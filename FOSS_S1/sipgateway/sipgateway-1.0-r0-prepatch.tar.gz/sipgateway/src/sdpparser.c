/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Parser for Session Description Protocol Data (SDP)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#include <sdpparser.h>
#include <gw_config.h>


/*
 * separate SIP message body from header
 */
char* sdp_get_content_ptr( char *msg, int max_len )
{
  char* p = msg;
  int i;

  for( i=0; i < max_len-4; ++i )
  {
    if( msg[i]=='\r' && msg[i+1]=='\n' && msg[i+2]=='\r' && msg[i+3]=='\n')
    {
      return( & msg[i+4] );
    }
  }

  return NULL;
}




/*
 * find line where given key occurs in str and store pointer to the
 * beginning of this line in *lineHandle. Returns length of the
 * the found line in case of success of negative error code.
 */
static int find_entity_line( const char* str, const char* key, const char** lineHandle )
{
  int max, i;
  char* p;

  p = strstr( str, key );
  if( p == NULL )
    return -1;

  max = strlen( p );

  /* go to beginning of next line, skip over empty lines */
  for( i=0; i<max; ++i )
    if( p[i] == '\r' || p[i] == '\n' )
      break;


  /* go to beginning of next line, skip over empty lines */
  for( ; i<max; ++i )
    if( p[i] != '\r' && p[i] != '\n' )
      break;


  *lineHandle = p;
  return i;
}

/*
 * replace the line where given key occurs in str by given new line
 */
static int replace_entity_line( char* str,  const int maxStrLen, const char* key, const char* pNewLine, int newLineLen )
{
  int retcode;
  char* pKeyLine;
  int keyLineLen;
  int strLen = strlen(str);
  int newStrLen;

  if( (keyLineLen = find_entity_line( str, key, (const char**)&pKeyLine )) < 0 )
    return keyLineLen;

  newStrLen = strLen + newLineLen - keyLineLen;
  if( newStrLen >= maxStrLen )
    return -1;

  /* now do the replacement */
  memmove( & pKeyLine[newLineLen], & pKeyLine[keyLineLen], strLen - (pKeyLine + keyLineLen - str) );
  memcpy(  & pKeyLine[0], pNewLine, newLineLen );

  /* set new line ending */
  str[newStrLen] = '\0';

  return 0;
}

/*
 * retrieves sdp entity for given key according to specifier in format string
 * according to the specification in scanf.
 */
int sdp_get_entities( const char* str, const int maxStrLen, const char* keyStr, const char* format, ... )
{
  const char* pKeyLine;
  int keyLineLen;
  va_list arg_list;
  int retcode;

  va_start( arg_list, format );

  if( ( keyLineLen = find_entity_line( str, keyStr, &pKeyLine ) ) < 0 )
    return keyLineLen;

  retcode = vsscanf( pKeyLine+strlen(keyStr), format, arg_list );
  va_end( arg_list );

  return retcode;
}



static int split_args( const char* pStr,  char* argv[], const int max_args )
{
  int argc = 0;
  char *pTmp, *pToFree;
  char* token;
  const char* sep=" \t\r\n";

  pTmp = pToFree = strdup( pStr );
  if( pTmp == NULL )
    return -1;

  while( (token = strsep( &pTmp, sep )) != NULL && strlen(token) > 0)
  {
    if( argc>= max_args )
      break;

    argv[argc++] = strdup( token );
  }

  free( pToFree );
  return argc;
}

static void free_args( int argc, char* argv[] )
{
  int i;

  for( i=0; i<argc; ++i )
    free( argv[i] );
}


/*
 * set sdp entity for given key according to specifier in format string
 * according to the specification in scanf.
 */
int sdp_set_entities( char* str, const int maxStrLen, const char* keyStr, const char* format, ... )
{
  const int keyStrLen = strlen( keyStr );
  const char* pKeyLine;
  int keyLineLen, newKeyLineLen;
  const int maxNewKeyLineLen = SDP_MAX_INET_ADDR_LEN;
  char newKeyArgStr[maxNewKeyLineLen];
  char* pNewKeyArgStr = newKeyArgStr;
  va_list arg_list;
  int retcode;
  const int max_args = 20;
  char *argv_new[max_args], *argv_old[max_args], *argv_merged[max_args];
  int argc_new, argc_old, arg_merged_len;
  int in, io, chars;

  va_start( arg_list, format );

  /* find entity line and generate old and new argument list */
  if( ( keyLineLen = find_entity_line( str, keyStr, &pKeyLine ) ) < 0 )
    return keyLineLen;

  retcode = vsnprintf( pNewKeyArgStr, maxNewKeyLineLen, format, arg_list );
  va_end( arg_list );

  argc_new = split_args( pNewKeyArgStr, argv_new, max_args );
  if( argc_new < 1 )
    return -1;

  argc_old = split_args( pKeyLine+strlen(keyStr), argv_old, max_args );
  if( argc_old < 1 )
  {
    free_args( argc_new, argv_new );
    return -1;
  }

  /* merge arguments in line together */
  strncpy( newKeyArgStr, keyStr, keyStrLen );
  pNewKeyArgStr = newKeyArgStr;
  for( in=0,io=0, chars=keyStrLen;  in < argc_new;  ++in, ++io )
  {
    if( io < argc_old )
    {
      if( (strcmp( argv_old[io], argv_new[in] ) == 0) || (*argv_new[in] == '*' ))
        argv_merged[in] = argv_old[io];
      else
        argv_merged[in] = argv_new[in];
    }
    else
    {
        argv_merged[in] = argv_new[in];
    }

    arg_merged_len = strlen( argv_merged[in] );
    if( chars + arg_merged_len + 1  >= maxNewKeyLineLen )
      break;

    strcpy( & pNewKeyArgStr[chars], argv_merged[in] ); chars+=strlen( argv_merged[in] );
    strcpy( & pNewKeyArgStr[chars++], " ");
  }
  --chars; /* remove last white space */

  /* append trailing "\r\n" string */
  if( chars > maxNewKeyLineLen - 2 )
    chars = maxNewKeyLineLen - 2;

  strcpy( & pNewKeyArgStr[chars], "\r\n" );
  chars+=2;

  /* replace the coding string */
  // gw_message( "====>:%s\n", newKeyArgStr );
  replace_entity_line( str, maxStrLen, keyStr, pNewKeyArgStr, chars );

  free_args( argc_new, argv_new );
  free_args( argc_old, argv_old );
  return argc_new;
}


/*
 * transfers all media attributes (keys m, a) from SDP record
 * (SIP message body string) from source to destination
 */
int sdp_transfer_media_attributes( char *dest, const int max_size_dest, const char *source )
{
  const char *p_media_source;
  char *p_media_dest;
  const char* key = "m=";

  p_media_source = strstr( source, key );
  if( p_media_source == NULL )
  {
    gw_error( "sdp_transfer_media_attributes: source key not found error!\n");
    return -1;
  }

  p_media_dest = strstr( dest, key );
  if( p_media_dest == NULL )
  {
    gw_error( "sdp_transfer_media_attributes: dest key not found error!\n");
    return -1;
  }

  strncpy( p_media_dest, p_media_source, max_size_dest - (p_media_dest - dest) );

  return 0;
}


/*!
 *  transfer connection address from SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry c=IN IP4 192.168.0.120
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: result address, in the exmample above 192.168.0.120
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_get_sdp_c_address( const char* sdp_str, const int sdp_str_len, char* addr )
{
  char tmp[SDP_MAX_INET_ADDR_LEN];
  int retcode;

  /* transfer SDP connection address */
  retcode = sdp_get_entities(
    sdp_str,
    sdp_str_len,
    "c=",
    "%"XSTR(SDP_MAX_INET_ADDR_LEN)"s %"XSTR(SDP_MAX_INET_ADDR_LEN)"s %"XSTR(SDP_MAX_INET_ADDR_LEN)"s",
    tmp, tmp, addr );

  if( retcode != 3 )
  {
    gw_error( "sdp_get_sdp_c_address: could not read connection attribute error!\n");
    return -retcode;
  }
  else
  {
    return 0;
  }
}


/*!
 *  transfer connection address to SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry c=
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: connection address to be set
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_set_sdp_c_address( char* sdp_str, const int sdp_str_len, const char* addr )
{
  int retcode;

  /* transfer SDP connection address */
  retcode = sdp_set_entities(
    sdp_str,
    sdp_str_len,
    "c=",
    "* * %s",
    addr );

  if( retcode != 3 )
  {
    gw_error( "sdp_set_sdp_c_address: could not write connection attribute error!\n");
    return -retcode;
  }
  else
  {
    return 0;
  }
}



/*!
 *  transfer origin address from SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry ol * * IN IP4 linphone.intern
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: result address, in the exmample above linhone.intern
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_get_sdp_o_address( const char* sdp_str, const int sdp_str_len, char* addr )
{
  char tmp[SDP_MAX_INET_ADDR_LEN];
  int retcode;

  /* transfer SDP connection address */
  retcode = sdp_get_entities(
    sdp_str,
    sdp_str_len,
    "o=",
    "%"XSTR(SDP_MAX_INET_ADDR_LEN)"s %"XSTR(SDP_MAX_INET_ADDR_LEN)"s %"XSTR(SDP_MAX_INET_ADDR_LEN)"s "
    "%"XSTR(SDP_MAX_INET_ADDR_LEN)"s %"XSTR(SDP_MAX_INET_ADDR_LEN)"s %"XSTR(SDP_MAX_INET_ADDR_LEN)"s",
    tmp, tmp, tmp, tmp, tmp, addr );

  if( retcode != 6 )
  {
    gw_error( "sdp_get_sdp_o_address: could not read origin attribute error!\n");
    return -retcode;
  }
  else
  {
    return 0;
  }
}


/*!
 *  transfer origin address to SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry o=
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: origin address to be set
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_set_sdp_o_address( char* sdp_str, const int sdp_str_len, const char* addr )
{
  int retcode;

  /* transfer SDP connection address */
  retcode = sdp_set_entities(
    sdp_str,
    sdp_str_len,
    "o=",
    "* * * * * %s",
    addr );

  if( retcode != 6 )
  {
    gw_error( "sdp_set_sdp_o_address: could not write origin attribute error!\n");
    return -retcode;
  }
  else
  {
    return 0;
  }
}


/*!
 *  transfer user name, session id and session version from sdp record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry ol * * IN IP4 linphone.intern
 *    - sdp_str_len: max. length of the SDP record
 *    - uname: extracted username
 *    - uname_len: maximum length of username string
 *    - sess_id: extracted session id
 *    - sess_ver: extracted session version
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_get_sdp_uname_sessid_sessver(
  const char* sdp_str,
  const int sdp_str_len,
  char* uname,
  const int uname_len,
  int* sess_id,
  int* sess_ver )
{
  char formatstr[100];
  int retcode;

  snprintf( formatstr, sizeof(formatstr), "%%%ds %%d %%d", uname_len );

  retcode = sdp_get_entities(
    sdp_str,
    sdp_str_len,
    "o=",
    formatstr,
    uname, sess_id, sess_ver );

  if( retcode != 3 )
  {
    gw_error( "sdp_get_sdp_uname_sessid_sessver: could not read user name, session id or version error!\n");
    return -retcode;
  }
  else
  {
    return 0;
  }
}


/*!
 *  transfer user name, session id and session version to sdp record
 *
 *  Function parameters
 *    - sdp_str: SDP record
 *    - sdp_str_len: max. length of the SDP record
 *    - uname: transfered username
 *    - uname_len: maximum length of username string
 *    - sess_id: transfered session id
 *    - sess_ver: transfered session version
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_set_sdp_uname_sessid_sessver(
  char* sdp_str,
  const int sdp_str_len,
  const char* uname,
  const int sess_id,
  const int sess_ver )
{
  int retcode;

  retcode = sdp_set_entities(
    sdp_str,
    sdp_str_len,
    "o=",
    "%s %d %d * * *",
    uname, sess_id, sess_ver );

  if( retcode != 6 )
  {
    gw_error( "sdp_set_sdp_uname_sessid_sessver: could not write user name, session id or version error!\n");
    return -retcode;
  }
  else
  {
    return 0;
  }
}


/*
 *  usage illustration
 */
int test_sdpparser(void)
{
  char s1[SDP_MAX_INET_ADDR_LEN];
  char s2[SDP_MAX_INET_ADDR_LEN];
  char s3[SDP_MAX_INET_ADDR_LEN];
  int i1, i2, retcode;

  gw_message("check sdp_get_entities ...\n");
  retcode = sdp_get_entities(
    int_sdp_record,
    sizeof(int_sdp_record),
    "o=",
    "%s %s %s",
    s1, s2, s3 );

  gw_message("retcode: %d\n", retcode );
  gw_message("%s, %s, %s\n", s1, s2, s3 );
  if( retcode != 3 )
  {
    gw_error( "sdp_get_entities [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( "sdp_get_entities [OK]\n");
  }


  gw_message("check sdp_set_entities ...\n");
  retcode = sdp_set_entities(
    int_sdp_record,
    sizeof(int_sdp_record),
    "o=",
    "%s %d %d * * *",
    "Testuser", 41, 42 );

  gw_message("retcode: %d\n", retcode );
  gw_message("%s\n", int_sdp_record );
  if( retcode != 6 )
  {
    gw_error( "sdp_set_entities [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( "sdp_set_entities [OK]\n");
  }


  gw_message("check sdp_get_sdp_c_address ...\n");
  retcode = sdp_get_sdp_c_address( int_sdp_record, sizeof(int_sdp_record), s1 );
  if( retcode != 0 )
  {
    gw_error( "check sdp_get_sdp_c_address [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( " got address %s\n", s1 );
    gw_message( "check sdp_get_sdp_c_address [OK]\n");
  }


  gw_message("check sdp_set_sdp_c_address ...\n");
  retcode = sdp_set_sdp_c_address( int_sdp_record, sizeof(int_sdp_record), "1.2.3.4" );
  if( retcode != 0 )
  {
    gw_error( " return code %d\n", retcode );
    gw_error( "check sdp_set_sdp_c_address [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( " got sdp record->\n%s\n", int_sdp_record );
    gw_message( "sdp_set_sdp_c_address [OK]\n");
  }




  gw_message("check sdp_get_sdp_o_address ...\n");
  retcode = sdp_get_sdp_o_address( int_sdp_record, sizeof(int_sdp_record), s1 );
  if( retcode != 0 )
  {
    gw_error( "check sdp_get_sdp_o_address [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( " got address %s\n", s1 );
    gw_message( "check sdp_get_sdp_o_address [OK]\n");
  }


  gw_message("check sdp_set_sdp_o_address ...\n");
  retcode = sdp_set_sdp_o_address( int_sdp_record, sizeof(int_sdp_record), "1.2.3.4" );
  if( retcode != 0 )
  {
    gw_error( " return code %d\n", retcode );
    gw_error( "check sdp_set_sdp_o_address [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( " got sdp record->\n%s\n", int_sdp_record );
    gw_message( "sdp_set_sdp_o_address [OK]\n");
  }


  gw_message("sdp_get_sdp_uname_sessid_sessver ...\n");
  retcode = sdp_get_sdp_uname_sessid_sessver(
    int_sdp_record, sizeof(int_sdp_record),
    s1, sizeof(s1),
    &i1,
    &i2 );
  if( retcode != 0 )
  {
    gw_error( " return code %d\n", retcode );
    gw_error( "check sdp_get_sdp_uname_sessid_sessver [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( " got user name %s, sess id %d, sess verion %d\n", s1, i1, i2 );
    gw_message( "sdp_get_sdp_uname_sessid_sessver [OK]\n");
  }


  gw_message("sdp_set_sdp_uname_sessid_sessver ...\n");
  retcode = sdp_set_sdp_uname_sessid_sessver(
    int_sdp_record, sizeof(int_sdp_record),
    "New_User",
    99,
    100 );
  if( retcode != 0 )
  {
    gw_error( " return code %d\n", retcode );
    gw_error( "check sdp_set_sdp_uname_sessid_sessver [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( " got sdp record->\n%s\n", int_sdp_record );
    gw_message( "sdp_set_sdp_uname_sessid_sessver [OK]\n");
  }


  gw_message("sdp_transfer_media_attributes ...\n");
  retcode = sdp_transfer_media_attributes( int_sdp_record, sizeof(int_sdp_record), ext_sdp_record );
  if( retcode != 0 )
  {
    gw_error( "sdp_transfer_media_attributes [NOT OK]\n");
    return retcode;
  }
  else
  {
    gw_message( "sdp_transfer_media_attributes [OK]\n");
  }


  return 0;
}
