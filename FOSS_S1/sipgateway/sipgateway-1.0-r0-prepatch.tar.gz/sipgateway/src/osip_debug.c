/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Lookuptables to stringify some macro definitions
 */
#include <sipgateway.h>
#include <eXosip2.4/eXosip.h>
#include <pstn.h>

const char *g_exosip_evt_type_name[] = {
  "EXOSIP_REGISTRATION_SUCCESS",       /**< user is successfully registred.  */
  "EXOSIP_REGISTRATION_FAILURE",       /**< user is not registred.           */
  "EXOSIP_CALL_INVITE",            /**< announce a new call                   */
  "EXOSIP_CALL_REINVITE",          /**< announce a new INVITE within call     */
  "EXOSIP_CALL_NOANSWER",          /**< announce no answer within the timeout */
  "EXOSIP_CALL_PROCEEDING",        /**< announce processing by a remote app   */
  "EXOSIP_CALL_RINGING",           /**< announce ringback                     */
  "EXOSIP_CALL_ANSWERED",          /**< announce start of call                */
  "EXOSIP_CALL_REDIRECTED",        /**< announce a redirection                */
  "EXOSIP_CALL_REQUESTFAILURE",    /**< announce a request failure            */
  "EXOSIP_CALL_SERVERFAILURE",     /**< announce a server failure             */
  "EXOSIP_CALL_GLOBALFAILURE",     /**< announce a global failure             */
  "EXOSIP_CALL_ACK",               /**< ACK received for 200ok to INVITE      */
  "EXOSIP_CALL_CANCELLED",         /**< announce that call has been cancelled */
  "EXOSIP_CALL_MESSAGE_NEW",              /**< announce new incoming request. */
  "EXOSIP_CALL_MESSAGE_PROCEEDING",       /**< announce a 1xx for request. */
  "EXOSIP_CALL_MESSAGE_ANSWERED",         /**< announce a 200ok  */
  "EXOSIP_CALL_MESSAGE_REDIRECTED",       /**< announce a failure. */
  "EXOSIP_CALL_MESSAGE_REQUESTFAILURE",   /**< announce a failure. */
  "EXOSIP_CALL_MESSAGE_SERVERFAILURE",    /**< announce a failure. */
  "EXOSIP_CALL_MESSAGE_GLOBALFAILURE",    /**< announce a failure. */
  "EXOSIP_CALL_CLOSED",            /**< a BYE was received for this call      */
  "EXOSIP_CALL_RELEASED",             /**< call context is cleared.            */
  "EXOSIP_MESSAGE_NEW",              /**< announce new incoming request. */
  "EXOSIP_MESSAGE_PROCEEDING",       /**< announce a 1xx for request. */
  "EXOSIP_MESSAGE_ANSWERED",         /**< announce a 200ok  */
  "EXOSIP_MESSAGE_REDIRECTED",       /**< announce a failure. */
  "EXOSIP_MESSAGE_REQUESTFAILURE",   /**< announce a failure. */
  "EXOSIP_MESSAGE_SERVERFAILURE",    /**< announce a failure. */
  "EXOSIP_MESSAGE_GLOBALFAILURE",    /**< announce a failure. */
  "EXOSIP_SUBSCRIPTION_NOANSWER",          /**< announce no answer              */
  "EXOSIP_SUBSCRIPTION_PROCEEDING",        /**< announce a 1xx                  */
  "EXOSIP_SUBSCRIPTION_ANSWERED",          /**< announce a 200ok                */
  "EXOSIP_SUBSCRIPTION_REDIRECTED",        /**< announce a redirection          */
  "EXOSIP_SUBSCRIPTION_REQUESTFAILURE",    /**< announce a request failure      */
  "EXOSIP_SUBSCRIPTION_SERVERFAILURE",     /**< announce a server failure       */
  "EXOSIP_SUBSCRIPTION_GLOBALFAILURE",     /**< announce a global failure       */
  "EXOSIP_SUBSCRIPTION_NOTIFY",            /**< announce new NOTIFY request     */
  "EXOSIP_IN_SUBSCRIPTION_NEW",            /**< announce new incoming SUBSCRIBE.*/
  "EXOSIP_NOTIFICATION_NOANSWER",          /**< announce no answer              */
  "EXOSIP_NOTIFICATION_PROCEEDING",        /**< announce a 1xx                  */
  "EXOSIP_NOTIFICATION_ANSWERED",          /**< announce a 200ok                */
  "EXOSIP_NOTIFICATION_REDIRECTED",        /**< announce a redirection          */
  "EXOSIP_NOTIFICATION_REQUESTFAILURE",    /**< announce a request failure      */
  "EXOSIP_NOTIFICATION_SERVERFAILURE",     /**< announce a server failure       */
  "EXOSIP_NOTIFICATION_GLOBALFAILURE"     /**< announce a global failure       */
};

const char *g_pstn_evt_type_name[] = {
  "PSTN_CALL_INVITE",           /** incomming call */
  "PSTN_CALL_COMPLETED",        /** outgoing call answered */
  "PSTN_CALL_ALERTING",         /** outgoing call ringing used for early media establishment */
  "PSTN_CALL_BUSY",             /** outgoing call but line is busy */
  "PSTN_CALL_TERMINATED",       /** call is terminated */
  "PSTN_CALL_VOIP_LOOPBACK",    /** enable loopback mode over VoIP */
  "PSTN_CALL_RESET"             /** assure terminated state, if necessary irregular transition to it */
};

const char* g_gw_state_name[] = {
  "GW_STATE_TERMINATED",
  "GW_STATE_PROCEEDING_INCOMING_CALL",     /* call PSTN -> SIP */
  "GW_STATE_PROCEEDING_OUTGOING_CALL",     /* call SIP -> PSTN */
  "GW_STATE_PROCEEDING_LOOPTHROUGH_CALL",  /* loopthrough in internal SIP instance (for latency calc) */
  "GW_STATE_COMPLETED",                    /* call established */
  "GW_STATE_TERMINATING"                   /* terminating call */
};

int gw_verify_debug_strings( void )
{
  return(
    (sizeof(g_exosip_evt_type_name) / sizeof( const char* )) == EXOSIP_EVENT_COUNT ||
    (sizeof(g_pstn_evt_type_name) / sizeof( const char* )) == PSTN_EVENT_COUNT ||
    (sizeof(g_gw_state_name) / sizeof( const char* )) == GW_STATE_COUNT
    );
}
