/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Lookuptables to stringify some macro definitions
 */

#ifndef OSIP_DEBUG_

extern const char *g_exosip_evt_type_name[];
extern const char *g_pstn_evt_type_name[];
extern const char* g_gw_state_name[];

int gw_verify_debug_strings( void );

#endif /* #ifndef OSIP_DEBUG_ */
