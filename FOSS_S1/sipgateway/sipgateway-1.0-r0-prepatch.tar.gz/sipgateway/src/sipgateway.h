/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Gateway State Machine and VoIP/PSTN Event Handling
 */

#ifndef SIPGATEWAY_H

/*!
 * call states of the sip gateway
 *
 *    incoming call means we have received a call from PSTN via GSM/UMTS/LTE
 *    outgoing call means we have received an INVITE from external VOIP instance e.g. Linphone/Headunit
 *    ecall is a separate state where different audio setup is used (not implemented yet)
 *    terminated means idle state where no call and no connection activity is present
 *    proceeding state is indicating that the call is established to one side only
 *    completed call is completely established and voice date is transfered
 */
typedef enum {
  GW_STATE_TERMINATED,
  GW_STATE_PROCEEDING_INCOMING_CALL,     /* call PSTN -> SIP */
  GW_STATE_PROCEEDING_OUTGOING_CALL,     /* call SIP -> PSTN */
  GW_STATE_PROCEEDING_LOOPTHROUGH_CALL,  /* loopthrough in internal SIP instance (for latency calc) */
  GW_STATE_COMPLETED,                    /* call established */
  GW_STATE_TERMINATING,                  /* terminating call */
  GW_STATE_ECALL,                        /* special case, threaded elsewhere */
  GW_STATE_COUNT                         /* < MAX number of states */
} tSipGatewayState;

#endif /* #ifndef SIPGATEWAY_H */
