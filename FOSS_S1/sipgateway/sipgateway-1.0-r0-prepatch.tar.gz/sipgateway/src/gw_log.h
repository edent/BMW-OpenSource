/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * logging
 */
#ifndef GW_LOG_H_
#define GW_LOG_H_


#ifndef LOG_TAG
#define LOG_TAG "SIPGW"
#endif


/*!
 * for message log output, currently to stdout
 */
void gw_message( const char* fmt, ... );


/*!
 * for error log output, currently to stderr
 */
void gw_error( const char* fmt, ... );



#endif /* #ifndef GW_LOG_H_ */
