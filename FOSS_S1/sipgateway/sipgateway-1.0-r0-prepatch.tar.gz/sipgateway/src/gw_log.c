/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * logging
 */
#include <gw_log.h>
#include <stdio.h>
#include <stdarg.h>
#include <time.h>
#include <sys/syslog.h>


#define LOG_SETTING  ( LOG_NOWAIT | LOG_PID )

/*!
 * for message log output, currently to stdout
 */
void gw_message( const char* fmt, ... )
{
  va_list args;

  va_start( args, fmt );
  openlog( LOG_TAG, LOG_SETTING, LOG_SYSLOG );
  vsyslog( LOG_INFO, fmt, args );
  closelog();
  va_end( args );
}

/*!
 * for error log output, currently to stderr
 */
void gw_error( const char* fmt, ... )
{
  va_list args;

  va_start( args, fmt );
  openlog( LOG_TAG, LOG_SETTING, LOG_SYSLOG );
  vsyslog( LOG_ERR, fmt, args );
  closelog();
  va_end( args );
}
