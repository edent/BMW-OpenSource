/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Interface to Linphone instance running in daemon mode (--pipe)
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <fcntl.h>
#include <gw_config.h>
#include <gw_log.h>


/*!
 * connect to linphone's control socket and return filedescriptor or error code
 */
static int linphone_connect_uds( void )
{
  struct sockaddr_un address;
  int fd, retcode;

  memset( &address, 0, sizeof(struct sockaddr_un) );
  address.sun_family = AF_UNIX;
  snprintf(address.sun_path, 108, "/tmp/linphonec-%d", g_linhone_proc_uid ) ;

  fd = socket(PF_UNIX, SOCK_STREAM, 0);
  if( fd < 0 )
  {
    gw_error( "Could open linphone daemon socket %s, is process running?\n",
              address.sun_path );
    return fd;
  }

  retcode = connect( fd, (struct sockaddr *) &address, sizeof(struct sockaddr_un));
  if( retcode != 0 )
  {
    gw_error( "Could not connect to linphone daemon socket %s (error: %d), is process running?\n",
              address.sun_path, retcode);
    close(fd);
    return retcode;
  }
  else
  {
    return fd;
  }
}


/*!
 * send call request to linphone instance via named pipe
 * runing in daemon mode with given address
 */
int linphone_call(  char* sip_addr )
{
  int fd;
  char cmd[256];
  int cmdLen;
  char answer[1024];
  int answerBytesRead;
  const char* linphoneAckStr = "Establishing call";
  int retcode;

  snprintf(cmd, sizeof(cmd), "call %s",  sip_addr );
  cmdLen = strlen(cmd);

  gw_message("Send command string '%s' to internal linphone instance ...\n", cmd );

  fd = linphone_connect_uds();
  if( fd < 0 )
    return fd;

  if( write( fd, cmd, cmdLen ) != cmdLen )
  {
    gw_error( "Could not write call command to linphone daemon!\n" );
    close(fd);
    return -1;
  }

  answerBytesRead = read( fd, answer, sizeof(answer) );

  retcode = strncmp( linphoneAckStr, answer, strlen(linphoneAckStr) );
  if( retcode )
  {
    gw_error( "No acknowledge message 'Establishing call' received from linphone daemon errror!\n" );
  }

  close(fd);
  return retcode;
}


/*!
 * send request to terminate active call to internal linphone instance
 */
int linphone_terminate( void )
{
  int fd;
  const char cmd[] = "terminate";
  const int cmdLen = sizeof(cmd);
  char answer[1024];
  int answerBytesRead;
  const char* linphoneAckStr1 = "Call";
  const char* linphoneAckStr2 = "ended";
  int retcode;

  gw_message("Send command string '%s' to internal linphone instance ...\n", cmd );

  fd = linphone_connect_uds();
  if( fd < 0 )
    return fd;

  if( write( fd, cmd, cmdLen ) != cmdLen )
  {
    gw_error( "Could not write call command to linphone daemon!\n" );
    close(fd);
    return -1;
  }

  answerBytesRead = read( fd, answer, sizeof(answer) );

  retcode = ( strstr( answer, linphoneAckStr1 ) == NULL )  ||
            ( strstr( answer, linphoneAckStr2 ) == NULL );
  if( retcode )
  {
    gw_error( "No acknowledge message 'Call x with <y> ended' received from linphone daemon errror!\n" );
  }

  return retcode;
}
