/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Handling of configuration data
 */
#ifndef GW_CONFIG_H
#define GW_CONFIG_H

#include <stdio.h>

#define SDP_RECORD_SIZE 4096


/*!
 * SDP record of internal linphone instance whose audio
 * interfaces are bound to the PSTN network e.g. via
 * a GSM/UMTS/LTE modem.
 */
extern char int_sdp_record[SDP_RECORD_SIZE];


/*!
 * SDP record of external VoIP instance instance whose audio
 * interfaces are bound to the PSTN network e.g. via a
 * GSM/UMTS/LTE modem
 *
 * The given values are just an example. They are over-
 * written during intial configuration.
 */
extern char ext_sdp_record[SDP_RECORD_SIZE];


/*!
 * When the internal VoiP UE is running on the
 * same machine it is good idea to restrict
 * the address range is going to use to internal
 * IP addresses (localhost). Declare the address
 * 127.0.0.1 for such a case. If this variable
 * is not specified the gateway will forward
 * external SIP messages to any address specified
 * within the SIP header.
 */
extern char g_gateway_int_network_ipv4_address[256];


/*!
 * When more than one network card is in use
 * it is recommended to explictly specify the
 * networks IP address which will be used
 * in SIP contact and transfer fields. Some
 * SIP user agents might otherwise not be able
 * to contact the sipserver in case the wrong
 * network is choosen. Refer to the option
 * EXOSIP_OPT_SET_IPV4_FOR_GATEWAY with the
 * eXosip2 library for more detailed information.
 */
extern char g_gateway_ext_network_ipv4_address[256];

/*
 * Accept exclusively calls from the
 * gateway-ext-network-ipv4-address when
 * accept-only-gateway-ext-network-address is
 * set to true. SIP INVITE messages to other
 * target addresses possible when more than
 * one network is present are declined in this
 * case.
*/
extern int g_accept_only_gateway_ext_network_address;

/*!
 * When true overwrite the address fields
 * in the internal sdp record which are send
 * to the external VoIP instance with the
 * address used in the registration.
 * When false the ip addresses declared in the
 * sdp records are used.
 */
extern int g_gateway_use_dynamic_int_address;

/*!
 * When true overwrite the address fields
 * in the external sdp record which are send
 * to the internal VoIP instance with the
 * address used in the registration.
 * When false the ip addresses declared in the
 * sdp records are used.
 */
extern int g_gateway_use_dynamic_ext_address;

/*!
 * When true the media attributes are tranfered
 * transparently between internal and external
 * SIP instance. Otherwise the attributes specified
 * in the "int-sdp_record" and "ext-sdp-record"
 * are used.
 */
extern int g_gateway_transfer_ext_invite_address;

/*!
 * When true the media attributes are tranfered
 * transparently between internal and external
 * SIP instance. Otherwise the attributes specified
 * in the "int-sdp_record" and "ext-sdp-record"
 * are used.
 */
extern int g_gateway_transfer_media_attributes;

/*!
 * used transport protocol for SIP messaging (IPPROTO_UDP or IPPROTO_UDP_TCP)
 */
extern int g_gateway_transport;


/*!
 * SIP port where an external VoIP instance such as a smartphone
 * app or a vehicles head unit can connect to. The corresponding
 * IP address is retrieved from by the origin field of the
 * external sdp record, see above.
*/
extern int g_gateway_ext_sip_port;


/*!
 * SIP port for connections of the gateway server (UAS) which is
 * in example used when we trigger it to send us an invite request.
 */
extern int g_gateway_int_sip_port;


/*!
 * Address for access to internal VoIP user equipment (linphone)
 * if gateway-transfer-ext-invite_address is not enabled. Otherwise
 * the gateway proxies to the UE found in the SIP INVITE header.
 */
extern char g_linphone_int_network_ipv4_address[256];


/*!
 * Default IPv4 address for external VoIP user equipment. This
 * could be required in case the external client does not
 * register.
 */
extern char g_default_ext_ue_ipv4_address[256];


/*!
 * Enforce usage of the address g_linphone_int_network_ipv4_address
 * in even when gateway-transfer-ext-invite_address is set to true.
 * This allows to redirect SIP IP addresses to localhost e.g. for
 * security reasons.
 */
extern int g_enforce_linphone_int_addr;


/*!
 * SIP port of managed internal VoIP (linphone) daemon. This
 * daemon is reached under the IP address which is indicated by
 * the origin field of the internal sdp record, see above.
 */
extern int g_linphone_int_sip_port;


/*!
 * user id of the linphone process. The console application
 * linphonec adds the proc uid number to the unix domain
 * socket file name. Declare 0 when linphonec runs as root
 * or the corresponding uid otherwise.
 */
extern int g_linhone_proc_uid;


/*!
 * TCP port serving control interface for external handler to
 * public switched telephony network (modem). Specify negative
 * value to use unix domain socket /tmp/sipgateway.uds.
 */
extern int g_pstn_crtl_port;


/*!
 * complete sip uri (address and port) of external VoIP instance
 * This data is retrieved from ext_sdp_record and g_gateway_ext_sip_port
 *
 * @refer to g_gateway_ext_sip_port for more information
 */
extern char g_gateway_ext_sip_uri[256];


/*!
 * complete sip uri (address and port) of gateway server
 * This data is retrieved from int_sdp_record and g_gateway_int_sip_port
 *
 * @refer to g_gateway_int_sip_port for more information
 */
extern char g_gateway_int_sip_uri[256];


/*!
 * complete sip uri (address and port) of internal VoIP instance
 * This data is retrieved from int_sdp_record and g_linphone_int_sip_port
 *
 * @refer to g_linphone_int_sip_port for more information
 */
extern char g_linphone_int_sip_uri[256];


/*!
 * pointer to configuration parser method
 */
typedef int (*tGWConfHandler) ( FILE* fp, const char * );


/*!
 * command list entry for all events received via socket interface
 */
typedef struct {
  char*             cmdStr;
  tGWConfHandler    pHandler;
} tGWConfCmd;



/*!
 * read configuration data from ~/.sipgateway.rc or /etc/sipgateway.rc
 * return 0 in case of success, otherwise error code
 */
int gw_init_config(void);

/*!
 * construct URI's out of sdp origin address and
 * given port
 */
int gwc_init_uri_addresses(void);

#endif /* #ifndef GW_CONFIG_H */
