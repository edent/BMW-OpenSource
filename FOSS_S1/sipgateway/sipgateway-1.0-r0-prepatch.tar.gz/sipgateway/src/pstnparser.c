/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Interface to Public Telephone Switched Network (PSTN)
 * Parser for event and command string send of socket
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <pstnparser.h>
#include <strutils.h>

/* maximum allowed size for a PSTN command */
#define MAX_CMD_SIZE   128

static int pstn_incoming_call( tPstnEvt* pEvt, const char *pArgStr)
{
  pEvt->type = PSTN_CALL_INVITE;
  if( pArgStr )
    s_strlcpy(pEvt->number, pArgStr, PSTN_MAX_NUMBER_LEN );
  else
    pEvt->number[0] = '\0';

  return 0;
}

static int pstn_comleted_call( tPstnEvt* pEvt, const char *pArgStr)
{
  pEvt->type = PSTN_CALL_COMPLETED;
  return 0;
}

static int pstn_alerting_call( tPstnEvt* pEvt, const char *pArgStr)
{
  pEvt->type = PSTN_CALL_ALERTING;
  return 0;
}

static int pstn_busy( tPstnEvt* pEvt, const char *pArgStr)
{
  pEvt->type = PSTN_CALL_BUSY;
  return 0;
}

static int pstn_terminated( tPstnEvt* pEvt, const char *pArgStr)
{
  pEvt->type = PSTN_CALL_TERMINATED;
  return 0;
}

static int pstn_voip_loopback( tPstnEvt* pEvt, const char *pArgStr)
{
  pEvt->type = PSTN_CALL_VOIP_LOOPBACK;
  return 0;
}

static int pstn_reset( tPstnEvt* pEvt, const char *pArgStr)
{
  pEvt->type = PSTN_CALL_RESET;
  return 0;
}

static int pstn_help( tPstnEvt* pEvt, const char *pArgStr);


static tPstnCmd eventTable[] = {
  { PSTN_CMD_INCOMING_CALL, pstn_incoming_call, "signal an incoming all from PSTN" },
  { PSTN_CMD_COMPLETED, pstn_comleted_call, "signal that call is established" },
  { PSTN_CMD_ALERTING, pstn_alerting_call, "signal that call is going to be established (early media)" },
  { PSTN_CMD_BUSY, pstn_busy, "signal that line is busy" },
  { PSTN_CMD_TERMINATED, pstn_terminated, "signal that phone call has been terminated" },
  { PSTN_CMD_VOIP_LOOPBACK, pstn_voip_loopback, "switch to VoIP loopback mode" },
  { PSTN_CMD_RESET, pstn_reset, "assure terminated state, if necessary irregular transition to it" },
  { PSTN_CMD_HELP, pstn_help, "prints available commands" }
};


static int pstn_help( tPstnEvt* pEvt, const char *pArgStr)
{
  int i;
  const char title[] = "sipgateway - list of available commands\n\n";
  char cmdStrBuf[100];

  send( pEvt->pCtx->socket_connect_fd, title, sizeof(title), 0 );
  for( i=0; i < (sizeof(eventTable) / sizeof(tPstnCmd)); ++i )
  {
    sprintf( cmdStrBuf, "%30s : ", eventTable[i].cmdStr );
    send( pEvt->pCtx->socket_connect_fd, cmdStrBuf, strlen(cmdStrBuf), 0 );
    send( pEvt->pCtx->socket_connect_fd, eventTable[i].helpString, strlen(eventTable[i].helpString), 0 );
    send( pEvt->pCtx->socket_connect_fd, "\n", 1, 0 );
  }

  /* no event generated */
  return -1;
}

/*!
 * parse event string and transforms to event data
 */
int pstn_parse( tPstnEvt* pEvt, const char* str )
{
  int i;
  char buf[MAX_CMD_SIZE];
  char* pbuf = buf, *pToken;
  const char* sep=" \t\r\n";

  s_strlcpy( buf, str, MAX_CMD_SIZE );
  buf[MAX_CMD_SIZE-1] = '\0'; /* enforce null termination */

  /* remove all leading and trailing spaces, tabs, etc. */
  condition_string( pbuf, MAX_CMD_SIZE );
  pToken = strsep( &pbuf, sep );

  if( pToken == NULL )
    return PSTN_EVENT_NOT_DEFINED_ERROR;

  strtolower( pToken, MAX_CMD_SIZE );

  for( i=0; i < (sizeof(eventTable) / sizeof(tPstnCmd)); ++i )
  {
    if( strcmp( eventTable[i].cmdStr, pToken ) == 0 )
    {
      /* we got the command so inoke the corresponding handler */
      return( (*eventTable[i].pHandler)( pEvt, pbuf ) );
    }

  }

  return PSTN_EVENT_NOT_DEFINED_ERROR;
}
