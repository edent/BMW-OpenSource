/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Gateway State Machine and VoIP/PSTN Event Handling
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <assert.h>
#include <getopt.h>
#include <netinet/in.h>
#include <eXosip2.4/eXosip.h>
#include <config.h>

#include <sipgateway.h>
#include <pstn.h>
#include <sdpparser.h>
#include <gw_config.h>
#include <gw_log.h>
#include <osip_debug.h>

#include <signal.h>
#include <execinfo.h>

#define MAX(x,y) ( ((x)>(y))?(x):(y))
#define MIN(x,y) ( ((x)<(y))?(x):(y))


/*
 * time cycles  for state terminating  when the event loop  cyles more
 * then this the terminating state is  left and the system return into
 * idle  (terminated) state.  This  ensures that  VoiP subsystem  will
 * return to  its operational state  even when state events  from pstn
 * are missing.
 */
#define TERMINATING_STATE_TIMEOUT      100 /* one cycle equals 100ms */
#define PROC_INCOMING_STATE_TIMEOUT    300 /* one cycle equals 100ms */
#define PROC_OUTGOING_STATE_TIMEOUT    300 /* one cycle equals 100ms */


/*!
 * helper function for allocation and intialization of libexosip2
 * return 0 on success otherwise errorcode
 */
static int init_exosip( struct eXosip_t** ctxHandle, const char* listen_to_addr,
                        int listen_to_port, int protocol )
{
  struct eXosip_t* pCtx = *ctxHandle;
  const char* address = (listen_to_addr && strlen(listen_to_addr)>4) ? listen_to_addr : NULL;
  const char* disp_address = (listen_to_addr && strlen(listen_to_addr)>4) ? listen_to_addr : "all interfaces";
  const int pause_between_retries = 3;
  int retries = 30;
  int retcode;

  pCtx = eXosip_malloc();
  if( pCtx == NULL )
  {
    gw_error( "exosip initialization malloc failed!\n");
    return -1;
  }

  retcode = eXosip_init(pCtx);
  if( retcode!= 0 )
  {
    gw_error( "exosip initialization failed!\n");
    return -1;
  }

  if(listen_to_port)
  {
    do {
      gw_message("start listening to address: %s, port: %d\n", disp_address, listen_to_port );
      retcode = eXosip_listen_addr( pCtx, protocol, address, listen_to_port, AF_INET, 0 );
      if( retcode!= 0 )
      {
        gw_error( "could not initialize gateway transport layer for port %d, retry %d times ...\n",
                  listen_to_port, retries );
        sleep( pause_between_retries );
      }
    } while( retcode != 0 && --retries > 0);
  }

  if( retcode )
    eXosip_quit( pCtx );
  else
    *ctxHandle = pCtx;

  return retcode;
}




static void help( const char* app_name )
{
  printf("Invocation: %s [ options ]\n\n", app_name );
  printf("Options:\n");
  printf("--loopback-voip\n-l\n");
  printf("\tSet internally managed VoIP instance (Linphone) to loopback mode.\n\n");
  printf("--level <0..6>\n-d <0..6>\n");
  printf("\tbe verbose. 0 is no output of osip/eXosip library. 6 is all output.\n\n");
  printf("--version\n-v\n");
  printf("\tPrints version information.\n\n");
  printf("--help\n-h\n");
  printf("\tThis help screen. For more informaiton refer also to the man page.\n\n");
}


static int parse_args( int argc, char* argv[], int* enable_voip_loopback, int* log_level )
{
  int optindex, optchar, error = 0;
  const struct option long_options[] =
  {
    { "help", no_argument, NULL, 'h' },
    { "version", no_argument, NULL, 'v' },
    { "loopback-voip", no_argument, NULL, 'l' },
    { "level", required_argument, NULL, 'd' }
  };

  printf("%s - A primitive SIP gateway from VoIP to PSTN\n", argv[0] );
  printf("based on libeXosip2 and libosip2 from Antisip ( http://www.antisip.com )\n");
  printf("written by Otto Linnemann\n");
  printf("Copyright 2013 GNU General Public Licence. All rights reserved.\n\n");

  while( ( optchar = getopt_long( argc, argv, "hvld:", long_options, &optindex ) ) != -1 )
  {
    switch( optchar )
    {
    case 'h':
      help( argv[0] );
      error = -1;
      break;

    case 'v':
      gw_message( "Version: %s\n", VERSION );
      error = -1;
      break;

    case 'l':
      gw_message("--- start in voip loopback mode ---\n");
      *enable_voip_loopback = 1;
      break;

    case 'd':
      *log_level = atoi( optarg );
      *log_level = MAX( *log_level, 0);
      *log_level = MIN( *log_level, 6);
      gw_message("set loglevel to %d\n", *log_level );
      break;

    default:
      gw_error( "input argument error!\n");
      return -1;
    }
  }

  return error;
}


void print_trace( void )
{
  void *array[10];
  size_t size;
  char **strings;
  size_t i;

  size = backtrace (array, 10);
  strings = backtrace_symbols (array, size);

  gw_error ("Obtained %zd stack frames.\n", size);

  for (i = 0; i < size; i++)
    gw_error ("%s\n", strings[i]);

  free (strings);
}

void segfaulthandler( int sig_num )
{
  gw_error( "!!!!! RECEIVED SEGMENTATION FAULT !!!!!\n" );
  gw_error( "=======================================\n" );
  print_trace();
  exit( -1 );
}


int main( int argc, char* argv[] )
{
  int retcode;

  /* external visible address where devices as smarthpones, PC's, etc.
     can register at */
  struct eXosip_t* pExtSipCtx;
  eXosip_event_t* pExtSipEvt = NULL;
  osip_message_t* pExtSipAnswer;
  osip_message_t* pExtSipRequest;
  osip_message_t* pExtSipInvite;
  int extSip_cid, extSip_tid, extSip_did;

  /* internal VoIP instance as e.g. Linphone which gets audio from
     PSTN (cellular voice call) */
  struct eXosip_t* pIntSipCtx;
  eXosip_event_t* pIntSipEvt = NULL;
  osip_message_t* pIntSipAnswer;
  osip_message_t* pIntSipInvite = NULL;
  osip_message_t* pIntSipRequest;
  int intSip_cid, intSip_tid, intSip_did;

  /* Public Switched Telelphone Network (via GSM/UTMS/LTE) */
  tPstn* pIntPstnCtx;
  tPstnEvt* pIntPstnEvt;
  int intPstn_cid;


  /* flags about established connections */
  int extSipCallEstablished;
  int intSipCallEstablished;
  int intPstnCallEstablished;
  int intPstnCallTriggered;

  int terminating_state_timeout_cnt;
  int proc_incoming_state_timeout_cnt;
  int proc_outgoing_state_timeout_cnt;


  osip_header_t* refer_to = NULL;

  char* p_msg_ext_str = NULL, *p_body_ext_str;
  int msg_ext_str_len;

  char* p_msg_int_str = NULL, *p_body_int_str;
  int msg_int_str_len;

  char username[100];
  char phonenumber[100];
  int  sess_id, sess_version;
  sdp_message_t *ext_sdp, *int_sdp;

  tSipGatewayState sipGatewayState = GW_STATE_TERMINATED;
  int enable_voip_loopback = 0;

  char registered_ext_addr[SDP_MAX_INET_ADDR_LEN+1]; /* external address taken from REGISTER evt */
  char registered_int_addr[SDP_MAX_INET_ADDR_LEN+1]; /* internal address taken from REGISTER evt */
  int  registered_ext_sip_port = 5060;

  char ue_ext_addr[SDP_MAX_INET_ADDR_LEN+1];     /* external address taken from  evt */
  char ue_int_addr[SDP_MAX_INET_ADDR_LEN+1];     /* internal address taken from REG*/

  char ue_ext_sip_addr[SDP_MAX_INET_ADDR_LEN+1]; /* SIP:<ue_ext_addr>:PORT */
  char ue_int_sip_addr[SDP_MAX_INET_ADDR_LEN+1]; /* SIP:<ue_int_addr>:PORT */
  char gw_int_sip_addr[SDP_MAX_INET_ADDR_LEN+1]; /* SIP:<gw_int_addr>:PORT */
  char gw_ext_sip_addr[SDP_MAX_INET_ADDR_LEN+1]; /* SIP:<gw_ext_addr>:PORT */

  char tmp_str[SDP_MAX_INET_ADDR_LEN+1];
  char *p_int_listen_addr = NULL, *p_ext_listen_addr = NULL;
  int log_level;

  if( signal( SIGSEGV, segfaulthandler ) == SIG_ERR )
    gw_error( "Could not register SIGSEGV error!\n");

  if( signal( SIGFPE, segfaulthandler ) == SIG_ERR )
    gw_error( "Could not register SIGFPE error!\n");

  if( signal( SIGPIPE, segfaulthandler ) == SIG_ERR )
    gw_error( "Could not register SIGPIPE error!\n");

  /* initialize address strings, ensure NULL termination by defining them one byte longer */
  memset( registered_ext_addr, 0, sizeof( registered_ext_addr ) );
  memset( registered_int_addr, 0, sizeof( registered_int_addr ) );
  memset( ue_ext_addr, 0, sizeof( ue_ext_addr ) );
  memset( ue_ext_sip_addr, 0, sizeof( ue_ext_sip_addr ) );
  memset( ue_int_addr, 0, sizeof( ue_int_addr ) );
  memset( tmp_str, 0, sizeof( tmp_str ) );

  /* check that enum debug array lengthes match to enum definition */
  assert( gw_verify_debug_strings() );

  /* print version info string and parse command line args */
  retcode = parse_args( argc, argv, &enable_voip_loopback, &log_level );
  if( retcode )
    return retcode;

  osip_trace_initialize_syslog( log_level, LOG_TAG );

  /* read configuration data */
  retcode = gw_init_config();
  if( retcode )
  {
    gw_error( "configuration error occured, exit!\n");
    return -1;
  }

  s_strlcpy( ue_int_sip_addr, g_linphone_int_sip_uri, sizeof( ue_int_sip_addr ) );
  s_strlcpy( gw_int_sip_addr, g_gateway_int_sip_uri, sizeof( gw_int_sip_addr ) );
  s_strlcpy( gw_ext_sip_addr, g_gateway_ext_sip_uri, sizeof( gw_ext_sip_addr ) );
  s_strlcpy( registered_ext_addr, g_default_ext_ue_ipv4_address, sizeof( registered_ext_addr ) );
  s_strlcpy( registered_int_addr, g_default_ext_ue_ipv4_address, sizeof(registered_int_addr) );

  // test_sdpparser();
  // return 0;

  /* initialize exosip (osip), transfer NULL pointer for address string
     if gateway address is not explicitly specified */
  if( g_gateway_int_network_ipv4_address[0]!='\0' )
    p_int_listen_addr = g_gateway_int_network_ipv4_address;

  if( g_gateway_ext_network_ipv4_address[0]!='\0' )
    p_ext_listen_addr = g_gateway_ext_network_ipv4_address;

  retcode = init_exosip( & pExtSipCtx, p_ext_listen_addr,
                         g_gateway_ext_sip_port, g_gateway_transport );
  if ( !retcode ) init_exosip( & pIntSipCtx, p_int_listen_addr,
                               g_gateway_int_sip_port, g_gateway_transport );
  if ( !retcode ) sdp_message_init( &ext_sdp );
  if ( !retcode ) sdp_message_init( &int_sdp );
  else
  {
    gw_error( "eXosip initialization error %d occured, exit!\n", retcode );
    return retcode;
  }

  /* set option EXOSIP_OPT_SET_IPV4_FOR_GATEWAY for correct contact address
     in SIP headers send to internal UE */
  if( g_gateway_int_network_ipv4_address[0]!='\0' )
  {
    eXosip_set_option( pIntSipCtx, EXOSIP_OPT_SET_IPV4_FOR_GATEWAY, g_gateway_int_network_ipv4_address );
    gw_message( "set option EXOSIP_OPT_SET_IPV4_FOR_GATEWAY to %s for internal UE\n",
                g_gateway_int_network_ipv4_address );
  }

  /* set option EXOSIP_OPT_SET_IPV4_FOR_GATEWAY for correct contact address
     in SIP headers send to external UE */
  if( g_gateway_ext_network_ipv4_address[0]!='\0' )
  {
    eXosip_set_option( pExtSipCtx, EXOSIP_OPT_SET_IPV4_FOR_GATEWAY, g_gateway_ext_network_ipv4_address );
    gw_message( "set option EXOSIP_OPT_SET_IPV4_FOR_GATEWAY to %s for external UE\n",
                g_gateway_ext_network_ipv4_address );
  }

  /* initialize PSTN instance */
  pIntPstnCtx = pstn_malloc();
  if( pIntPstnCtx == NULL )
  {
    gw_error( "out of memory while allocating PSTN data!\n" );
    return -1;
  }
  retcode = pstn_init( pIntPstnCtx );
  if( retcode )
  {
    gw_error( "PSTN initialization error %d occured, exit!\n", retcode );
    return retcode;
  }

  gw_message("transport layer successfully initialized, waiting for connections ...\n");


  /* event loop */
  for(;;)
  {
    retcode = 0;

    /* clean up memory */
    if( pExtSipEvt )
      eXosip_event_free( pExtSipEvt );

    if( pIntSipEvt )
      eXosip_event_free( pIntSipEvt );


    /* fetches all events from:
         - external SIP instance (smartphone headunit)
         - internal SIP instance VOICE gateway
         - int PSTN instance (GSM/UMTS/LTE modem)
     */
    pExtSipEvt = eXosip_event_wait (pExtSipCtx, 0, 50);
    pIntSipEvt = eXosip_event_wait (pIntSipCtx, 0, 50);
    pIntPstnEvt = pstn_get_event( pIntPstnCtx );


    if( pIntSipEvt )
    {
      gw_message("\n\n");
      gw_message("---------------------------------------------------------------------\n");
      gw_message("--- INT SIP EVT: (%d):%s,  STATE: (%d):%s ---\n",
                 pIntSipEvt->type, g_exosip_evt_type_name[pIntSipEvt->type],
                 sipGatewayState, g_gw_state_name[sipGatewayState] );
      gw_message("---------------------------------------------------------------------\n");
      gw_message("\n\n");
    }

    if( pExtSipEvt )
    {
      gw_message("\n\n");
      gw_message("---------------------------------------------------------------------\n");
      gw_message("--- EXT SIP EVT: (%d):%s,  STATE: (%d):%s ---\n",
                 pExtSipEvt->type, g_exosip_evt_type_name[pExtSipEvt->type],
                 sipGatewayState, g_gw_state_name[sipGatewayState] );
      gw_message("---------------------------------------------------------------------\n");
      gw_message("\n\n");
    }

    if( pIntPstnEvt )
    {
      gw_message("\n\n");
      gw_message("---------------------------------------------------------------------\n");
      gw_message("--- INT PSTN EVT: (%d):%s,  STATE: (%d):%s ---\n",
                 pIntPstnEvt->type, g_pstn_evt_type_name[pIntPstnEvt->type],
                 sipGatewayState, g_gw_state_name[sipGatewayState] );
      gw_message("---------------------------------------------------------------------\n");
      gw_message("\n\n");
    }

    /*
     * handle registration event for VOIP client (iOS/Android Linphone app)
     * this is required exclusively for the VOIP Demo!
     */
    if( pExtSipEvt && pExtSipEvt->type == EXOSIP_MESSAGE_NEW )
    {
      osip_contact_t *contact;

      gw_message("EXT: EXOSIP_MESSAGE_NEW\n");
      gw_message("EXT: %s\n", pExtSipEvt->textinfo);

      eXosip_lock(pExtSipCtx);
      retcode = eXosip_message_build_answer( pExtSipCtx, pExtSipEvt->tid, 200, &pExtSipAnswer );
      if( ! retcode )
        retcode = eXosip_message_send_answer( pExtSipCtx, pExtSipEvt->tid, 200, pExtSipAnswer );
      eXosip_unlock(pExtSipCtx);


      if( pExtSipEvt->request->sip_method &&
          strcmp(pExtSipEvt->request->sip_method, "REGISTER") == 0 )
      {
        if( g_gateway_use_dynamic_int_address )
        {
          gw_message( "registering new internal address: %s\n",
                  pExtSipEvt->request->req_uri->host );

          s_strlcpy( registered_int_addr, pExtSipEvt->request->req_uri->host, sizeof(registered_int_addr) );

          if( g_gateway_int_network_ipv4_address[0] != '\0' )
          {
            /* internal network for gateway specified, usually localhost.
               this is address is e.g. used within the from field for
               sip invite of internal UE */
            snprintf( gw_int_sip_addr, sizeof(gw_int_sip_addr), "sip:%s:%d",
                      g_gateway_int_network_ipv4_address, g_gateway_int_sip_port );
          }
          else
          {
            /* when gateway is not explicitly specified via config file then
               derive its contact address from the INVITE message */
            snprintf( gw_int_sip_addr, sizeof(gw_int_sip_addr), "sip:%s:%d",
                      registered_int_addr, g_gateway_int_sip_port );
          }

          if( g_linphone_int_sip_uri[0] != '\0' )
          {
            /* for internal VoIP UE (linphone) applies the same as for the
               given gateway application, use configuration if given */
            snprintf( ue_int_sip_addr, sizeof(ue_int_sip_addr), "sip:%s:%d",
                      g_linphone_int_sip_uri, g_linphone_int_sip_port );
          }
          else
          {
            /* otherwise it is assumed that linphone can be reached under
               the address which is accessed via registration */
            snprintf( ue_int_sip_addr, sizeof(ue_int_sip_addr), "sip:%s:%d",
                      registered_int_addr, g_linphone_int_sip_port );
          }
        }

        if( g_gateway_use_dynamic_ext_address )
        {
          contact = osip_list_get (&pExtSipEvt->request->contacts, 0);
          gw_message( "registering new external address: %s, port: %s\n",
                  contact->url->host,
                  contact->url->port );

          s_strlcpy( registered_ext_addr, contact->url->host, sizeof(registered_ext_addr) );

          if( contact->url->port )
          {
            registered_ext_sip_port = atoi( contact->url->port );

            if( registered_ext_sip_port < 1024 || registered_ext_sip_port > 65535 ) {
              registered_ext_sip_port = g_gateway_ext_sip_port;
            }
          }
          else
          {
            registered_ext_sip_port = g_gateway_ext_sip_port;
          }

          gw_message( "using port %d to address UE\n",
                      registered_ext_sip_port );
        }
      }
    }


    /*
     * Reset Handler
     *
     * A reset request  from modem which might be  required e.g. after
     * going to or coming from hybernation mode is handled outside the
     * state machine. This allows to  ensure that the sipgateway is in
     * initial state and generates error messages otherwise.
     */
    if( pIntPstnEvt && pIntPstnEvt->type == PSTN_CALL_RESET )
    {
      if( sipGatewayState == GW_STATE_TERMINATED )
      {
        gw_message( "received reset request, we are already in state TERMINATED" );
      }
      else
      {
        gw_error( "attention: received reset request outside state TERMINATED, call states will be terminated!" );

        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        eXosip_unlock(pIntSipCtx);

        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
        eXosip_unlock(pExtSipCtx);

        gw_error("switch to state terminated.\n");

        sipGatewayState = GW_STATE_TERMINATED;
      }

      /* process next event */
      continue;
    }


    /*
     * call state machine
     */
    switch( sipGatewayState )
    {

      /* ---------------------------------------------------------- */
    case GW_STATE_TERMINATED:
      /* ---------------------------------------------------------- */
      /*
       * we are in idle state. No call present yet!
       * In this state only events for incomming calls EXOSIP_CALL_INVITE
       * and PSTN_CALL_INVITE are relevant.
       */

      extSipCallEstablished  = 0;
      intSipCallEstablished  = 0;
      intPstnCallEstablished = 0;
      intPstnCallTriggered = 0;
      extSip_did = 0; /* did 0 seems to be default when call is not established */
      intSip_did = 0; /* so we initialize local state to this. */

      terminating_state_timeout_cnt = TERMINATING_STATE_TIMEOUT;
      proc_incoming_state_timeout_cnt = PROC_INCOMING_STATE_TIMEOUT;
      proc_outgoing_state_timeout_cnt = PROC_OUTGOING_STATE_TIMEOUT;

      if( pExtSipEvt && pExtSipEvt->type ==  EXOSIP_CALL_INVITE )
      {
        /*
         * incomming call from external SIP instance (Smartphone/Headunit)
         */
        extSip_tid = pExtSipEvt->tid;
        extSip_cid = pExtSipEvt->cid;
        extSip_did = pExtSipEvt->did;

        if( pExtSipEvt->request && pExtSipEvt->request->to->url->username )
        {
          s_strlcpy( phonenumber, pExtSipEvt->request->to->url->username, sizeof(phonenumber) );
        }
        else
        {
          phonenumber[0] = '\0';

          gw_error("no phone number given, decline SIP call and switch back to terminated state!\n");

          eXosip_lock(pExtSipCtx);
          retcode = eXosip_call_build_answer( pExtSipCtx, extSip_tid, 603, &pExtSipAnswer );
          if( ! retcode )
            retcode = eXosip_call_send_answer( pExtSipCtx, extSip_tid, 603, pExtSipAnswer );
          eXosip_unlock(pExtSipCtx);

          sipGatewayState = GW_STATE_TERMINATED;
          break;
        }

        gw_message("EXT: EXOSIP_CALL_INVITE\n");
        gw_message("received inite from external SIP instance, phone number: %s\n",
                   phonenumber );

        /* forward voice call to internal SIP instance */
        osip_message_to_str( pExtSipEvt->request, & p_msg_ext_str, &msg_ext_str_len );
        p_body_ext_str = sdp_get_content_ptr( p_msg_ext_str, msg_ext_str_len );
        if( ! p_body_ext_str )
          break;

        if( g_accept_only_gateway_ext_network_address && g_gateway_ext_network_ipv4_address[0]!='\0' )
        {
          gw_message("ipv4 address specified, check for matching inviation address!\n");
          if( cmp_ipv4_addr_strings( pExtSipEvt->request->req_uri->host,
                                     g_gateway_ext_network_ipv4_address ) != 0 )
          {
            gw_error("inivitation addr %s and gateway addr %s do not match error!\n",
                       pExtSipEvt->request->req_uri->host, g_gateway_ext_network_ipv4_address );

            gw_error("decline SIP call and switch back to terminated state!\n");
            eXosip_lock(pExtSipCtx);
            retcode = eXosip_call_build_answer( pExtSipCtx, extSip_tid, 603, &pExtSipAnswer );
            if( ! retcode )
              retcode = eXosip_call_send_answer( pExtSipCtx, extSip_tid, 603, pExtSipAnswer );
            eXosip_unlock(pExtSipCtx);

            sipGatewayState = GW_STATE_TERMINATED;
            break;
          }
          gw_message("invitation and gateway addresses match!\n");
        }


        retcode = sdp_get_sdp_uname_sessid_sessver( p_body_ext_str, sizeof(p_body_ext_str),
                                                    username, sizeof(username), &sess_id, &sess_version );

        if( g_gateway_transfer_media_attributes )
        {
          /* transfer media attributes from external caller (keys m= and a=) */
          retcode = sdp_transfer_media_attributes( ext_sdp_record, sizeof(ext_sdp_record), p_body_ext_str );
        }


        /* transfer ip addresses as in registration */
        if( g_gateway_transfer_ext_invite_address )
        {
          osip_contact_t *contact =  osip_list_get (&pExtSipEvt->request->contacts, 0);

          s_strlcpy( ue_ext_addr, contact->url->host, sizeof(ue_ext_addr) );
          s_strlcpy( ue_int_addr, pExtSipEvt->request->req_uri->host, sizeof(ue_int_addr) );

          if( g_enforce_linphone_int_addr )
          {
            /* address rewrite mechanism to allow internal VoIP UE (linphone)
               to run under localhost e.g. for security reasons */
            snprintf( ue_int_sip_addr, sizeof(ue_int_sip_addr), "sip:%s:%d",
                      g_linphone_int_network_ipv4_address, g_linphone_int_sip_port );
          }
          else
          {
            /* otherwise we forward to address from INVITE message and
               take exclusively over the SIP port from configuration */
            snprintf( ue_int_sip_addr, sizeof(ue_int_sip_addr), "sip:%s:%d",
                      ue_int_addr, g_linphone_int_sip_port );
          }

          gw_message( "Use INVITE address defintions for internal: %s, external: %s clients\n",
                      ue_int_addr, ue_ext_addr );
        }


        /* make sure that we get a new seesion */
        ++sess_id;
        ++sess_version;

        gw_message("connection id's: username=%s, sess-id=%d, sess-version=%d\n",
                   username, sess_id, sess_version );




        /*
         * invite internal UA (linphone)
         */
        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_build_initial_invite(
          pIntSipCtx,
          & pIntSipInvite,
          ue_int_sip_addr, /* to */
          gw_int_sip_addr, /* from */
          "",
          "Phone Call");
        eXosip_unlock(pIntSipCtx);

        if( retcode )
        {
          gw_error( "eXosip_call_build_initial_invite failed with error %d!\n", retcode);
          break;
        }

        if( g_gateway_transfer_ext_invite_address )
        {
          gw_message( "FOR SIP INVITE transfer external address: %s\n", ue_ext_addr );

          /*
           * FOR SIP INVITE to internal client (ATM)
           * SDP (C)->external (NBT evo)
           */
          retcode = sdp_set_sdp_c_address(ext_sdp_record, sizeof(ext_sdp_record), ue_ext_addr );
        }
        else
        {
          if( g_gateway_use_dynamic_ext_address )
          {
            /*
             * FOR SIP INVITE to internal client (ATM)
             * SDP (C)->external (NBT evo)
             */
            gw_message( "FOR SIP INVITE transfer REGISTERED external address: %s\n",
                        registered_ext_addr );

            retcode = sdp_set_sdp_c_address(ext_sdp_record, sizeof(ext_sdp_record), registered_ext_addr );
          }
        }

        retcode = sdp_set_sdp_uname_sessid_sessver( ext_sdp_record, sizeof(ext_sdp_record),
                                                    username, sess_id, sess_version );

        if( retcode )
        {
          gw_error( "Could not patch sdp record for internal invite error!\n" );
          break;
        }

        osip_message_set_body( pIntSipInvite, ext_sdp_record, strlen(ext_sdp_record) );
        osip_message_set_content_type( pIntSipInvite, "application/sdp" );

        eXosip_lock(pIntSipCtx);
        intSip_cid = eXosip_call_send_initial_invite(
          pIntSipCtx,
          pIntSipInvite);
        eXosip_unlock(pIntSipCtx);
        if( intSip_cid < 0 )
        {
          gw_error( "eXosip_call_send_initial_invite failed with error!\n", intSip_cid );
          break;
        }


        /*
         * send ringing indication as answer
         */
        eXosip_lock(pExtSipCtx);
        eXosip_call_send_answer( pExtSipCtx, pExtSipEvt->tid, 180, NULL );
        eXosip_unlock(pExtSipCtx);


        /* everything ok so switch gateway state to proceeding */
        sipGatewayState = GW_STATE_PROCEEDING_OUTGOING_CALL;
      }

      else if( pIntPstnEvt && pIntPstnEvt->type == PSTN_CALL_INVITE )
      {
        /* got a call from PSTN */

        s_strlcpy( phonenumber, pIntPstnEvt->number, sizeof(phonenumber) );
        gw_message("PSTN: GOT NEW CALL FROM NR: %s\n", phonenumber );

        /* trigger first internal linphone instance via unix domain
           socket respectively pipe connection to send an internal
           INVITE to the sipgateway. We can then handle the flow of
           events more or less symmetrical to the outgoing call. */

        retcode = linphone_call( gw_int_sip_addr );
        if( retcode )
        {
          gw_error( "Could not trigger internal linphone process for addr %s, stop call now!\n",
                    gw_int_sip_addr );
          retcode = pstn_terminate( pIntPstnCtx );

          sipGatewayState = GW_STATE_TERMINATED;
        }
      }
      else if( pIntPstnEvt && pIntPstnEvt->type == PSTN_CALL_TERMINATED )
      {
        /* in case the pstn call manager directly cancels a call after
        having initiated it, we cannot  inform the VoIP UAC (linphone)
        to end  this call  based on standard  SIP messages  since this
        call was established  outside the SIP protocol  (out of band).
        For this  reason we need  to trigger call termination  via the
        socket protocoll in  the same way as with INVITE.  In case the
        call is already in processing state on the VoIP UAC (linphone)
        we will  get the usual SIP  messages to end the  call, so this
        scenario should be covered as well. */
        gw_message("send out of band message 'terminate' to UAC linphone.\n");
        retcode = linphone_terminate();
      }
      else if( pIntSipEvt && pIntSipEvt->type ==  EXOSIP_CALL_INVITE )
      {
        /*
         * incomming call from internal SIP instance triggered via unix domain socket!
         */
        gw_message("INT: EXOSIP_CALL_INVITE\n");

        /*
         * send back ringing indication as answer
         */
        eXosip_lock(pIntSipCtx);
        eXosip_call_send_answer( pIntSipCtx, pIntSipEvt->tid, 180, NULL );
        eXosip_unlock(pIntSipCtx);

        /* forward voice call to external SIP instance */
        osip_message_to_str( pIntSipEvt->request, & p_msg_int_str, &msg_int_str_len );
        p_body_int_str = sdp_get_content_ptr( p_msg_int_str, msg_int_str_len );
        if( p_body_int_str )
        {
          intSip_tid = pIntSipEvt->tid;
          intSip_cid = pIntSipEvt->cid;
          intSip_did = pIntSipEvt->did;

          retcode = sdp_get_sdp_uname_sessid_sessver( p_body_int_str, sizeof(p_body_int_str),
            username, sizeof(username), &sess_id, &sess_version );

          if( g_gateway_transfer_media_attributes )
          {
            /* transfer media attributes from external caller (keys m= and a=) */
            retcode = sdp_transfer_media_attributes( int_sdp_record, sizeof(int_sdp_record), p_body_int_str );
          }

          if( g_gateway_use_dynamic_int_address )
          {
            if( g_enforce_linphone_int_addr )
            {
              /* careful: address rewriting applies exclusively for the SIP domain!
                          In case rewriting is enabled, we use the gateway address
                          for RTP where internal and extern VoIP UE must be on the
                          same network */
              gw_message( "FOR SIP INVITE transfer gateway address for RTP: %s\n",
                          g_gateway_ext_network_ipv4_address );

              retcode = sdp_set_sdp_c_address(
                int_sdp_record, sizeof(int_sdp_record), g_gateway_ext_network_ipv4_address );
              retcode = sdp_set_sdp_o_address(
                int_sdp_record, sizeof(int_sdp_record), g_gateway_ext_network_ipv4_address );
            }
            else
            {
              /*
               * FOR SIP INVITE to external client (NBT evo)
               * SDP (C)->external (NBT evo)
               */
              gw_message( "FOR SIP INVITE transfer registered internal address for RTP: %s\n",
                          registered_int_addr );

              retcode = sdp_set_sdp_c_address(
                int_sdp_record, sizeof(int_sdp_record), registered_int_addr );
              retcode = sdp_set_sdp_o_address(
                int_sdp_record, sizeof(int_sdp_record), registered_int_addr );
            }

            snprintf( ue_ext_sip_addr, sizeof(ue_ext_sip_addr), "sip:%s:%d",
                      registered_ext_addr, registered_ext_sip_port );
          }
          else
          {
            snprintf( ue_ext_sip_addr, sizeof(ue_ext_sip_addr), "sip:%s:%d",
                      g_gateway_ext_sip_uri, registered_ext_sip_port );
          }

          snprintf( gw_ext_sip_addr, sizeof(gw_ext_sip_addr), "sip:%s@%s:%d",
                    phonenumber, g_gateway_ext_network_ipv4_address, g_gateway_ext_sip_port );

          /* make sure that we get a new seesion */
          ++sess_id;
          ++sess_version;

          gw_message("connection id's: username=%s, sess-id=%d, sess-version=%d\n",
                 username, sess_id, sess_version );

          /* Invite external caller */
          gw_message("invite external caller from: %s, to: %s\n", gw_ext_sip_addr, ue_ext_sip_addr );

          eXosip_lock(pExtSipCtx);
          retcode = eXosip_call_build_initial_invite(
            pExtSipCtx,
            & pExtSipInvite,
            ue_ext_sip_addr, /* to */
            gw_ext_sip_addr, /* from */
            "",
            "Phone Call");
          eXosip_unlock(pExtSipCtx);

          if( retcode )
            gw_error( "eXosip_call_build_initial_invite failed with error %d!\n", retcode);

          if( retcode == 0)
          {
            retcode = sdp_set_sdp_uname_sessid_sessver(int_sdp_record, sizeof(int_sdp_record),
                                                       username, sess_id, sess_version );

            osip_message_set_body( pExtSipInvite, int_sdp_record, strlen(int_sdp_record) );
            osip_message_set_content_type( pExtSipInvite, "application/sdp" );

            eXosip_lock(pExtSipCtx);
            extSip_cid = eXosip_call_send_initial_invite(
              pExtSipCtx,
              pExtSipInvite);
            eXosip_unlock(pExtSipCtx);

            if( extSip_cid < 0 )
            {
              gw_error( "eXosip_call_send_initial_invite failed with error!\n", extSip_cid );
              retcode = -1;
            }
          }
        } /* if( p_body_int_str ) */
        else
        {
          gw_error("got malformed SDP record from internal UE error!\n");
          retcode = -1;
        }

        if( retcode == 0)
        {
          sipGatewayState = GW_STATE_PROCEEDING_INCOMING_CALL;
        }
        else
        {
          /* error occured so terminate all open connections */
          eXosip_lock(pIntSipCtx);
          retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
          gw_message("eXosip_call_terminate internal SIP for cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
          eXosip_unlock(pIntSipCtx);

          retcode = pstn_terminate( pIntPstnCtx );
        }
      }
      else if( pIntPstnEvt && pIntPstnEvt->type == PSTN_CALL_VOIP_LOOPBACK  ||  enable_voip_loopback )
      {
        /* ensure that loopback is enabled only once for startup flag */
        enable_voip_loopback = 0;

        /* voip loopback case */
        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_build_initial_invite(
          pIntSipCtx,
          & pIntSipInvite,
          ue_int_sip_addr, /* to */
          gw_int_sip_addr, /* from */
          "",
          "Phone Call");
        eXosip_unlock(pIntSipCtx);

        if( retcode )
        {
          gw_error( "eXosip_call_build_initial_invite failed with error %d!\n", retcode);
        }
        else
        {
          strcpy( username, "loopback" );
          sess_id = rand();
          sess_version = rand();

          retcode = sdp_set_sdp_uname_sessid_sessver(
            ext_sdp_record, sizeof(ext_sdp_record),
            username, sess_id, sess_version );

          if( retcode )
          {
            gw_error( "Could not patch sdp record for internal invite error!\n");
          }
          else
          {

            osip_message_set_body( pIntSipInvite, ext_sdp_record, strlen(ext_sdp_record) );
            osip_message_set_content_type( pIntSipInvite, "application/sdp" );

            eXosip_lock(pIntSipCtx);
            extSip_cid = eXosip_call_send_initial_invite(
              pIntSipCtx,
              pIntSipInvite);
            eXosip_unlock(pIntSipCtx);
            if( extSip_cid < 0 )
            {
              gw_error( "eXosip_call_send_initial_invite failed with error!\n", extSip_cid );
              retcode = -1;
            }
            else
            {
              sipGatewayState = GW_STATE_PROCEEDING_LOOPTHROUGH_CALL;
            }
          }
        }
      } /* else if( loopthrough ) */
      break; /* case GW_STATE_TERMINATED: */




      /* ---------------------------------------------------------- */
    case GW_STATE_PROCEEDING_INCOMING_CALL:
      /* ---------------------------------------------------------- */

      if( pExtSipEvt && ( pExtSipEvt->type == EXOSIP_CALL_PROCEEDING  || pExtSipEvt->type == EXOSIP_CALL_RINGING ) )
      {
        gw_message("got call proceeding resp. ringing, did: %d\n", pExtSipEvt->did );
        extSip_did = pExtSipEvt->did;
      }
      else if( pExtSipEvt && pExtSipEvt->type ==  EXOSIP_CALL_ANSWERED )
      {
        osip_message_to_str( pExtSipEvt->response, & p_msg_ext_str, &msg_ext_str_len );
        p_body_ext_str = sdp_get_content_ptr( p_msg_ext_str, msg_ext_str_len );

        if( g_gateway_transfer_media_attributes )
        {
          /* transfer media attributes from external invited client (keys m= and a=) */
          retcode = sdp_transfer_media_attributes( ext_sdp_record, sizeof(ext_sdp_record), p_body_ext_str );
        }

        /* transfer SDP connection address */
        retcode = sdp_get_sdp_c_address( p_body_ext_str, sizeof(p_body_ext_str), ue_ext_addr );

        /* send ack to external instance */
        eXosip_lock(pExtSipCtx);
        extSip_did = pExtSipEvt->did;
        retcode = eXosip_call_build_ack( pExtSipCtx, pExtSipEvt->did, &pExtSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_ack( pExtSipCtx, pExtSipEvt->did, pExtSipAnswer );
        eXosip_unlock(pExtSipCtx);

        if( ! retcode )
        {
          extSipCallEstablished = 1;
        }
        else
        {
          gw_error( "Error %d while building/sending ACK message to external SIP instance!\n", retcode );
        }

        /* send 200 OK to internal instance */
        retcode = sdp_set_sdp_uname_sessid_sessver(
          ext_sdp_record,
          sizeof(ext_sdp_record),
          username, sess_id, sess_version );

        if( g_gateway_use_dynamic_ext_address )
        {
          /*
           * FOR SIP 200 OK to internal client (ATM)
           * SDP (C)->external (NBT evo)
           * ATTENTION: Some UE's provide the wrong ip address e.g. linphone
           *            when hardware is equipped with two network cards. We
           *            use therefore the registration address.
           */
          gw_message( "FOR SIP 200 OK transfer external address (SDP): %s\n",
                  registered_ext_addr /* instead of: ue_ext_addr */ );

          retcode = sdp_set_sdp_c_address( ext_sdp_record, sizeof(ext_sdp_record),
                                           registered_ext_addr /* instead of: ue_ext_addr */ );
          retcode = sdp_set_sdp_o_address( ext_sdp_record, sizeof(ext_sdp_record),
                                           registered_ext_addr /* instead of: ue_ext_addr */ );
        }

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_build_answer( pIntSipCtx, intSip_tid, 200, &pIntSipAnswer );
        if( ! retcode )
        {
          retcode = osip_message_set_body( pIntSipAnswer, ext_sdp_record, strlen(ext_sdp_record) );
          osip_message_set_content_type( pIntSipAnswer, "application/sdp" );

          if( ! retcode )
            retcode = eXosip_call_send_answer( pIntSipCtx, intSip_tid, 200, pIntSipAnswer );
        }
        eXosip_unlock(pIntSipCtx);

        if( ! retcode )
        {
          intSipCallEstablished = 1;
        }
        else
        {
          gw_error( "Error %d while building/sending ACK message to internal SIP instance!\n", retcode );
        }


        /* trigger PSTN to accept incoming call now */
        retcode = pstn_answer( pIntPstnCtx );
        if( retcode )
        {
          gw_error( "Error %d when sending answer to PSTN instance!\n", retcode );
        }
        else
        {
          sipGatewayState = GW_STATE_COMPLETED;
        }
      }
      else if( pIntSipEvt &&
               ( pIntSipEvt->type==EXOSIP_CALL_CANCELLED ||
                 pIntSipEvt->type==EXOSIP_CALL_GLOBALFAILURE ||
                 pIntSipEvt->type==EXOSIP_CALL_REQUESTFAILURE ) )
      {
        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
        gw_message("eXosip_call_terminate external SIP for cid: %d, did: %d -> %d\n", extSip_cid, extSip_did, retcode );
        eXosip_unlock(pExtSipCtx);

        sipGatewayState = GW_STATE_TERMINATING;
      }
      else if( pExtSipEvt &&
               ( pExtSipEvt->type==EXOSIP_CALL_CANCELLED ||
                 pExtSipEvt->type==EXOSIP_CALL_GLOBALFAILURE ||
                 pExtSipEvt->type==EXOSIP_CALL_REQUESTFAILURE ) )
      {
        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        gw_message("eXosip_call_terminate for internal SIP cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
        eXosip_unlock(pIntSipCtx);

        sipGatewayState = GW_STATE_TERMINATING;
      }
      else if( pIntPstnEvt && pIntPstnEvt->type ==  PSTN_CALL_TERMINATED )
      {
        gw_message("PSTN: CALL DECLINED\n");

        /* ensure that internal VoIP call is terminated */
        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        gw_message("eXosip_call_terminate internal SIP for cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
        eXosip_unlock(pIntSipCtx);

        /* ensure that external VoIP call is terminated */
        eXosip_lock(pExtSipCtx);
        gw_message("eXosip_call_terminate external SIP for cid: %d, did: %d -> %d\n", extSip_cid, extSip_did, retcode );
        retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
        eXosip_unlock(pExtSipCtx);

        if( ! retcode )
        {
          gw_error( "error %d while building/sending decline to external SIP instance occured!\n", retcode );
        }

        sipGatewayState = GW_STATE_TERMINATED;
      }

      if( intSipCallEstablished && extSipCallEstablished )
      {
        /*
         * only when connection on both sides of the gateway are
         * established switch to completed state
         */
        sipGatewayState = GW_STATE_COMPLETED;
      }
      else if( ! proc_incoming_state_timeout_cnt-- )
      {
        gw_error("timeout of state proceeding incoming call experired, quit all open connections ...\n");
        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        eXosip_unlock(pIntSipCtx);

        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
        eXosip_unlock(pExtSipCtx);

        gw_error("switch to state terminated.\n");

        sipGatewayState = GW_STATE_TERMINATED;
      }
      break; /* GW_STATE_PROCEEDING_INCOMING_CALL: */






      /* ---------------------------------------------------------- */
    case GW_STATE_PROCEEDING_OUTGOING_CALL:
      /* ---------------------------------------------------------- */

      /*
       * PSTN still signals ringing and we are waiting for
       * the internal SIP instance to ANSWER to the INVITE message
       * we have just sent out. Since the internal SIP instance is
       * adjusted to auto answer mode this should happen
       * immediately.
       */

      if( pIntSipEvt && ( pIntSipEvt->type == EXOSIP_CALL_PROCEEDING  || pIntSipEvt->type == EXOSIP_CALL_RINGING ) )
      {
        gw_message("got call proceeding resp. ringing, did: %d\n", pIntSipEvt->did );
        intSip_did = pIntSipEvt->did;
      }
      else if( pIntSipEvt && pIntSipEvt->type ==  EXOSIP_CALL_ANSWERED )
      {
        /*
         * internal SIP instance has answered
         * signal external SIP instance that call has been established
         */

        gw_message("INT: EXOSIP_CALL_ANSWERED\n");

        osip_message_to_str( pIntSipEvt->response, & p_msg_int_str, &msg_int_str_len );
        p_body_int_str = sdp_get_content_ptr( p_msg_int_str, msg_int_str_len );
        if( g_gateway_transfer_media_attributes )
        {
          /* transfer media attributes from internal caller (keys m= and a=) */
          retcode = sdp_transfer_media_attributes( int_sdp_record, sizeof(int_sdp_record), p_body_int_str );
        }


        /* transfer SDP connect address */
        /* DON'T DO THAT DUE TO PROBLEMS WHEN USING MORE THAN ONE NETWORK!
        // retcode = sdp_get_sdp_c_address( p_body_int_str, sizeof(p_body_int_str), ue_int_addr );
        */

        /* send ack to internal instance */
        eXosip_lock(pIntSipCtx);
        intSip_did = pIntSipEvt->did;
        retcode = eXosip_call_build_ack( pIntSipCtx, pIntSipEvt->did, &pIntSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_ack( pIntSipCtx, pIntSipEvt->did, pIntSipAnswer );
        eXosip_unlock(pIntSipCtx);

        if( ! retcode )
        {
          intSipCallEstablished = 1;
        }
        else
        {
          gw_error( "Error %d while building/sending ack to internal SIP instance!\n", retcode );
        }


        retcode = sdp_set_sdp_uname_sessid_sessver( int_sdp_record, sizeof(int_sdp_record),
                                                    username, sess_id, sess_version );

        if( g_gateway_use_dynamic_int_address )
        {
          /*
           * FOR SIP 200 OK to external client (NBT evo)
           * SDP (C)->internal (ATM) received from linphone's 200 OK message
           */
          gw_message( "FOR SIP 200 OK transfer internal address (SDP): %s\n",
                  ue_int_addr );
          retcode = sdp_set_sdp_c_address( int_sdp_record, sizeof(int_sdp_record), ue_int_addr );
          retcode = sdp_set_sdp_o_address( int_sdp_record, sizeof(int_sdp_record), ue_ext_addr );
        }

        if( retcode )
        {
          gw_error( "Error %d while patching internal sdp record\n", retcode );
          sipGatewayState = GW_STATE_TERMINATED;
          break;
        }

        extSipCallEstablished = 1;

        /*
         * initiate dialing sequence to public switched telephone network
         * via GSM/UMTS/LTE
         */
        gw_message("dialing phone number %s ...\n", phonenumber );
        retcode = pstn_call( pIntPstnCtx, phonenumber );
        if( retcode )
        {
          gw_error( "Error %d while trying to establish pstn call to %s, terminating SIP call!\n",
                    retcode, phonenumber );

          eXosip_lock(pIntSipCtx);
          retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
          gw_message("eXosip_call_terminate internal SIP for cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
          eXosip_unlock(pIntSipCtx);

          eXosip_lock(pExtSipCtx);
          retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
          gw_message("eXosip_call_terminate external SIP for cid: %d, did: %d -> %d\n", extSip_cid, extSip_did, retcode );
          eXosip_unlock(pExtSipCtx);

          sipGatewayState = GW_STATE_TERMINATED;
          break;
        }
        intPstnCallTriggered = 1;
      }
      else if( pIntSipEvt && ( pIntSipEvt->type==EXOSIP_CALL_CANCELLED || pIntSipEvt->type==EXOSIP_CALL_GLOBALFAILURE ) )
      {
        if( intPstnCallEstablished || intPstnCallTriggered )
        {
          retcode = pstn_terminate( pIntPstnCtx );
          sipGatewayState = GW_STATE_TERMINATING;
        }
        else
        {
          sipGatewayState = GW_STATE_TERMINATED;
        }

      }

      /*
       * We are now waiting for outgoing call to be accepted or to
       * get a busy indication.
       */
      if( pIntPstnEvt &&
          ( pIntPstnEvt->type ==  PSTN_CALL_COMPLETED || pIntPstnEvt->type ==  PSTN_CALL_ALERTING ) &&
          !intPstnCallEstablished )
      {
        /*
         * PSTN has signaled call completion
         * inform internal SIP instance and trigger state transition
         */
        intPstnCallEstablished = 1;

        if( pIntPstnEvt->type == PSTN_CALL_COMPLETED )
          gw_message("Got PSTN_CALL_COMPLETED, send ACK to external UA.\n");
        else
          gw_message("Got PSTN_CALL_ALERTING, send ACK to external UA for early media establishment.\n");

        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_build_answer( pExtSipCtx, extSip_tid, 200, &pExtSipAnswer );
        if( ! retcode )
        {
          retcode = osip_message_set_body( pExtSipAnswer, int_sdp_record, strlen(int_sdp_record) );
          osip_message_set_content_type( pExtSipAnswer, "application/sdp" );
          if( ! retcode )
            retcode = eXosip_call_send_answer( pExtSipCtx, extSip_tid, 200, pExtSipAnswer );
        }
        eXosip_unlock(pExtSipCtx);
      }
      else if( pIntPstnEvt && pIntPstnEvt->type ==  PSTN_CALL_BUSY )
      {
        gw_message("PSTN: CALL BUSY\n");

        /*
         * PSTN line is busy
         * we inform external SIP instance about it but this by sending busy everywhere
         */
        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_build_answer( pExtSipCtx, extSip_tid, 600, &pExtSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_answer( pExtSipCtx, extSip_tid, 600, pExtSipAnswer );
        eXosip_unlock(pExtSipCtx);

        if( retcode )
        {
          gw_error( "error %d while building/sending answer to external SIP instance occured!\n", retcode );
        }

        /* ensure that internal VoIP call is terminated */
        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        gw_message("eXosip_call_terminate internal SIP for cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
        eXosip_unlock(pIntSipCtx);

        sipGatewayState = GW_STATE_TERMINATED;
      }
      else if( pIntPstnEvt && pIntPstnEvt->type ==  PSTN_CALL_TERMINATED )
      {
        gw_message("PSTN: CALL DECLINED\n");

        /* ensure that internal VoIP call is terminated */
        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        gw_message("eXosip_call_terminate internal SIP for cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
        eXosip_unlock(pIntSipCtx);

        /*
         * PSTN rejected to setup call so send the response code 603 Decline
         */
        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_build_answer( pExtSipCtx, extSip_tid, 603, &pExtSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_answer( pExtSipCtx, extSip_tid, 603, pExtSipAnswer );
        eXosip_unlock(pExtSipCtx);

        if( retcode )
        {
          gw_error( "error %d while building/sending answer to external SIP instance occured!\n", retcode );
        }

        sipGatewayState = GW_STATE_TERMINATED;
      }
      else if( pExtSipEvt && pExtSipEvt->type ==  EXOSIP_CALL_INVITE )
      {
        /* not allowed here, so send 603 Decline */
        gw_message( "Got more than one INVITE message so decline the last one \n" );
        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_build_answer( pExtSipCtx, pExtSipEvt->tid, 603, &pExtSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_answer( pExtSipCtx, pExtSipEvt->tid, 603, pExtSipAnswer );
        eXosip_unlock(pExtSipCtx);
      }

      if( pExtSipEvt && pExtSipEvt->type == EXOSIP_CALL_CANCELLED )
      {
        /* ensure that internal VoIP call is terminated */
        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        gw_message("eXosip_call_terminate internal SIP for cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
        eXosip_unlock(pIntSipCtx);

        /*
         * external SIP (Smartphone, Headunit, etc) canceled call
         * e.g. after having received BUSY
         * inform internal SIP instance about it and switch to
         * TERMINATED state.
         */
        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, 0 );
        eXosip_unlock(pIntSipCtx);

        if( intPstnCallTriggered )
          sipGatewayState = GW_STATE_TERMINATING;
        else
          sipGatewayState = GW_STATE_TERMINATED;
      }

      if( intSipCallEstablished && intPstnCallEstablished )
      {
        /*
         * only when connection on both sides of the gateway are
         * established switch to completed state
         */
        sipGatewayState = GW_STATE_COMPLETED;
      }
      else if( ! proc_outgoing_state_timeout_cnt-- )
      {
        gw_error("timeout of state proceeding outgoing call experired, quit all open connections ...\n");
        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        eXosip_unlock(pIntSipCtx);

        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
        eXosip_unlock(pExtSipCtx);

        gw_error("switch to state terminated.\n");

        sipGatewayState = GW_STATE_TERMINATED;
      }
      break; /* GW_STATE_PROCEEDING_OUTGOING_CALL: */




      /* ---------------------------------------------------------- */
    case GW_STATE_PROCEEDING_LOOPTHROUGH_CALL:
      /* ---------------------------------------------------------- */

      if( pIntSipEvt && pIntSipEvt->type ==  EXOSIP_CALL_ANSWERED )
      {
        /*
         * internal SIP instance has answered to loopback request
         */

        gw_message("INT: EXOSIP_CALL_ANSWERED (loopback case)\n");

        /* send ack  */
        eXosip_lock(pIntSipCtx);
        extSip_did = pIntSipEvt->did;
        retcode = eXosip_call_build_ack( pIntSipCtx, pIntSipEvt->did, &pIntSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_ack( pIntSipCtx, pIntSipEvt->did, pIntSipAnswer );
        eXosip_unlock(pIntSipCtx);

        if( ! retcode )
        {
          intSipCallEstablished = 1;
        }
        else
        {
          gw_error( "Error %d while building/sending ACK message to external SIP instance!\n", retcode );
        }

        sipGatewayState = GW_STATE_COMPLETED;
      }
      break;



      /* ---------------------------------------------------------- */
    case GW_STATE_COMPLETED:
      /* ---------------------------------------------------------- */
      if( ( pExtSipEvt && pExtSipEvt->type == EXOSIP_CALL_CLOSED ) ||
          ( pIntSipEvt && pIntSipEvt->type == EXOSIP_CALL_CLOSED ) )
      {
        /*
         * external SIP instance (Smartphone, Headunit) or internal linphone client hanged up
         * the later case normally shall not happen but can occur e.g. in case of IP connnection
         * loss.
         * inform PSTN about it (e.g. AT+CUPS) and switch to TERMINATED state
         */
        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        gw_message("eXosip_call_terminate internal SIP for cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
        eXosip_unlock(pIntSipCtx);

        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
        gw_message("eXosip_call_terminate external SIP for cid: %d, did: %d -> %d\n", extSip_cid, extSip_did, retcode );
        eXosip_unlock(pExtSipCtx);

        sipGatewayState = GW_STATE_TERMINATING;
      }
      else if( pIntPstnEvt && pIntPstnEvt->type ==  PSTN_CALL_TERMINATED )
      {
        /*
         * internal PST instance (GSM/UTMS/LTE) modem hanged up
         * inform internal SIP instance about it and switch to TERMINATED
         * state
         */
        if( intSipCallEstablished )
        {
          eXosip_lock(pIntSipCtx);
          retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
          gw_message("eXosip_call_terminate for internal SIP cid: %d, did: %d -> %d\n", intSip_cid, intSip_did, retcode );
          if( retcode )
          {
            /* in loopback mode we have invited the internal instances in a weird way
               which we cannot terminated easily. Maybe this is because we are not
               serving the transport protocol. Nevertheless when we cannot finish
               the call the SIP way we use the socket control to enforce it! */
            retcode = linphone_terminate();
          }
          eXosip_unlock(pIntSipCtx);
        }

        if( extSipCallEstablished )
        {
          eXosip_lock(pExtSipCtx);
          retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
          gw_message("eXosip_call_terminate external SIP for cid: %d, did: %d -> %d\n", extSip_cid, extSip_did, retcode );
          eXosip_unlock(pExtSipCtx);
        }

        sipGatewayState = GW_STATE_TERMINATED;
      }
      else if( pExtSipEvt && pExtSipEvt->type ==  EXOSIP_CALL_INVITE )
      {
        /* not allowed here, so send 603 Decline */
        gw_message( "Got INVITE message within an open call. We send a 603 Decline mesage as answer and hang up\n" );
        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_build_answer( pExtSipCtx, pExtSipEvt->tid, 603, &pExtSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_answer( pExtSipCtx, pExtSipEvt->tid, 603, pExtSipAnswer );
        eXosip_unlock(pExtSipCtx);

        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        eXosip_unlock(pIntSipCtx);

        sipGatewayState = GW_STATE_TERMINATED;
      }
      break; /* GW_STATE_COMPLETED: */


      /* ---------------------------------------------------------- */
    case GW_STATE_TERMINATING:
      /* ---------------------------------------------------------- */
      if( pIntPstnEvt && pIntPstnEvt->type ==  PSTN_CALL_TERMINATED )
      {
        /* helper state to ensure only one active pstn call. This
           requires to switch into TERMINATED state not till then
           we have received the indication that the modem has infact
           terminated the voice call. Otherwise a new SIP INIVTE
           could be processed without the modem to be ready to
           establish a new call. */
        gw_message("Received TERMINATED event from modem, switch to TERMINATED state ...\n");
        sipGatewayState = GW_STATE_TERMINATED;
        break;
      }
      else if( pExtSipEvt && pExtSipEvt->type ==  EXOSIP_CALL_INVITE )
      {
        /* not allowed here, so send 603 Decline */
        gw_message( "Got INVITE message within an open call. We send a 603 Decline mesage as answer and hang up\n" );
        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_build_answer( pExtSipCtx, pExtSipEvt->tid, 603, &pExtSipAnswer );
        if( ! retcode )
          retcode = eXosip_call_send_answer( pExtSipCtx, pExtSipEvt->tid, 603, pExtSipAnswer );
        eXosip_unlock(pExtSipCtx);
      }

      /*
       * scaredy cat state transission to idle
       * just to avoid that we stay forever in this temporary state.
       */
      if( ! (terminating_state_timeout_cnt % 10) )
      {
        gw_message("will leave terminating state in %d seconds ...\n",
                   terminating_state_timeout_cnt/10 );
      }

      if( ! terminating_state_timeout_cnt-- )
      {
        gw_message("terminating timeout experired, try to quit all open connections ...\n");

        retcode = pstn_terminate( pIntPstnCtx );

        eXosip_lock(pIntSipCtx);
        retcode = eXosip_call_terminate( pIntSipCtx, intSip_cid, intSip_did );
        eXosip_unlock(pIntSipCtx);

        eXosip_lock(pExtSipCtx);
        retcode = eXosip_call_terminate( pExtSipCtx, extSip_cid, extSip_did );
        eXosip_unlock(pExtSipCtx);

        gw_message("switch to state terminated.\n");

        sipGatewayState = GW_STATE_TERMINATED;
      }
      break;


      /* ---------------------------------------------------------- */
    case GW_STATE_ECALL:
      /* ---------------------------------------------------------- */
      /*
       * not implemented yet
       */
      break;



    default:
      /* just to make lint happier */
      break;
    } /* switch( sipGatewayState ) */


  } /* for(;;) */


  /*
   * release handles
   */
  eXosip_quit(pExtSipCtx);
  eXosip_quit(pIntSipCtx);
  pstn_release(pIntPstnCtx);

  return 0;
}
