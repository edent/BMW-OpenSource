/*
 * string manipulation utilies
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 */

#ifndef STRUTILS_H
#define STRUTILS_H

/*!
 * transforms buffer to lower case letters
 */
void strtolower( char *p, const int max_len );


 /*!
  * helper function for removing carriage return / linefeed charaters,
  * replace tabulators by space, etc.
 */
void condition_string( char *p, const int max_len );


/*!
 * helper function to compare to ip v4 address strings
 * return 0 when both ip v4 strings are equal
 */
int cmp_ipv4_addr_strings( const char *p1, const char *p2 );


/*!
 * s_strlcpy -- size-bounded string copying and concatenation
 *
 * for more detailed information refer to: bsd man page strlcpy
 *
 * taken from:
 *   http://stackoverflow.com/questions/2933725/my-version-of-strlcpy
 */
size_t s_strlcpy(char *dest, const char *src, size_t len);

#endif /* #ifndef STRUTILS_H */
