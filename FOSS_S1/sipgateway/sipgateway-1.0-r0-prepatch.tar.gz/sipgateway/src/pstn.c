/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Interface to Public Telephone Switched Network (PSTN)
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>
#include <unistd.h>
#include <pthread.h>

#include <pstnparser.h>
#include <gw_config.h>


#define MAX_TRY_BIND_TO_CRTL 200
#define TRY_BIND_AFTER_SECS  3

static void pstn_enqueue_evt( tPstn* p, char* str )
{
  tPstnEvt   evt;
  tPstnEvt*  pEvt;

  evt.pCtx = p;
  if( ! pstn_parse( &evt, str ) )
  {
    pthread_mutex_lock( & p->mutex );

    if ( !IsListEmpty( & p->pool ) )
    {
      gw_message("create event from pool\n");
      pEvt = (tPstnEvt *)RemoveHeadList( & p->pool );
    }
    else
    {
      gw_message("create event from ready list\n");
      pEvt = (tPstnEvt *)RemoveHeadList( & p->readyList );
    }

    memcpy( pEvt, &evt, sizeof(tPstnEvt) );
    InsertTailList( & p->readyList, & pEvt->node);

    pthread_mutex_unlock( & p->mutex );
  }
}


/*!
 * event loop running within a separate thread
 * waits for new data on socket interface to external PSTN instance
 * when data is available parse and generate a new PSTN event
 */
static void* pstn_socket_event_loop( void* pCtx )
{
  tPstn* p = (tPstn *) pCtx;
  struct sockaddr_un uds_address;
  struct sockaddr_in inet_address;
  struct sockaddr* addr_ptr;
  int socket_listen_fd, nbytes;
  const int buffer_len = 256;
  char buffer[buffer_len];
  socklen_t addrlen;
  ssize_t size;
  int retry_bind = 0;
  int bind_cnt = MAX_TRY_BIND_TO_CRTL;
  int retcode;


  if( g_pstn_crtl_port < 0 )
  {
    /* bind to unix domain socket */
    socket_listen_fd = socket(PF_UNIX, SOCK_STREAM, 0);
    if(socket_listen_fd < 0)
    {
      gw_error( "control socket creation failed\n");
      p->event_loop_error = socket_listen_fd;
      return( & p->event_loop_error );
    }

    /* start with clean uds_address struture */
    memset( &uds_address, 0, sizeof(struct sockaddr_un));
    uds_address.sun_family = AF_UNIX;
    snprintf(uds_address.sun_path, 108, UDS_FILE);
    addr_ptr = (struct sockaddr *) &uds_address;

    unlink(UDS_FILE);

    retcode = bind( socket_listen_fd, addr_ptr, sizeof(struct sockaddr_un));
  }
  else
  {
    /* bind to tcp socket */
    int y;

    socket_listen_fd = socket(AF_INET, SOCK_STREAM, 0);
    if(socket_listen_fd < 0)
    {
      gw_error( "control socket creation failed\n");
      p->event_loop_error = socket_listen_fd;
      return( & p->event_loop_error );
    }

    /* start with clean uds_address struture */
    memset( &inet_address, 0, sizeof(struct sockaddr_in));
    inet_address.sin_family = AF_INET;
    inet_address.sin_addr.s_addr = htonl(INADDR_ANY);
    inet_address.sin_port = htons( g_pstn_crtl_port );
    addr_ptr = (struct sockaddr *) &inet_address;

    setsockopt( socket_listen_fd, SOL_SOCKET, SO_REUSEADDR, &y, sizeof(int));
    do {
      char errstr[50];
      retcode = bind( socket_listen_fd, addr_ptr, sizeof(struct sockaddr_in));
      if( retcode && bind_cnt-- > 0 )
      {
        retry_bind = 1;
        strerror_r( abs(retcode), errstr, sizeof(errstr) );
        gw_message("error (%d): '%.50s' when binding to crtl socket occurred, try again ...\n",
                   retcode, errstr );
        sleep( TRY_BIND_AFTER_SECS );
      }
      else
      {
        retry_bind = 0;
      }
    } while( retry_bind );
  }

  if( retcode )
  {
    gw_error( "bind to control socket failed with error %d\n", retcode );
    p->event_loop_error = retcode;
    return( & p->event_loop_error );
  }

  retcode = listen( socket_listen_fd, 5 );
  if( retcode )
  {
    gw_error( "error %d while listening to control socket!\n", retcode );
    p->event_loop_error = retcode;
    return( & p->event_loop_error );
  }

  addrlen = sizeof( struct sockaddr );

  /* incoming event loop */
  while( 1 )
  {
    gw_message("start listening to control port ...\n");
    p->socket_connect_fd = accept( socket_listen_fd, addr_ptr, &addrlen );
    if( p->socket_connect_fd > 0 )
    {
      gw_message("client is connected to control socket!\n");
      do {
        size = recv( p->socket_connect_fd, buffer, buffer_len - 1, 0 );
        if( size > 0 )
        {
          buffer[size]= '\0';
          pstn_enqueue_evt( p, buffer );

#ifdef TEST
          gw_message( "received message and send it back: %s\n", buffer );
          if( strncmp( buffer, "print", 5 ) == 0 )
          {
            tPstnEvt*  evt;

            gw_message("===== Enqued Events ====\n");
            while( (evt = pstn_get_event(p)) != NULL )
            {
              gw_message("-->%s\n", evt->number );
            }
          }
          send( p->socket_connect_fd, buffer, size, 0 );
#endif /* #ifdef TEST */
        }
        else
        {
          gw_error( "socket stream broke!\n");
          break;
        }
      } while ( 1 ); /* forever */
      close( p->socket_connect_fd );
      p->socket_connect_fd = -1;
    } /* if( socket_connect_fd > 0 ) */
  } /* while( 1 ) */

  close( socket_listen_fd );
  p->event_loop_error = retcode;
  return( & p->event_loop_error );
}


/*!
 * allocate memory for PSTN internal state struct
 */
tPstn* pstn_malloc (void)
{
  tPstn* ptr = (tPstn*) malloc( sizeof(tPstn) );

  if (ptr)
    memset (ptr, 0, sizeof(tPstn) );
  return ptr;
}


/*!
 * initialize PSTN internal state struct
 */
int pstn_init (tPstn* p)
{
  int i;
  int retcode = PSTN_SUCCESS;

  if( pthread_mutex_init( &p->mutex, 0 ) != 0 )
  {
    gw_error( "Allocation of mutex failed!\n" );
    return -1;
  }

  /* initialize pool an ready ring buffers */
  InitializeListHead( & p->pool );
  InitializeListHead( & p->readyList );
  for (i = 0; i < PSTN_EVT_QUEUE_SIZE; i++)
  {
    /* p->evtBlock[i].pData = & p->pPcmDataHeap[ i * DATA_SIZE ]; */
    InsertTailList( & p->pool, & p->evtBlock[i].node );
  }

  retcode = pthread_create( &p->evtLoopThread, NULL, pstn_socket_event_loop, p );
  if( retcode )
    gw_error( "pthread_create in event loop failed with error %d\n", retcode );
  else
  {
    retcode =  pthread_detach(p->evtLoopThread);
    if( retcode )
      gw_error( "pthread_detach in event loop failed with error %d\n", retcode );
  }

  return retcode;
}

/*!
 * frees PSTN internal used memory
 */
void pstn_release(tPstn* p)
{
  if( p != NULL )
  {
    pthread_cancel( p->evtLoopThread );
    pthread_mutex_destroy( &p->mutex );
    free( p );
  }
}

/*!
 * fetches event from PSTN. Waits max tv_s seconds, tv_ms miliseconds
 * returns pointer to event or NULL if no event is present
 */
tPstnEvt* pstn_get_event( tPstn* p )
{
  pthread_mutex_lock( & p->mutex );

  /* put already processed event back in pool */
  if( p->pCurrentEvent )
  {
    InsertTailList( & p->pool, & p->pCurrentEvent->node);
  }

  if ( !IsListEmpty( & p->readyList ) )
    p->pCurrentEvent = (tPstnEvt *)RemoveHeadList( & p->readyList );
  else
    p->pCurrentEvent = NULL;

  pthread_mutex_unlock( & p->mutex );

  return p->pCurrentEvent;
}


/*!
 * initiate dialing to PSTN with given phone number
 */
int pstn_call( tPstn* p, char* pNumber )
{
  char cmdBuf[100];

  gw_message( "send pstn command %s %s\n", PSTN_CMD_CALL, pNumber );

  snprintf( cmdBuf, sizeof( cmdBuf ), "%s %s\n", PSTN_CMD_CALL, pNumber );
  send( p->socket_connect_fd, cmdBuf, strlen(cmdBuf), 0 );

  return 0;
}


/*!
 * answer incoming call from PSTN
 */
int pstn_answer( tPstn* p )
{
  char cmdBuf[100];

  gw_message( "send pstn command %s\n", PSTN_CMD_ANSWER );

  snprintf( cmdBuf, sizeof( cmdBuf ), "%s\n", PSTN_CMD_ANSWER );
  send( p->socket_connect_fd, cmdBuf, strlen(cmdBuf), 0 );

  return 0;
}


/*!
 * answer terminate call from PSTN
 */
int pstn_terminate( tPstn* p )
{
  char cmdBuf[100];

  gw_message( "send pstn command %s\n", PSTN_CMD_TERMINATE );

  snprintf( cmdBuf, sizeof( cmdBuf ), "%s\n", PSTN_CMD_TERMINATE );
  send( p->socket_connect_fd, cmdBuf, strlen(cmdBuf), 0 );

  return 0;
}
