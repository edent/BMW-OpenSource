/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Parser for Session Description Protocol Data (SDP)
 */

#ifndef SDPPARSER_H
#define SDPPARSER_H

/*
 * maximum length of internally used IP addresses (SIP, TCP, ...)
 */
#define SDP_MAX_INET_ADDR_LEN  128


/*
 * stringify macro expanded argument e.g. XSTR(MYLEN) "3" with MYLEN=3
 */
#define XSTR(s) STR(s)


/*
 * stringify argument e.g. XSTR(MYLEN) "MYLEN"
 */
#define STR(s) #s



/*
 * separate SIP message body from header
 */
char* sdp_get_content_ptr( char *msg, int max_len );


/*
 * retrieves sdp entity for given key according to specifier in format string
 * according to the specification in scanf.
 */
int sdp_get_entities( const char* str, const int maxStrLen, const char* keyStr, const char* format, ... );


/*
 * set sdp entity for given key according to specifier in format string
 * according to the specification in scanf.
 */
int sdp_set_entities( char* str, const int maxStrLen, const char* keyStr, const char* format, ... );


/*
 * transfers all media attributes (keys m, a) from SDP record
 * (SIP message body string) from source to destination
 */
int sdp_transfer_media_attributes( char *dest, const int max_size_dest, const char *source );


/*!
 *  transfer connection address from SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry c=IN IP4 192.168.0.120
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: result address, in the exmample above 192.168.0.120
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_get_sdp_c_address( const char* sdp_str, const int sdp_str_len, char* addr );


/*!
 *  transfer connection address to SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry c=
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: connection address to be set
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_set_sdp_c_address( char* sdp_str, const int sdp_str_len, const char* addr );


/*!
 *  transfer origin address from SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry ol * * IN IP4 linphone.intern
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: result address, in the exmample above linhone.intern
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_get_sdp_o_address( const char* sdp_str, const int sdp_str_len, char* addr );


/*!
 *  transfer origin address to SDP record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry o=
 *    - sdp_str_len: max. length of the SDP record
 *    - addr: origin address to be set
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_set_sdp_o_address( char* sdp_str, const int sdp_str_len, const char* addr );


/*!
 *  transfer user name, session id and session version from sdp record
 *
 *  Function parameters
 *    - sdp_str: SDP record e.g. with entry ol * * IN IP4 linphone.intern
 *    - sdp_str_len: max. length of the SDP record
 *    - uname: extracted username
 *    - uname_len: maximum length of username string
 *    - sess_id: extracted session id
 *    - sess_ver: extracted session version
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_get_sdp_uname_sessid_sessver(
  const char* sdp_str,
  const int sdp_str_len,
  char* uname,
  const int uname_len,
  int* sess_id,
  int* sess_ver );


/*!
 *  transfer user name, session id and session version to sdp record
 *
 *  Function parameters
 *    - sdp_str: SDP record
 *    - sdp_str_len: max. length of the SDP record
 *    - uname: transfered username
 *    - uname_len: maximum length of username string
 *    - sess_id: transfered session id
 *    - sess_ver: transfered session version
 *
 *  Returnparameter
 *    - error code or 0 in case of success
 */
int sdp_set_sdp_uname_sessid_sessver(
  char* sdp_str,
  const int sdp_str_len,
  const char* uname,
  const int sess_id,
  const int sess_ver );



/*
 *  usage illustration
 */
int test_sdpparser(void);


#endif /* #ifndef SDPPARSER_H */
