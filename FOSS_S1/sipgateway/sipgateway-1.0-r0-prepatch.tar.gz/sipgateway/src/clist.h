/*
 * Circular List List Manipulation Utilities
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 */

#ifndef CLIST_H
#define CLIST_H

#include <stdint.h>

#define TRUE 1
#define FALSE 0
typedef int BOOL;

void OS_Assert(const char *expression, const char *file, int line);

#ifdef DEBUG
/* A define to convert asserts to OS_Assert calls */
# define Assert(exp)  (((exp) != 0) ? (void)0 : OS_Assert(#exp,__FILE__,(int)__LINE__))
#else
# define Assert(ex) (void)0
#endif


/*---------------------------------------------------------------------------
 *
 * ListEntry is for creating doubly linked circular lists. They can be used as
 * either a list head, or as part of another structure to allow that
 * structure to be a link node.
 */
#ifndef LISTS_DEFINED
#define LISTS_DEFINED

typedef struct  _ListEntry
{
    struct _ListEntry *Flink;
    struct _ListEntry *Blink;

} ListEntry;
#endif

/****************************************************************************
 *
 * Functions and Macros Reference.
 *
 ****************************************************************************/

/*---------------------------------------------------------------------------
 *
 *  Doubly-linked list manipulation routines.  Some are implemented as
 *  macros but logically are procedures.
 */

#define InitializeListHead(ListHead) (\
    (ListHead)->Flink = (ListHead)->Blink = (ListHead) )

#define InitializeListEntry(Entry) (\
    (Entry)->Flink = (Entry)->Blink = 0 )

#define IsEntryAvailable(Entry) (\
    ((Entry)->Flink == 0))

#define IsListEmpty(ListHead) (\
    ((ListHead)->Flink == (ListHead)))

#define GetHeadList(ListHead) (ListHead)->Flink

#define GetTailList(ListHead) (ListHead)->Blink

#define GetNextNode(Node)     (Node)->Flink

#define IsNodeConnected(n) (((n)->Blink->Flink == (n)) && ((n)->Flink->Blink == (n)))

void _InsertTailList(ListEntry* head, ListEntry* entry);
#define InsertTailList(a, b) (Assert(IsListCircular(a)), \
                            _InsertTailList(a, b), \
                            Assert(IsListCircular(a)))

void _InsertHeadList(ListEntry* head, ListEntry* entry);
#define InsertHeadList(a, b) (Assert(IsListCircular(a)), \
                            _InsertHeadList(a, b), \
                            Assert(IsListCircular(a)))

ListEntry* _RemoveHeadList(ListEntry* head);
#define RemoveHeadList(a) (Assert(IsListCircular(a)), \
                            _RemoveHeadList(a))

void RemoveEntryList(ListEntry* entry);
BOOL IsNodeOnList(ListEntry* head, ListEntry* node);
BOOL IsListCircular(ListEntry* list);
void MoveList(ListEntry* dest, ListEntry* src);

#endif /* #ifndef CLIST_H */
