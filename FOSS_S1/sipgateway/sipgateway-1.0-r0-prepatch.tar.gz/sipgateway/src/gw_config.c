/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Handling of configuration data
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <pwd.h>
#include <gw_config.h>
#include <strutils.h>
#include <sdpparser.h>
#include <netinet/ip.h>


/*!
 * SDP record of internal linphone instance whose audio
 * interfaces are bound to the PSTN network e.g. via
 * a GSM/UMTS/LTE modem.
 *
 * The given values are just an example. They are over-
 * written during intial configuration.
 */
char int_sdp_record[SDP_RECORD_SIZE] =
  "v=0\r\n"
  "o=ol * * IN IP4 192.168.1.117\r\n"
  "s=internal linphone instance (linux)\r\n"
  "c=IN IP4 192.168.1.113\r\n"
  "b=AS:380\r\n"
  "t=0 0\r\n"
  "m=audio 7078 RTP/AVP 111 101\r\n"
  "a=rtpmap:111 speex/16000\r\n"
  "a=fmtp:111 vbr=on\r\n"
  "a=rtpmap:101 telephone-event/8000\r\n"
  "a=fmtp:101 0-11\r\n";


/*!
 * SDP record of external VoIP instance instance whose audio
 * interfaces are bound to the PSTN network e.g. via a
 * GSM/UMTS/LTE modem
 *
 * The given values are just an example. They are over-
 * written during intial configuration.
 */
char ext_sdp_record[SDP_RECORD_SIZE] =
  "v=0\r\n"
  "o=ol * * IN IP4 192.168.1.113\r\n"
  "s=Talk\r\n"
  "c=IN IP4 192.168.1.117\r\n"
  "b=AS:380\r\n"
  "t=0 0\r\n"
  "m=audio 7078 RTP/AVP 111 101\r\n"
  "a=rtpmap:111 speex/16000\r\n"
  "a=fmtp:111 vbr=on\r\n"
  "a=rtpmap:101 telephone-event/8000\r\n"
  "a=fmtp:101 0-11\r\n";


/*!
 * When the internal VoiP UE is running on the
 * same machine it is good idea to restrict
 * the address range is going to use to internal
 * IP addresses (localhost). Declare the address
 * 127.0.0.1 for such a case. If this variable
 * is not specified the gateway will forward
 * external SIP messages to any address specified
 * within the SIP header.
 */
char g_gateway_int_network_ipv4_address[256];


/*!
 * When more than one network card is in use
 * it is recommended to explictly specify the
 * networks IP address which will be used
 * in SIP contact and transfer fields. Some
 * SIP user agents might otherwise not be able
 * to contact the sipserver in case the wrong
 * network is choosen. Refer to the option
 * EXOSIP_OPT_SET_IPV4_FOR_GATEWAY with the
 * eXosip2 library for more detailed information.
 */
char g_gateway_ext_network_ipv4_address[256];


/*
 * Accept exclusively calls from the
 * gateway-ext-network-ipv4-address when
 * accept-only-gateway-ext-network-address is
 * set to true. SIP INVITE messages to other
 * target addresses possible when more than
 * one network is present are declined in this
 * case.
*/
int g_accept_only_gateway_ext_network_address = 0;


/*!
 * When true overwrite the address fields
 * in the internal sdp record which are send
 * to the external VoIP instance with the
 * address used in the registration.
 * When false the ip addresses declared in the
 * sdp records are used.
 */
int g_gateway_use_dynamic_int_address = 0;

/*!
 * When true overwrite the address fields
 * in the external sdp record which are send
 * to the internal VoIP instance with the
 * address used in the registration.
 * When false the ip addresses declared in the
 * sdp records are used.
 */
int g_gateway_use_dynamic_ext_address = 0;


/*!
 * When true overwrite the address fields
 * in the external sdp record which are send
 * to the internal VoIP instance with the
 * addressed used in the invite method.
 * When false the ip addresses declared in the
 * sdp records are used.
 */
int g_gateway_transfer_ext_invite_address = 0;


/*!
 * When true the media attributes are tranfered
 * transparently between internal and external
 * SIP instance. Otherwise the attributes specified
 * in the "int-sdp_record" and "ext-sdp-record"
 * are used.
 */
int g_gateway_transfer_media_attributes = 0;


/*!
 * used transport protocol for SIP messaging (IPPROTO_UDP or IPPROTO_UDP_TCP)
 */
int g_gateway_transport = IPPROTO_UDP;


/*!
 * SIP port where an external VoIP instance such as a smartphone
 * app or a vehicles head unit can connect to. The corresponding
 * IP address is retrieved from by the origin field of the
 * external sdp record, see above.
*/
int g_gateway_ext_sip_port = 5060;


/*!
 * SIP port for connections of the gateway server (UAS) which is
 * in example used when we trigger it to send us an invite request.
 */
int g_gateway_int_sip_port = 5062;


/*!
 * Address for access to internal VoIP user equipment (linphone)
 * if gateway-transfer-ext-invite_address is not enabled. Otherwise
 * the gateway proxies to the UE found in the SIP INVITE header.
 */
char g_linphone_int_network_ipv4_address[256];


/*!
 * Default IPv4 address for external VoIP user equipment. This
 * could be required in case the external client does not
 * register.
 */
char g_default_ext_ue_ipv4_address[256];


/*!
 * Enforce usage of the address g_linphone_int_network_ipv4_address
 * in even when gateway-transfer-ext-invite_address is set to true.
 * This allows to redirect SIP IP addresses to localhost e.g. for
 * security reasons.
 */
int g_enforce_linphone_int_addr;


/*!
 * SIP port of managed internal VoIP (linphone) daemon. This
 * daemon is reached under the IP address which is indicated by
 * the origin field of the internal sdp record, see above.
 */
int g_linphone_int_sip_port = 5061;


/*!
 * user id of the linphone process. The console application
 * linphonec adds the proc uid number to the unix domain
 * socket file name. Declare 0 when linphonec runs as root
 * or the corresponding uid otherwise.
 */
int g_linhone_proc_uid = 0;



/*!
 * TCP port serving control interface for external handler to
 * public switched telephony network (modem). Specify negative
 * value to use unix domain socket /tmp/sipgateway.uds.
 */
int g_pstn_crtl_port = 5000;


/*!
 * complete sip uri (address and port) of external VoIP instance
 * This data is retrieved from ext_sdp_record and g_gateway_ext_sip_port
 *
 * @refer to g_gateway_ext_sip_port for more information
 */
char g_gateway_ext_sip_uri[256];


/*!
 * complete sip uri (address and port) of gateway server
 * This data is retrieved from int_sdp_record and g_gateway_int_sip_port
 *
 * @refer to g_gateway_int_sip_port for more information
 */
char g_gateway_int_sip_uri[256];


/*!
 * complete sip uri (address and port) of internal VoIP instance
 * This data is retrieved from int_sdp_record and g_linphone_int_sip_port
 *
 * @refer to g_linphone_int_sip_port for more information
 */
char g_linphone_int_sip_uri[256];



/* maximum number of allowed characters per config line  */
#define GW_CONF_MAX_LINE_LEN   128


/* counter for parsed line to indicate errors */
static int line_cnt = 0;


static int gwc_parse_sdp_record( char* pRec, FILE* fp, const char* p )
{
  char line[GW_CONF_MAX_LINE_LEN];
  int lineLen;
  char *pWrite = pRec, *pLine;

  /* copy rest of the command line */
  if( p )
  {
    s_strlcpy( line, p, GW_CONF_MAX_LINE_LEN );
    condition_string( line, GW_CONF_MAX_LINE_LEN );
  }
  else
  {
    line[0] = '\0';
  }


  /* seek for open curly bracket */
  while( *line != '{' )
  {
    if( fgets( line, sizeof(line), fp ) == NULL )
    {
      ++line_cnt;
      fprintf( stderr, "did not find open curly bracket error!\n");
      return -1;
    }
    condition_string( line, GW_CONF_MAX_LINE_LEN );
    ++line_cnt;

    if( strstr( line, "}" ) != NULL )
    {
      fprintf( stderr, "nested curly brackets not allowed error!\n" );
      return -1;
    }
  }


  /* parse rest of line after open curly bracket if there is anything */
  lineLen = strlen(line);
  if( lineLen > 1 )
  {
    pLine = & line[1];
    condition_string( pLine, GW_CONF_MAX_LINE_LEN );
    lineLen = strlen( pLine );
    if( SDP_RECORD_SIZE - (pWrite - pRec) < (lineLen + 2) )
    {
      fprintf( stderr, "sdp configuration data overflow error!\n");
      return -1;
    }
    memcpy( pWrite, pLine, lineLen ); pWrite += lineLen;
    memcpy( pWrite, "\r\n", 2 ); pWrite += 2;
  }

  /* parse rest of configuration block until closing curly bracket */
  pLine = line;
  do
  {
    if( fgets( pLine, sizeof(line), fp ) == NULL )
    {
      ++line_cnt;
      fprintf( stderr, "did not find closing curly bracket error!\n");
      return -1;
    }
    ++line_cnt;
    condition_string( pLine, GW_CONF_MAX_LINE_LEN );
    lineLen = strlen( pLine );

    if( strstr( pLine, "{" ) != NULL )
    {
      fprintf( stderr, "nested curly brackets not allowed error!\n" );
      return -1;
    }

    if( SDP_RECORD_SIZE - (pWrite - pRec) < (lineLen + 2) )
    {
      fprintf( stderr, "sdp configuration data overflow error!\n");
      return -1;
    }

    if( lineLen > 1 ) /* do not copy empty lines */
    {
      if( pLine[lineLen-1] == '}' )
      {
        memcpy( pWrite, pLine, lineLen-1 ); pWrite += lineLen-1; /* do not copy '}' */
      }
      else
      {
        memcpy( pWrite, pLine, lineLen ); pWrite += lineLen;
      }
      memcpy( pWrite, "\r\n", 2 ); pWrite += 2;
    }

  } while( pLine[lineLen-1] != '}' );


  if( SDP_RECORD_SIZE - (pWrite - pRec) < 1 )
  {
    fprintf( stderr, "sdp configuration data overflow error!\n");
    return -1;
  }
  *pWrite = '\0'; /* append eol character */

  return 0;
}


static int gwc_comment( FILE* fp, const char* p )
{
  return 0;
}

static int gwc_gateway_int_network_ipv4_address( FILE* fp, const char* p )
{
  s_strlcpy( g_gateway_int_network_ipv4_address, p, sizeof(g_gateway_int_network_ipv4_address) );

  return 0;
}

static int gwc_gateway_ext_network_ipv4_address( FILE* fp, const char* p )
{
  s_strlcpy( g_gateway_ext_network_ipv4_address, p, sizeof(g_gateway_ext_network_ipv4_address) );

  return 0;
}

static int gwc_int_sdp_record( FILE* fp, const char* p )
{
  return gwc_parse_sdp_record( int_sdp_record, fp, p );
}


static int gwc_ext_sdp_record( FILE* fp, const char* p )
{
  return gwc_parse_sdp_record( ext_sdp_record, fp, p );
}

static int gw_gateway_use_dynamic_int_address( FILE* fp, const char* p )
{
  char str[4];
  strncpy( str, p, 3 );
  strtolower( str, 3 );

  if( strncmp(str, "true", 3) == 0 )
  {
    g_gateway_use_dynamic_int_address = 1;
  }
  else
  {
    g_gateway_use_dynamic_int_address = 0;
  }

  return 0;
}

static int gw_accept_only_gateway_ext_network_address( FILE* fp, const char* p )
{
  char str[4];
  strncpy( str, p, 3 );
  strtolower( str, 3 );

  if( strncmp(str, "true", 3) == 0 )
  {
    g_accept_only_gateway_ext_network_address = 1;
  }
  else
  {
    g_accept_only_gateway_ext_network_address = 0;
  }

  return 0;
}


static int gw_gateway_use_dynamic_ext_address( FILE* fp, const char* p )
{
  char str[4];
  strncpy( str, p, 3 );
  strtolower( str, 3 );

  if( strncmp(str, "true", 3) == 0 )
  {
    g_gateway_use_dynamic_ext_address = 1;
  }
  else
  {
    g_gateway_use_dynamic_ext_address = 0;
  }

  return 0;
}

static int gw_gateway_transfer_ext_invite_address( FILE* fp, const char* p )
{
  char str[4];
  strncpy( str, p, 3 );
  strtolower( str, 3 );

  if( strncmp(str, "true", 3) == 0 )
  {
    g_gateway_transfer_ext_invite_address = 1;
  }
  else
  {
    g_gateway_transfer_ext_invite_address = 0;
  }

  return 0;
}

static int gw_gateway_transfer_media_attributes( FILE* fp, const char* p )
{
  char str[4];
  strncpy( str, p, 3 );
  strtolower( str, 3 );

  if( strncmp(str, "true", 3) == 0 )
  {
    g_gateway_transfer_media_attributes = 1;
  }
  else
  {
    g_gateway_transfer_media_attributes = 0;
  }

  return 0;
}


static int gw_gateway_transport( FILE* fp, const char* p )
{
  char str[4];
  strncpy( str, p, 3 );
  strtolower( str, 3 );

  if( strncmp(str, "udp", 3) == 0 )
  {
    g_gateway_transport = IPPROTO_UDP;
  }
  else if( strncmp(str, "tcp", 3) == 0 )
  {
    g_gateway_transport = IPPROTO_TCP;
  }
  else
  {
    fprintf( stderr, "specified transport protocol not supported!\n" );
    return -1;
  }

  return 0;
}


static int gwc_gateway_ext_sip_port( FILE* fp, const char* p )
{
  g_gateway_ext_sip_port = atoi( p );
  return( g_gateway_ext_sip_port < 1000 || g_gateway_ext_sip_port > 65535 );
}


static int gwc_gateway_int_sip_port( FILE* fp, const char* p )
{
  g_gateway_int_sip_port = atoi( p );
  return( g_gateway_int_sip_port < 1000 || g_gateway_ext_sip_port > 65535 );
}


static int gwc_linphone_int_network_ipv4_address( FILE* fp, const char* p )
{
  s_strlcpy( g_linphone_int_network_ipv4_address, p, sizeof(g_linphone_int_network_ipv4_address) );

  return 0;
}


static int gwc_default_ext_ue_ipv4_address( FILE* fp, const char* p )
{
  s_strlcpy( g_default_ext_ue_ipv4_address, p, sizeof(g_default_ext_ue_ipv4_address) );

  return 0;
}


static int gwc_enforce_linphone_int_addr( FILE* fp, const char* p )
{
  char str[4];
  strncpy( str, p, 3 );
  strtolower( str, 3 );

  if( strncmp(str, "true", 3) == 0 )
  {
    g_enforce_linphone_int_addr = 1;
  }
  else
  {
    g_enforce_linphone_int_addr = 0;
  }

  return 0;
}

static int gwc_linphone_int_sip_port( FILE* fp, const char* p )
{
  g_linphone_int_sip_port = atoi( p );
  return( g_linphone_int_sip_port < 1000 || g_linphone_int_sip_port > 65535 );
}

static int gwc_linhone_proc_uid( FILE* fp, const char* p )
{
  g_linhone_proc_uid = atoi( p );
  return( g_linhone_proc_uid < 0 || g_linhone_proc_uid > 65535 );
}


static int gwc_pstn_crtl_port( FILE* fp, const char* p )
{
  g_pstn_crtl_port = atoi( p );
  return( g_pstn_crtl_port > 0 && (g_pstn_crtl_port < 1000 || g_pstn_crtl_port > 65535) );
}


static tGWConfCmd gwConfCmdTable[] = {
  "#", gwc_comment,
  "gateway-int-network-ipv4-address", gwc_gateway_int_network_ipv4_address,
  "gateway-ext-network-ipv4-address", gwc_gateway_ext_network_ipv4_address,
  "accept-only-gateway-ext-network-address", gw_accept_only_gateway_ext_network_address,
  "int-sdp-record", gwc_int_sdp_record,
  "ext-sdp-record", gwc_ext_sdp_record,
  "gateway-use-dynamic-int-address", gw_gateway_use_dynamic_int_address,
  "gateway-use-dynamic-ext-address", gw_gateway_use_dynamic_ext_address,
  "gateway-transfer-ext-invite-address", gw_gateway_transfer_ext_invite_address,
  "gateway-transfer-media-attributes", gw_gateway_transfer_media_attributes,
  "transport", gw_gateway_transport,
  "gateway-ext-sip-port", gwc_gateway_ext_sip_port,
  "gateway-int-sip-port", gwc_gateway_int_sip_port,
  "linphone-int-network-ipv4-address", gwc_linphone_int_network_ipv4_address,
  "default-ext-ue-ipv4-address", gwc_default_ext_ue_ipv4_address,
  "enforce-linphone-int-addr", gwc_enforce_linphone_int_addr,
  "linphone-int-sip-port", gwc_linphone_int_sip_port,
  "linhone-proc-uid", gwc_linhone_proc_uid,
  "pstn-crtl-port", gwc_pstn_crtl_port
};


/*!
 * construct URI's out of sdp origin address and
 * given port
 */
int gwc_init_uri_addresses( void )
{
  int retcode;
  char uriString[256];
  char tmp[256];

  retcode = sdp_get_sdp_c_address( ext_sdp_record, sizeof(ext_sdp_record), uriString );
  if( retcode )
  {
    fprintf( stderr, "failure while parsing origin field of external sdp record!\n");
    return -1;
  }

  if( g_gateway_ext_network_ipv4_address[0] != '\0' )
    snprintf( g_gateway_ext_sip_uri, sizeof(g_gateway_ext_sip_uri), "sip:%s:%d",
              g_gateway_ext_network_ipv4_address, g_gateway_ext_sip_port );
  else
    snprintf( g_gateway_ext_sip_uri, sizeof(g_gateway_ext_sip_uri), "sip:%s:%d",
              uriString, g_gateway_ext_sip_port );


  retcode = sdp_get_sdp_c_address( int_sdp_record, sizeof(int_sdp_record), uriString );
  if( retcode )
  {
    fprintf( stderr, "failure while parsing origin field of internal sdp record!\n");
    return -1;
  }

  snprintf( g_gateway_int_sip_uri, sizeof(g_gateway_int_sip_uri), "sip:%s:%d",
            g_gateway_int_network_ipv4_address, g_gateway_int_sip_port );

  snprintf( g_linphone_int_sip_uri, sizeof(g_linphone_int_sip_uri), "sip:%s:%d",
            g_linphone_int_network_ipv4_address, g_linphone_int_sip_port );

  return 0;
}


/*!
 * read configuration data from ~/.sipgateway.rc, /etc/sipgateway.rc
 * or /usr/local/etc/sipgateway.rc
 * return 0 in case of success, otherwise error code
 */
int gw_init_config(void)
{
  struct passwd* pw = getpwuid(getuid());
  char local_conf_path[128];
  char global_conf_path1[128], global_conf_path2[128];
  char* pUsedConfFileName;
  char line[GW_CONF_MAX_LINE_LEN];
  char *pToken, *pLine;
  FILE *fp;
  const char* sep=" \t\r\n";
  int retcode, i, found, executed_line;

  line_cnt = 0;

  /* intialize path to local and global conf files */
  snprintf( local_conf_path, sizeof(local_conf_path), "%s/.sipgateway.rc", pw->pw_dir );
  snprintf( global_conf_path1, sizeof(global_conf_path1), "/etc/sipgateway.rc" );
  snprintf( global_conf_path2, sizeof(global_conf_path2), "/usr/local/etc/sipgateway.rc" );

  /* ensure that gate network address is not set by default */
  g_gateway_int_network_ipv4_address[0] = '\0';
  g_gateway_ext_network_ipv4_address[0] = '\0';

  fp = fopen(local_conf_path, "r" );
  pUsedConfFileName = local_conf_path;
  if( fp ==  NULL )
  {
    fp = fopen(global_conf_path1, "r" );
    pUsedConfFileName = global_conf_path1;

    if( fp == NULL )
    {
      fp = fopen(global_conf_path2, "r" );
      pUsedConfFileName = global_conf_path2;
    }
  }

  if( fp == NULL )
  {
    fprintf( stderr, "configuration data neither at %s nor at %s or %s given!\n",
             local_conf_path, global_conf_path1, global_conf_path2 );
    return -1;
  }


  while( fgets( line, sizeof(line), fp ) != NULL  )
  {
    ++line_cnt;
    pLine = line;
    condition_string( pLine, sizeof(line) );

    pToken = strsep( &pLine, sep );
    if( pToken == NULL || strlen(pToken) == 0 )
      continue;

    strtolower( pToken, sizeof(line) );
    for( i=0, found=0; i < (sizeof(gwConfCmdTable) / sizeof(tGWConfCmd)); ++i )
    {
      executed_line = line_cnt;

      if( strcmp( gwConfCmdTable[i].cmdStr, pToken ) == 0 )
      {
        found = 1;

        /* we got the command so inoke the corresponding handler */
        retcode = (*gwConfCmdTable[i].pHandler)( fp, strsep( &pLine, sep ) );
        if( retcode )
        {
          fprintf( stderr,
                   "error while parsing line %d of config file %s detected, abort!\n",
                   executed_line, pUsedConfFileName );
          return retcode;
        }

        break;
      }
    }

    if( ! found )
    {
      fprintf( stderr,
               "command not found in line %d of config file %s, abort !\n",
               line_cnt, pUsedConfFileName );
      return -1;
    }
  }

  retcode = gwc_init_uri_addresses();

  fclose( fp );
  return retcode;
}
