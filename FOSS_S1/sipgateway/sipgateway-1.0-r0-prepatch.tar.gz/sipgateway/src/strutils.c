/*
 * string manipulation utilies
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 */

#include <string.h>
#include <ctype.h>


/*!
 * transforms buffer to lower case letters
 */
void strtolower( char *p, const int max_len )
{
  int i = 0;

  while( (*p!='\0') && (i++ < max_len) )
  {
    *p = tolower( *p );
    ++p;
  }
}


 /*!
  * helper function for removing carriage return / linefeed charaters,
  * replace tabulators by space, etc.
  */
void condition_string( char *p, const int max_len )
{
  int i = 0, j = 0;

  /* remove intial tabs, spaces and CR, LF characters */
  while(  (p[i]==' ' || p[i]=='\x09' || p[i]=='\n' || p[i]=='\r') &&
          (p[i]!='\0') && (i < max_len-1) )
    ++i;

  if( i )
  {
    while( p[i]!= '\0' && (i < max_len-1) )
      p[j++] = p[i++];

    p[j++]='\0';
    i = 0;
  }


  /* replace inner spaces tabs and CR, LF characters by spaces */
  while( *p!='\0' )
  {
    switch( (int)*p )
    {
    case 10:
    case 13:
    case 9:
      *p = ' ';
      break;

    default:
      break;
    }

    ++i;
    ++p;
  }

  /* remove trailing tabs and spaces */
  --p;
  while( (*p==' ' || *p == '\x09' ) && (*p!='\0') && (i > 0) )
  {
    --i;
    --p;
  }

  if( i > 0)
    *++p = '\0';
}


/*!
 * helper function to compare to ip v4 address strings
 * return 0 when both ip v4 strings are equal
 */
int cmp_ipv4_addr_strings( const char *p1, const char *p2 )
{
  int a1, a2, a3, a4;
  int b1, b2, b3, b4;

  sscanf( p1, "%3d.%3d.%3d.%3d", &a1, &a2, &a3, &a4 );
  sscanf( p2, "%3d.%3d.%3d.%3d", &b1, &b2, &b3, &b4 );

  return( !(( a1 == b1 ) && ( a2 == b2 ) && ( a3 == b3 ) && ( a4 == b4 )) );
}


/*!
 * s_strlcpy -- size-bounded string copying and concatenation
 *
 * for more detailed information refer to: bsd man page strlcpy
 *
 * taken from:
 *   http://stackoverflow.com/questions/2933725/my-version-of-strlcpy
 */
size_t s_strlcpy(char *dest, const char *src, size_t len)
{
    char *d = dest;
    char *e = dest + len; /* end of destination buffer */
    const char *s = src;

    /* Insert characters into the destination buffer
       until we reach the end of the source string
       or the end of the destination buffer, whichever
       comes first. */
    while (*s != '\0' && d < e)
        *d++ = *s++;

    /* Terminate the destination buffer, being wary of the fact
       that len might be zero. */
    if (d < e)        // If the destination buffer still has room.
        *d = 0;
    else if (len > 0) // We ran out of room, so zero out the last char
                      // (if the destination buffer has any items at all).
        d[-1] = 0;

    /* Advance to the end of the source string. */
    while (*s != '\0')
        s++;

    /* Return the number of characters
       between *src and *s,
       including *src but not including *s .
       This is the length of the source string. */
    return s - src;
}
