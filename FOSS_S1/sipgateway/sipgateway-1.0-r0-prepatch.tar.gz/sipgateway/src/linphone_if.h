/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Interface to Linphone instance running in daemon mode (--pipe)
 */


#ifndef LINPHONE_IF_H
#define LINPHONE_IF_H


/*!
 * send call request to linphone instance via named pipe
 * runing in daemon mode with given address
 */
int linphone_call(  char* address );


/*!
 * send request to terminate active call to internal linphone instance
 */
int linphone_terminate( void );


#endif /* #ifndef LINPHONE_IF_H */
