/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Interface to Public Telephone Switched Network (PSTN)
 */

#ifndef PSTN_H
#define PSTN_H

#include <pthread.h>
#include <clist.h>

/*!
 * socket for external PSTN application
 */
#define UDS_FILE "/tmp/sipgateway.uds"

/*!
 * maximum number of characters allowed for a pstn phone number
 */
#define PSTN_MAX_NUMBER_LEN  30


/*!
 * number of maximum events to be stored in ring buffer
 */
#define PSTN_EVT_QUEUE_SIZE 5


/*!
 * call events types for public switched telephone network (PSTN)
 */
typedef enum {
  PSTN_CALL_INVITE,           /** incomming call */
  PSTN_CALL_COMPLETED,        /** outgoing call answered */
  PSTN_CALL_ALERTING,         /** outgoing call is ringing (early media) */
  PSTN_CALL_BUSY,             /** outgoing call but line is busy */
  PSTN_CALL_TERMINATED,       /** call is terminated */
  PSTN_CALL_VOIP_LOOPBACK,    /** enable loopback mode over VoIP */
  PSTN_CALL_RESET,            /** assure terminated state, if necessary irregular transition to it */
  PSTN_EVENT_COUNT            /** < MAX number of events */
} tPstnEvtType;


/*!
 * PSTN Error Codes
 */
#define PSTN_SUCCESS                    (  0 )
#define PSTN_UNDEFINED_ERROR            ( -1 )
#define PSTN_EVENT_NOT_DEFINED_ERROR    ( -2 )

struct sPstn sPstn;

/*!
 * call events for public switched telephone network (PSTN)
 */
typedef struct  {
  ListEntry         node;          /* For Queueing, must be first */
  tPstnEvtType      type;
  char              number[PSTN_MAX_NUMBER_LEN];  /* phone number */
  struct sPstn*     pCtx;          /* reference to event context */
} tPstnEvt;


/*!
 * internal state for PSTN handlers
 */
typedef struct sPstn {
  tPstnEvt          evtBlock[PSTN_EVT_QUEUE_SIZE];
  int               socket_connect_fd;
  int               event_loop_error;
  ListEntry         pool;
  ListEntry         readyList;
  tPstnEvt*         pCurrentEvent;
  pthread_t         evtLoopThread;
  pthread_mutex_t   mutex;
} tPstn;


/*!
 * allocate memory for PSTN internal state struct
 */
tPstn* pstn_malloc (void);


/*!
 * initialize PSTN internal state struct
 */
int pstn_init (tPstn* p);


/*!
 * frees PSTN internal used memory
 */
void pstn_release(tPstn* p);


/*!
 * fetches event from PSTN.
 * returns pointer to event or NULL if no event is present
 */
tPstnEvt* pstn_get_event( tPstn* p );


/*!
 * initiate dialing to PSTN with given phone number
 */
int pstn_call( tPstn* p, char* pNumber );


/*!
 * initiate dialing to PSTN with given phone number
 */
int pstn_call( tPstn* p, char* pNumber );


/*!
 * answer incoming call from PSTN
 */
int pstn_answer( tPstn* p );


/*!
 * answer terminate call from PSTN
 */
int pstn_terminate( tPstn* p );


#endif /* #ifndef PSTN_H */

