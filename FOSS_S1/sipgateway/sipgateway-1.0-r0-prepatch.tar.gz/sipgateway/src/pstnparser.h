/*
 * Sip Gateway - A primitive SIP gateway from VoIP to PSTN
 *
 * Created by Otto Linnemann
 * Copyright 2013 GNU General Public Licence. All rights reserved
 *
 * Interface to Public Telephone Switched Network (PSTN)
 * Parser for event and command string send of socket
 */
#ifndef PSTNPARSER_H
#define PSTNPARSER_H

#include <pstn.h>

/* -------------- Socket IDL ------------------------ */

/*
 * list of supported events received via control socket
 */
#define PSTN_CMD_INCOMING_CALL    "incoming_call"    /* mapped to PSTN_CALL_INVITE evt */
#define PSTN_CMD_COMPLETED        "completed"        /* mapped to PSTN_COMPLETED, send when call established */
#define PSTN_CMD_ALERTING         "alerting"         /* mapped to PSTN_CALL_ALERTING, send for early media */
#define PSTN_CMD_BUSY             "busy"             /* mapped to PSTN_BUSY */
#define PSTN_CMD_TERMINATED       "terminated"       /* mapped to PSTN_TERMINATED */
#define PSTN_CMD_VOIP_LOOPBACK    "voip_loopback"    /* mapped to PSTN_LOOPBACK */
#define PSTN_CMD_RESET            "reset"            /* mapped to PSTN_CALL_RESET */
#define PSTN_CMD_HELP             "help"             /* print out help string */

/*
 * list of supported commands sent out via control socket
 */
#define PSTN_CMD_CALL             "atd"              /* dial command + phone number separated by blank */
#define PSTN_CMD_ANSWER           "ata"              /* answer command for incoming call */
#define PSTN_CMD_TERMINATE        "ath"              /* hang up command for established call */


/*!
 * pointer to event generator for incoming events from PSTN wrapper
 * received via socket interface
 */
typedef int (*tPstnCmdHandler) ( tPstnEvt* pEvt, const char *);


/*!
 * command list entry for all events received via socket interface
 */
typedef struct {
  char*             cmdStr;
  tPstnCmdHandler   pHandler;
  char*             helpString;
} tPstnCmd;


/*!
 * parse event string and transforms to event data
 */
int pstn_parse( tPstnEvt* pEvt, const char* str );


#endif /* #ifndef PSTNPARSER_H */
