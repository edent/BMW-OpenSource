# Sipgateway - A primitive SIP gateway from IP to PSTN

Sipgateway is a simple SIP proxy server which is intended to be used on a network access devices (NAD) e.g. based on Qualcomm's MDM96x5 SoC.  These chips nowadays come more and more with a Linux operating system and provide beside a high speed data connection telephony voice services via cellular networks as standard features but devices where these chips are applied to do not always include a user interface and audio equipment. This software allows to use such devices as a standard phone where the audio and user interface is realized via an external VoIP client in example the Linphone software running on an iPod touch. Another application is to connect voice services of network access device via ethernet to multimedia devices aka the head unit within an automotive environment. Since a broadband data connection is already present in latest premium vehicles it can be used to transmit telephony audio and telephony control as well and ultimately reduce cabling.

## Architecture
Sipgate is intended to be used together with a headless linphone software (linphonec) but on constrast to linphonec is depends the libraries libosip2 and libeXosip2 in version 4.0.0 which are multi instance capable. The makefiles of these libraries have been patched to be able to coexist with the older versions 3.5.0 where linphonec is depended on. You find all of these libraries in corresponding repositories on this server.


               --------------------     (SIP)          -----------------
               |    sipgateway    |--------------------|   ext. VoIP   |
               --------------------                    -----------------
                   /           |  /                            ||
              (UDS)/      (SIP)|  /(UDS)                       ||
                   /           |  /                            ||
    --------------------      -----------------    (RTP)       ||
    |  PSTN via Modem  |\\\\\\| int. linphone |=================
    --------------------(ALSA)-----------------


The above figure illustrates how the software is intended to be used. The sipgateway controls an external VoIP and internal linphone instance. The alsa audio ports of the internal linphone instance are connected to the voice audio of the modem which is controlled via an unix domain socket connection (UDS). The external VoIP instance can be in example a smart phone running the linphone app or an automotive head unit. It is exclusively controlled via SIP which sets up the real time tranport protocol (RTP) which is used for the transmission of the audio data streams. Since VoIP connections for incoming calls need to established by the the internal linphone instance another unix domain socket between the sipgateway and the internal linphone instance is required to trigger these. The advantage of this concept is that the linphone software does not need to be changed and can be used as it is to enable VoIP services within the NAD.


## Configuration
The sipgateway is configured via a configuration file which is retrieved from ~/.sipgateway.rc, /etc/sipgateway.rc or /usr/local/etc/sipgateway.rc. The software checks the existence of this file in the given paths order during startup. Sipgateway delivers the given SDP records to the external and the internal linphone instance. These are patched with the appropriate session ID's. In case the flag <gateway-use-dynamic-ext-address> is enabled instead of using the static IP addresses specified in the configuration file the origin IP address during registration is used for the external VoIP instance.

The registration of the external VoIP instance (smartphone app) does not include authentication which is currently not impletend. In the given application this is usually not required since all entities are in the same local network which realizes authentication as well e.g. via WEP or WPA in case of WIFI.

## Quick Start
The following steps provide an instruction how to get the software up and running on Linux:

* Startup linphonec in autoanswer and daemon mode by the following command:
 linphonec -a --pipe
* Startup the sipgateway with a 2nd shell
 sipgateway
* Open a socket connection to emulate the PSTN control port within a 3rd shell:
 socat stdio gopen:/tmp/sipgateway.uds
* Register an external linphone instance. In example setup the linphone smartphone app to use the IP address and the port specified in linphone.rc (use port 5060 as default).

### Incoming Call
* Setup the PSTN call e.g. by using AT commands on the GSM modem interface. Make sure that the voice audio is available at the alsa ports which are setup within the linphone configuration file (linphone.rc)
* Enter the following command in the aforementioned 3rd shell:
 incoming_call 123
* The sipgateway shall now trigger the call initiation on the internal linphone instance which should in turn send an INVITE message to the sipgateway. The gateway will forward the call to the smartphone app which should ring.
* Answer the call at the smartphone
* The voice call (up and downlink) should be now available at the external linphone instance. You can end the call on this instnace or by entering the following command within the control shell (3rd shell):
 terminated

### Outgoing call
* Enter the phone number on the external linphone client (smart phone app) and press the dial button
* The external linphone client should send an INVITE message to the sipgateway which should forward this message to the internal linphone instance.
* On the control shell (3rd shell) the command AT <phone number> shall appear
* Setup the PSTN voice call e.g. by using the external AT interface
* The voice shall be now available. It can be terminated in the same way as for the incoming call.

## Control Interface
The sipgate unix domain socket /tmp/sipgateway.uds serves as an interface to the modem. The PSTN modem interface shall react the following events:

### list of supported events received via control socket
    | event string    | meaning                                               |
    | --------------- | ----------------------------------------------------- |
    | incoming_call   | mapped to PSTN_CALL_INVITE evt                        |
    | completed       | mapped to PSTN_COMPLETED, send when call established  |
    | busy            | mapped to PSTN_BUSY                                   |
    | terminated      | mapped to PSTN_TERMINATED                             |
    | voip_loopback   | mapped to PSTN_LOOPBACK                               |
    | help            | print out help string                                 |

The PSTN modem interface can send the following commands where the sipgateway will react on
### list of supported commands sent out via control socket
    | command string  | meaning                                               |
    | --------------- | ----------------------------------------------------- |
    | atd             | dial command + phone number separated by blank        |
    | ata             | answer command for incoming call                      |
    | ath             | hang up command for established call                  |


## Licence
This implementation code stands under the terms of the GNU General Public License.

It was written for peiker acustic in April 2013 by Otto Linnemann


## Resource and Links
Thanks to the providers of the linphone software stack and the osip and eXsop libraries

* Linphone: https://www.linphone.org
* Libosip2: http://www.gnu.org/software/osip
* LibeXosip2: http://savannah.nongnu.org/projects/exosip
