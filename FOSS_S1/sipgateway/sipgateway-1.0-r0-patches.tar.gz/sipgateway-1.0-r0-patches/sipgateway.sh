#! /bin/sh
# /etc/init.d/sipgateway: prelimary version, initializes SIP PSTN gateway


##set -e # 01/07/2014 disabled to avoid script breakage on error

NAME=sipgateway

PIDFILE=/var/run/$NAME.pd
LINPHONE_SOCKET=/tmp/linphonec-0

DAEMON=/usr/bin/sipgateway
DAEMON_ARGS=""

chgrp_linphone_socket() {
    # and poll for named pipe which is opened in it
    until test -e $LINPHONE_SOCKET; do
        sleep 0.2
    done
    chown peiker:peiker $LINPHONE_SOCKET
    }

case "$1" in
    start)
	      echo -n "Starting daemon: "$NAME
        chgrp_linphone_socket
        start-stop-daemon --background --start --quiet -m --pidfile $PIDFILE --exec $DAEMON --chuid peiker -- $DAEMON_ARGS
	      ;;

    stop)
	      echo -n "Stopping daemon: "$NAME
        start-stop-daemon --stop --quiet --signal 9 --pidfile $PIDFILE
	      ;;

    restart)
	      echo -n "Restart daemon: "$NAME
        $0 stop
        $0 start
	      ;;

    *)
	      echo "Usage: "$1" {start|stop|restart}" >&2
	      exit 1
        ;;
esac

exit 0
