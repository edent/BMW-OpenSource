#include<stdio.h>

void 
print(char* s)
{
	printf("%s\n",s);
}
