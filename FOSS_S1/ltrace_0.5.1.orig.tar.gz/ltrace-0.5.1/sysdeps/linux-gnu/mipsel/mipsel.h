#ifndef MIPSEL_h
#define  MIPSEL_h
// linux-2.4.30/arch/mips/kernel/ptrace.c for these offsets.
#define off_v0 2
#define off_pc 64
#define off_a0 4
#define off_a3 7
#define off_lr 31
#define off_sp 29

#endif //  MIPSEL_h
