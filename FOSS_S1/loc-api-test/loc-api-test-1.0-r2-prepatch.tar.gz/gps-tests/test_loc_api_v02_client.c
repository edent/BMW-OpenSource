/*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*

                        TEST_LOC_API_V02_CLIENT.C

  Copyright (c) 2011-2012 QUALCOMM Incorporated.  All Rights Reserved.
 QUALCOMM Proprietary and Confidential.

$Header: //source/qcom/qct/modem/gps/loc_api_v02_test/common/main/latest/
    src/test_loc_api_v02_client.c#11 $
$DateTime: 2012/06/19 09:39:25 $
$Author: nksingh $
*====*====*====*====*====*====*====*====*====*====*====*====*====*====*====*/

#include <stdint.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "loc_api_v02_client.h"
#include "loc_api_sync_req.h"
#include "location_service_v02.h"
#include "loc_util_log.h"

#define DUMMY_SESSION_ID (1)

#define LOG_NDEBUG 0
#define LOG_NDDEBUG 1
#define LOG_TAG "loc_api_utt"

#define TF_APP_ID
#define TF_MULTIPLE_HANDLE
#define TF_GET_SERVICE_REVISION_V02

void eventIndCb(
    locClientHandleType handle,
    uint32_t eventIndId,
    const locClientEventIndUnionType eventIndPayload,
    void *pClientCookie)
{
  int *pIndex = pClientCookie;
  LOC_LOGE("%s:%d]: received ind %d from handle %p with index %d\n",
          __func__, __LINE__ , eventIndId,  handle, *pIndex);

  switch(eventIndId) {
    case QMI_LOC_EVENT_POSITION_REPORT_IND_V02:
        LOC_LOGD("%s:%d]: pos report indication lat:%f, lon:%f, alt_valid%d\n",
                __func__, __LINE__,
        eventIndPayload.pPositionReportEvent->latitude,
        eventIndPayload.pPositionReportEvent->longitude,
        eventIndPayload.pPositionReportEvent->altitudeWrtEllipsoid_valid);
        break;

    case QMI_LOC_EVENT_GNSS_SV_INFO_IND_V02:
        LOC_LOGD("%s:%d]: satellite report indication\n",
                __func__, __LINE__);
        break;
  }
}

void  respIndCb(
    locClientHandleType handle,
    uint32_t respIndId,
    const locClientRespIndUnionType respIndPayload,
    void *pClientCookie)
{
  int *pIndex = pClientCookie;
  LOC_LOGE(" %s:%d]: received ind %d status %d from handle %p "
          "with index %d\n", __func__, __LINE__, respIndId,
          respIndPayload.pDeleteAssistDataInd->status, handle, *pIndex);

  // process the sync call
   // use pDeleteAssistDataInd as a dummy pointer
  loc_sync_process_ind(handle, respIndId,
          (void *)respIndPayload.pDeleteAssistDataInd);
}

static void errorCb(
    locClientHandleType handle,
    locClientErrorEnumType errorId,
    void *pClientCookie)
{
  int *pIndex = pClientCookie;
  LOC_LOGE(" %s:%d]: received errorId%d from handle %p "
          "with index %d\n", __func__, __LINE__, errorId,
          handle, *pIndex);
}

locClientCallbacksType globalCallbacks = {
    sizeof(locClientCallbacksType),
    eventIndCb,
    respIndCb,
    errorCb
};

// send set protocol config
bool cmd_send_protocol_config(
        locClientHandleType handle,
        uint8_t suplSecurity,
        qmiLocVxVersionEnumT_v02 vxVersion,
        qmiLocSuplVersionEnumT_v02 suplVersion,
        uint32_t mask)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocSetProtocolConfigParametersReqMsgT_v02 setReq;
  qmiLocSetProtocolConfigParametersIndMsgT_v02 setInd;

  memset(&setReq, 0, sizeof(setReq));
  memset(&setInd, 0, sizeof(setInd));

  if (mask & 0x1) {
      setReq.suplSecurity_valid = 1;
      setReq.suplSecurity  = suplSecurity; //Enable SUPL security
  }

  if (mask & 0x02) {
      setReq.vxVersion_valid = 1;
      setReq.vxVersion = vxVersion;
  }

  if (mask & 0x04) {
      setReq.suplVersion_valid = 1;
      setReq.suplVersion = suplVersion;
  }

  req_union.pSetProtocolConfigParametersReq = &setReq;

  status = loc_sync_send_req(handle,
          QMI_LOC_SET_PROTOCOL_CONFIG_PARAMETERS_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_SET_PROTOCOL_CONFIG_PARAMETERS_IND_V02,
          &setInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != setInd.status)
  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d "
            "ind bitmask =%llu\n", __func__, __LINE__,
            status, setInd.status,
            setInd.failedProtocolConfigParamMask);
    return false;
  }

  LOC_LOGE("%s:%d]: success !!\n", __func__, __LINE__);
  return true;
}

// send set protocol config
bool cmd_get_protocol_config(locClientHandleType handle)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocGetProtocolConfigParametersReqMsgT_v02 getReq;
  qmiLocGetProtocolConfigParametersIndMsgT_v02 getInd;

  memset(&getReq, 0, sizeof(getReq));
  memset(&getInd, 0, sizeof(getInd));

  getReq.getProtocolConfigParamMask =
      QMI_LOC_PROTOCOL_CONFIG_PARAM_MASK_SUPL_SECURITY_V02
      |QMI_LOC_PROTOCOL_CONFIG_PARAM_MASK_VX_VERSION_V02
      |QMI_LOC_PROTOCOL_CONFIG_PARAM_MASK_SUPL_VERSION_V02;

  req_union.pGetProtocolConfigParametersReq = &getReq;

  status = loc_sync_send_req(handle,
          QMI_LOC_GET_PROTOCOL_CONFIG_PARAMETERS_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_GET_PROTOCOL_CONFIG_PARAMETERS_IND_V02,
          &getInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != getInd.status)
  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d "
            "suplSecurity valid =%u, vxVersion_valid = %u\n",
            __func__, __LINE__,
            status, getInd.status, getInd.suplSecurity_valid,
            getInd.vxVersion_valid);
    return false;
  }

  LOC_LOGE("%s:%d]: success suplSecurity = %d, vxVersion=%d\n",
          __func__, __LINE__,
          getInd.suplSecurity, getInd.vxVersion);
  return true;
}

bool cmd_send_pe_config(locClientHandleType handle,
        uint8_t injectedPositionControl,
        uint8_t filterSvUsage,
        uint8_t storeAssistData,
        uint32_t mask)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocSetPositionEngineConfigParametersReqMsgT_v02 setReq;
  qmiLocSetPositionEngineConfigParametersIndMsgT_v02 setInd;

  memset(&setReq, 0, sizeof(setReq));
  memset(&setInd, 0, sizeof(setInd));

  if (mask & 0x1) {
      setReq.injectedPositionControl_valid = 1;
      // enable injected position
      setReq.injectedPositionControl = injectedPositionControl;
  }

  if (mask & 0x02) {
      setReq.filterSvUsage_valid = 1;
      setReq.filterSvUsage = filterSvUsage;
  }

  if (mask & 0x04) {
      setReq.storeAssistData_valid = 1;
      setReq.storeAssistData = storeAssistData;
  }

  req_union.pSetPositionEngineConfigParametersReq = &setReq;

  status = loc_sync_send_req(handle,
          QMI_LOC_SET_POSITION_ENGINE_CONFIG_PARAMETERS_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_SET_POSITION_ENGINE_CONFIG_PARAMETERS_IND_V02,
          &setInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != setInd.status)

  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d "
            "ind bitmask =0x%x\n", __func__, __LINE__,
            status, setInd.status,
            setInd.failedPositionEngineConfigParamMask);
    return false;
  }

  LOC_LOGE("%s:%d]: success !!\n", __func__, __LINE__);
  return true;
}

// send get pe config
bool cmd_get_pe_config(locClientHandleType handle)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocGetPositionEngineConfigParametersReqMsgT_v02 getReq;
  qmiLocGetPositionEngineConfigParametersIndMsgT_v02 getInd;

  memset(&getReq, 0, sizeof(getReq));
  memset(&getInd, 0, sizeof(getInd));

  getReq.getPositionEngineConfigParamMask =
      QMI_LOC_POSITION_ENGINE_CONFIG_PARAM_MASK_INJECTED_POSITION_CONTROL_V02
      |QMI_LOC_POSITION_ENGINE_CONFIG_PARAM_MASK_FILTER_SV_USAGE_V02
      |QMI_LOC_POSITION_ENGINE_CONFIG_PARAM_MASK_STORE_ASSIST_DATA_V02;

  req_union.pGetPositionEngineConfigParametersReq = &getReq;

  status = loc_sync_send_req(handle,
          QMI_LOC_GET_POSITION_ENGINE_CONFIG_PARAMETERS_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_GET_POSITION_ENGINE_CONFIG_PARAMETERS_IND_V02,
          &getInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != getInd.status)

  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d "
            "sinjectedPositionControl_valid =%u, "
            "filterSvUsage_valid = %u storeAssistData_valid =%u\n",
            __func__, __LINE__,
            status, getInd.status, getInd.injectedPositionControl_valid,
            getInd.filterSvUsage_valid, getInd.storeAssistData_valid);
    return false;
  }

  LOC_LOGE("%s:%d]: success injectedPositionControl = %u, filterSvUsage=%u"
          "storeAssistData =%u\n",
          __func__, __LINE__,
          getInd.injectedPositionControl, getInd.filterSvUsage,
          getInd.storeAssistData);
  return true;
}

// send GetServiceRevision request
bool cmd_send_get_serv_rev_req(locClientHandleType handle)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocGetServiceRevisionIndMsgT_v02 serv_revision = { 0 };

  status = loc_sync_send_req(handle,
          QMI_LOC_GET_SERVICE_REVISION_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_GET_SERVICE_REVISION_IND_V02,
          &serv_revision);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != serv_revision.status)

  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d ",
            __func__, __LINE__, status, serv_revision.status);
    return false;
  }

  LOC_LOGE("%s:%d]: success !!\n", __func__, __LINE__);

  LOC_LOGE("status %d revision %d\n",
          serv_revision.status, serv_revision.revision);
  /**<   Status of the Get Revision request.
        Valid values: \n
          - 0x00000000 -- SUCCESS \n
          - 0x00000001 -- GENERAL_FAILURE \n
          - 0x00000002 -- UNSUPPORTED \n
          - 0x00000003 -- INVALID_PARAMETER \n
          - 0x00000004 -- ENGINE_BUSY \n
          - 0x00000005 -- PHONE_OFFLINE \n
          - 0x00000006 -- TIMEOUT
   */
  return true;
}

bool cmd_get_fix_criteria(locClientHandleType handle)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocGetFixCriteriaIndMsgT_v02 fixCriteriaInd;
  memset(&fixCriteriaInd, 0, sizeof(fixCriteriaInd));
  status = loc_sync_send_req(handle,
          QMI_LOC_GET_FIX_CRITERIA_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_GET_FIX_CRITERIA_IND_V02,
          &fixCriteriaInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != fixCriteriaInd.status)

  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d\n ",
            __func__, __LINE__, status, fixCriteriaInd.status);
    return false;
  }

  return true;
}

bool cmd_send_start(locClientHandleType handle)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocStartReqMsgT_v02 startReq;
  memset(&startReq, 0, sizeof(startReq));
  startReq.fixRecurrence_valid = 1;
  startReq.fixRecurrence = eQMI_LOC_RECURRENCE_PERIODIC_V02;
  startReq.intermediateReportState_valid = 1;
  startReq.intermediateReportState = eQMI_LOC_INTERMEDIATE_REPORTS_ON_V02;
  startReq.sessionId = 1;
  startReq.minInterval_valid = 1;
  startReq.minInterval =  1000; // 1Hz fixes

  req_union.pStartReq = &startReq;
  status = locClientSendReq(handle, QMI_LOC_START_REQ_V02, req_union);
  LOC_LOGD("%s:%d]: send request returned status = %d\n", __func__,
          __LINE__, status);

  return true;
}

bool cmd_delete_data_all(locClientHandleType handle)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocDeleteAssistDataReqMsgT_v02 deleteReq;  /* Message */
  qmiLocDeleteAssistDataIndMsgT_v02 deleteInd;  /* Message */

  memset(&deleteReq, 0, sizeof(deleteReq));
  memset(&deleteInd, 0, sizeof(deleteInd));

  deleteReq.deleteAllFlag = 1;

  req_union.pDeleteAssistDataReq = &deleteReq;

  status = loc_sync_send_req(handle,
          QMI_LOC_DELETE_ASSIST_DATA_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_DELETE_ASSIST_DATA_IND_V02,
          &deleteInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != deleteInd.status)
  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d ",
            __func__, __LINE__,  status, deleteInd.status);
    return false;
  }

  LOC_LOGE("%s:%d]: successful delete assist call\n",
          __func__, __LINE__);

  return true;
}

bool cmd_inject_supl_cert(locClientHandleType handle,
    uint8_t certId, uint32_t certLen, const uint8_t *certData)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocInjectSuplCertificateReqMsgT_v02 certReq;
  qmiLocInjectSuplCertificateIndMsgT_v02 certInd;

  memset(&certReq, 0, sizeof(certReq));
  memset(&certInd, 0, sizeof(certInd));

  certReq.suplCertId = certId;
  certReq.suplCertData_len = certLen;

  memcpy(certReq.suplCertData, certData, certLen);
  req_union.pInjectSuplCertificateReq = &certReq;

  status = loc_sync_send_req(handle,
          QMI_LOC_INJECT_SUPL_CERTIFICATE_REQ_V02,
          req_union,
          5000,
          QMI_LOC_INJECT_SUPL_CERTIFICATE_IND_V02,
          &certInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != certInd.status)
  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d ",
            __func__, __LINE__,  status, certInd.status);
    return false;
  }

  LOC_LOGE("%s:%d]: successful cert Injection\n",
          __func__, __LINE__);
  return true;
}

bool cmd_delete_supl_cert(locClientHandleType handle,
        uint8_t certId,
        bool delete_all)
{
  locClientStatusEnumType status;
  locClientReqUnionType req_union;
  qmiLocDeleteSuplCertificateReqMsgT_v02 certReq;
  qmiLocDeleteSuplCertificateIndMsgT_v02 certInd;

  memset(&certReq, 0, sizeof(certReq));
  memset(&certInd, 0, sizeof(certInd));

  // check if delete all is not specified
  if (!delete_all) {
      certReq.suplCertId_valid = 1;
      certReq.suplCertId = certId;
  }

  req_union.pDeleteSuplCertificateReq = &certReq;

  status = loc_sync_send_req(handle,
          QMI_LOC_DELETE_SUPL_CERTIFICATE_REQ_V02,
          req_union,
          LOC_ENGINE_SYNC_REQUEST_TIMEOUT,
          QMI_LOC_DELETE_SUPL_CERTIFICATE_IND_V02,
          &certInd);

  if (status != eLOC_CLIENT_SUCCESS ||
          eQMI_LOC_SUCCESS_V02 != certInd.status)
  {
    LOC_LOGE("%s:%d]: Error : status = %d, ind.status = %d ",
            __func__, __LINE__,  status, certInd.status);
    return false;
  }

  LOC_LOGE("%s:%d]: successful cert deletion\n",
          __func__, __LINE__);
  return true;
}

#ifdef LOC_UTIL_TARGET_OFF_TARGET
#include "qmi_cci_common.h"
extern qmi_cci_xport_ops_type udp_ops;
#endif

/*=============================================================================
  FUNCTION main
=============================================================================*/
int main(int argc, char **argv)
{
  locClientStatusEnumType status;
  locClientHandleType handle1;
  int i;
  int id1 = 1;

#ifdef TF_MULTIPLE_HANDLE
  locClientHandleType handle2;
  int id2 = 2;
#endif

#ifdef TF_SUPL_CERT
  uint8_t suplCert[QMI_LOC_MAX_SUPL_CERT_LENGTH_V02];
  uint32_t suplCertSize = 0;
  FILE *fp = NULL;
#endif

#ifdef LOC_UTIL_TARGET_OFF_TARGET
// start the udp router for off target env
  qmi_cci_xport_start(&udp_ops, NULL);
#endif

#ifdef _ANDROID_
  loc_read_gps_conf();
#endif

#ifdef TF_INVALID_HANDLE
  // test locClientClose with an invalid handle; expect failure
  status = locClientClose(&handle1);
  printf("locClientClose returnedi %d\n", status);

  //test a send request with an invalid handle; expect failure
  cmd_send_protocol_config(handle1,
          0,
          eQMI_LOC_VX_VERSION_V1_ONLY_V02,
          eQMI_LOC_SUPL_VERSION_1_0_V02,
          1);
#endif

  status = locClientOpen(QMI_LOC_EVENT_MASK_POSITION_REPORT_V02
          | QMI_LOC_EVENT_MASK_GNSS_SV_INFO_V02,
          &globalCallbacks,
          &handle1,
          (void *)&id1);

  LOC_LOGD("%s:%d]: First locClientOpen returned %d handle =%p\n ",
          __func__,
          __LINE__,
          status,
          handle1);

#ifdef TF_MULTIPLE_HANDLE
  status = locClientOpen(QMI_LOC_EVENT_MASK_POSITION_REPORT_V02
          | QMI_LOC_EVENT_MASK_GNSS_SV_INFO_V02,
          &globalCallbacks,
          &handle2,
          (void *)&id2);

  LOC_LOGD("%s:%d]: locClientOpen returned %d handle =%p\n ",
          __func__,
          __LINE__,
          status,
          handle2);
#endif

#ifdef TF_DELETE_ALL
  cmd_delete_data_all(handle1);
#endif

#ifdef TF_PROTOCOL_CONFIG
for (i = 0; i < 2; i++) {

    cmd_send_protocol_config(handle1,
            0,
            eQMI_LOC_VX_VERSION_V1_ONLY_V02,
            eQMI_LOC_SUPL_VERSION_1_0_V02,
            1);
    sleep(1);
    cmd_send_protocol_config(handle1,
            0,
            eQMI_LOC_VX_VERSION_V1_ONLY_V02,
            eQMI_LOC_SUPL_VERSION_1_0_V02,
            2);
    sleep(1);
    cmd_send_protocol_config(handle1,
            0,
            eQMI_LOC_VX_VERSION_V1_ONLY_V02,
            eQMI_LOC_SUPL_VERSION_1_0_V02,
            4);
    sleep(1);
    cmd_send_protocol_config(handle1,
            1,
            eQMI_LOC_VX_VERSION_V2_ONLY_V02,
            eQMI_LOC_SUPL_VERSION_2_0_V02,
            7);
    sleep(1);
    cmd_get_protocol_config(handle1);
    sleep(5);
}
#endif

#ifdef TF_PE_CONFIG
for (i = 0; i < 2; i++) {

    cmd_send_pe_config(handle1, 1, 0, 0, 1);
    sleep(1);
    cmd_send_pe_config(handle1, 0, 1, 0, 2);
    sleep(1);
    cmd_send_pe_config(handle1, 0, 0, 1, 4);
    sleep(1);
    cmd_send_pe_config(handle1, 1, 1, 0, 7);
    sleep(1);
    cmd_get_pe_config(handle1);
    sleep(5);
}
#endif

#ifdef TF_GET_SERVICE_REVISION_V02
cmd_send_get_serv_rev_req(handle1);
#endif

#ifdef TF_SUPL_CERT
#define CERT1 "/etc/supl_cert1"
#define CERT2 "/etc/supl_cert2"

fp = fopen(CERT1, "r");
if (NULL != fp) {
    size_t bytesToRead = QMI_LOC_MAX_SUPL_CERT_LENGTH_V02;
    suplCertSize = fread(suplCert, 1, bytesToRead, fp);
    printf(" read %d bytes from %s into cert buffer\n", suplCertSize, CERT1);
    fclose(fp);
} else {
    printf("failed to open file\n");
    exit(0);
}

// send the certId 0
cmd_inject_supl_cert(handle1, 0, suplCertSize, suplCert);

printf("Please hit Enter to continue to overwrite another certificate\n");

while (getchar() != '\n') {};

fp = fopen(CERT2, "r");
if (NULL != fp) {
    size_t bytesToRead = 2000;
    suplCertSize = fread(suplCert, 1, bytesToRead, fp);
    printf(" read %d bytes from %s into cert buffer\n", suplCertSize, CERT2);
    fclose(fp);
}

cmd_inject_supl_cert(handle1, 1, suplCertSize, suplCert);

printf("Please hit Enter to continue to Delete Wrong cert Id 10\n");

while (getchar() != '\n') {};

//this should return an error that 10 is an invalid ID isn't found
cmd_delete_supl_cert(handle1, 10, 0);

printf("Please hit Enter to continue to Delete  cert Id 1\n");

while (getchar() != '\n') {};

// delete the right cert now
cmd_delete_supl_cert(handle1, 1, 0);

printf("Please hit Enter to continue to inject from buffer\n");

while (getchar() != '\n') {};

// inject and delete all
for (i = 0; i < suplCertSize; i++) {
    suplCert[i] = 'c';
}

cmd_inject_supl_cert(handle1, 3, suplCertSize, suplCert);
printf("Please hit Enter to continue to Delete  all certs\n");

while (getchar() != '\n') {};

// delete all
cmd_delete_supl_cert(handle1, 5, 1);

printf("Please hit Enter to continue to inject  invalid cert Id 15\n");
while (getchar() != '\n') {};

//inject an invalid cert ID
for (i = 0; i < suplCertSize; i++) {
    suplCert[i] = 'd';
}

cmd_inject_supl_cert(handle1, 15, suplCertSize, suplCert);
#endif

printf("Before cmd_send_start()\n");

//cmd_send_start(handle1, NULL);
cmd_send_start(handle1);
sleep(1);

#ifdef TF_MULTIPLE_HANDLE
//cmd_send_start (handle2, NULL);
cmd_send_start(handle2);
sleep(10);
status = locClientClose(&handle2);
LOC_LOGE("%s:%d] close1 returned %d\n", __func__, __LINE__, status);
#endif

sleep(50);
status = locClientClose(&handle1);
LOC_LOGE("%s:%d] close2 returned %d\n", __func__, __LINE__, status);

return 0;
}
