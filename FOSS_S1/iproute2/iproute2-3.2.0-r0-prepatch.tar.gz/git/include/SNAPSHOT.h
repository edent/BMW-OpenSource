static const char SNAPSHOT[] = "120105";
