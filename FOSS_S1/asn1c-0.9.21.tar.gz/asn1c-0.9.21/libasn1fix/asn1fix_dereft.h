#ifndef	_ASN1FIX_DEREFT_H_
#define	_ASN1FIX_DEREFT_H_

int asn1f_fix_dereference_types(arg_t *);

#endif	/* _ASN1FIX_DEREFT_H_ */
