/* Need :
<netinet/in.h>
*/

/* elementary data types types */
typedef unsigned char u8;
typedef signed char s8;
typedef unsigned short u16;
typedef signed short s16;
typedef unsigned int u32;
typedef signed int s32;
typedef unsigned long long u64;
typedef signed long long s64;

#define U32_AT(p) (ntohl(*((u32 *)(p))))
#define U16_AT(p) (ntohs(*((u16 *)(p))))

#define DEFAULT_PORT 1234
