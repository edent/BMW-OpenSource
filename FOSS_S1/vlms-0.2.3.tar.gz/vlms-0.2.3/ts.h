
void ts_fill( options_t *options, unsigned int *left, int wait, int pcr_pid );
void ts_thread( options_t *options );

