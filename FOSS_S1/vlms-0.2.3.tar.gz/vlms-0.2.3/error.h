void err_sys(const char *fmt, ...);
void err_quit(const char *fmt, ...);
