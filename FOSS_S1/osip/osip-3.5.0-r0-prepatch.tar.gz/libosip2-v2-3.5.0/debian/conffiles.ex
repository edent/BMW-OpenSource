#
# If you want to use this conffile, remove all comments and put files that
# you want dpkg to process here using their absolute pathnames.
# See the policy manual
#
# for example:
# /etc/libosip2/libosip2.conf
