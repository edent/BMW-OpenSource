/****************************************************************************
 *
 *      Copyright (c) DiBcom SA.  All rights reserved.
 *
 *      THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 *      KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 *      IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 *      PURPOSE.
 *
 ****************************************************************************/


#ifndef _MEM_MAP_
#define _MEM_MAP_

#define CRYPTED_BLOCK_END_ADDR          0x7001813c
#define CRYPTED_BLOCK_START_ADDR        0x70017d00
#define CRYPTED_DATA_ADDR               0x70017d00
#define CRYPTED_DATA_SIZE               1024
#define CRYPTED_IV_ADDR                 0x70018120
#define CRYPTED_KEY_ADDR                0x70018100
#define DOWNLOAD_MODE_REG               0x70018130
#define ENTRY_POINT_ADDR                0x70000000
#define ENTRY_STACK_SIZE                8192
#define EXCEPTION_ADDR                  0x70018a20
#define FIRMRAM_LENGTH                  92888
#define FIRMRAM_START_ADDR              0x70000000
#define FIRMWARE_ADDR_REG               0x70018138
#define FIRMWARE_ID_REG                 0x700189e8
#define FOO_SYSRAM_ADDR                 0x700189dc
#define HOST_MBX_END_ADDR               0x70018d00
#define HOST_MBX_RD_PTR_REG             0x700189ec
#define HOST_MBX_SIZE                   768
#define HOST_MBX_START_ADDR             0x70018a00
#define HOST_MBX_WR_PTR_REG             0x700189f0
#define HOST_STATUS_REG                 0x7001813c
#define JEDEC_ADDR                      0x8000a020
#define JEDEC_REG_VALUE                 0x01b31069
#define JUMP_ADDRESS_REG                0x70018134
#define MAC_MBX_END_ADDR                0x70018e00
#define MAC_MBX_RD_PTR_REG              0x700189f4
#define MAC_MBX_SIZE                    256
#define MAC_MBX_START_ADDR              0x70018d00
#define MAC_MBX_WR_PTR_REG              0x700189f8
#define MAIN_COUNTER_ADDR               0x700189e4
#define MAX_IV_SIZE                     16
#define MAX_KEY_SIZE                    32
#define MBX_END_ADDR                    0x70018d00
#define MBX_SIZE                        1056
#define MBX_START_ADDR                  0x700189dc
#define MSG_API_BUF_ADDR                0x700188d4
#define MSG_API_BUF_SIZE                264
#define SRAM_END_ADDR                   0x70019000
#define SRAM_START_ADDR                 0x70000000
#define STACK_END_ADDR                  0x700188d0
#define SUBFIRMRAM_LENGTH               131072
#define SUBFIRMRAM_START_ADDR           0x701e0000
#define TRAP_BASE_ADDR                  0x70000000
#define URAM_END_ADDR                   0x70200000
#define URAM_START_ADDR                 0x70100000

#endif /*_MEM_MAP_*/
