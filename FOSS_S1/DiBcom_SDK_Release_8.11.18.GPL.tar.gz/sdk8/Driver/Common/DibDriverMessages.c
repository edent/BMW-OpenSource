/****************************************************************************
 *
 *      Copyright (c) DiBcom SA.  All rights reserved.
 *
 *      THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 *      KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 *      IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 *      PURPOSE.
 *
 ****************************************************************************/

/**************************************************************************************************
* @file "DibMessages.c"
* @brief Generic Message Handling.
*
***************************************************************************************************/
#include "DibDriverConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibDriverConstants.h"
#include "DibDriverTargetTypes.h"
#include "DibDriverCommon.h"
#include "DibDriverTargetDebug.h"
#include "DibDriverRegisterIf.h"
#include "DibDriverDowncalls.h"
#include "DibDriverIf.h"
#include "DibDriver.h"
#include "DibDriverMessages.h"

/**
 * Sends a message to one of the riscs from application context (not irq context)
 * @param pContext pointer to the context
 * @param Data     pointer to the data to send
 * @param Nb       size of the message in bytes
 */
DIBSTATUS DibDriverSendMessage(struct DibDriverContext *pContext, uint32_t * Data, uint32_t Nb)
{
   DIBSTATUS Status = DIBSTATUS_ERROR;

   DIB_ASSERT(Data);

   Status = (DIBSTATUS)DibD2BSendMsg(pContext, Nb, Data);

   return Status;
}



