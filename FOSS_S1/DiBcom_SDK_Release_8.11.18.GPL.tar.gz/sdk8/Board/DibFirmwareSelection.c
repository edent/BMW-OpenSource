/****************************************************************************
 *
 *      Copyright (c) DiBcom SA.  All rights reserved.
 *
 *      THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 *      KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 *      IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 *      PURPOSE.
 *
 ****************************************************************************/


#include "DibConfig.h" /* Must be first include of all SDK files - Defines compilation options */

#if (USE_DRAGONFLY == 1)

#include "DibFirmwareSelection.h"

/* Here we include all the octocode binaries */
#if DIB_CMMB_STD == 1
#include "../Firmware/octopus-hw11-spal3-cmmb-4096_data-bin.h"
#include "../Firmware/octopus-hw11-spal3-cmmb-bin.h"
#endif
#if DIB_DVB_STD == 1
#include "../Firmware/octopus-spal3-dvbt-bin.h"
#include "../Firmware/octopus-spal3-dvbt_data-bin.h"
#include "../Firmware/octopus-spal3-dvbt-2048_data-bin.h"
#include "../Firmware/octopus-spal3-dvbt-4096_data-bin.h"
#endif

#if DIB_ISDBT_STD == 1
#include "../Firmware/octopus-spal3-isdbt-bin.h"
#include "../Firmware/octopus-spal3-isdbt-2061_data-bin.h"
#include "../Firmware/octopus-spal3-isdbt-8205_data-bin.h"
#include "../Firmware/octopus-spal3-isdbt-8193_data-bin.h"
#include "../Firmware/octopus-spal3-isdbt-8195_data-bin.h"
#include "../Firmware/octopus-spal3-isdbt-4109_data-bin.h"
#endif

#if DIB_DAB_STD == 1
#include "../Firmware/octopus-spal-dab-bin.h"
#include "../Firmware/octopus-spal-dab_tm1_data-bin.h"
#include "../Firmware/octopus-spal-dab_tm2_data-bin.h"
#include "../Firmware/octopus-spal-dab_tm3_data-bin.h"
#include "../Firmware/octopus-spal-dab_tm4_data-bin.h"
#endif

struct DibFirmwareDescription    FirmwareList[] =
{
#if DIB_CMMB_STD == 1
    {"octopus-hw11-spal3-cmmb-4096_data.bin" ,"cmmb standard only"          ,octopus_hw11_spal3_cmmb_4096_data_bin ,  sizeof(octopus_hw11_spal3_cmmb_4096_data_bin)  },
    {"octopus-hw11-spal3-cmmb.bin"           ,"cmmb standard modulation 4K" ,octopus_hw11_spal3_cmmb_bin           ,  sizeof(octopus_hw11_spal3_cmmb_bin)  },
#endif
#if DIB_DVB_STD == 1
   {"octopus-spal3-dvbt.bin"  ,"dvb standard only 8K"                   ,octopus_spal3_dvbt_bin           ,  sizeof(octopus_spal3_dvbt_bin)  },
   {"octopus-spal3-dvbt_data.bin"  ,"dvb standard modulation 8K"        ,octopus_spal3_dvbt_data_bin      ,  sizeof(octopus_spal3_dvbt_data_bin)  },
   {"octopus-spal3-dvbt-2048_data.bin"  ,"dvb standard modulation 2K"   ,octopus_spal3_dvbt_2048_data_bin ,  sizeof(octopus_spal3_dvbt_2048_data_bin)  },
   {"octopus-spal3-dvbt-4096_data.bin"  ,"dvb standard modulation 4K"   ,octopus_spal3_dvbt_4096_data_bin ,  sizeof(octopus_spal3_dvbt_4096_data_bin)  },
#endif
#if DIB_ISDBT_STD == 1
   {"octopus-spal3-isdbt.bin"  ,"isdbt standard only"                        ,  octopus_spal3_isdbt_bin          , sizeof(octopus_spal3_isdbt_bin)  },
   {"octopus-spal3-isdbt-8205_data.bin", "isdbt standard modulation 8K 13seg",  octopus_spal3_isdbt_8205_data_bin, sizeof(octopus_spal3_isdbt_8205_data_bin) },
   {"octopus-spal3-isdbt-8193_data.bin", "isdbt standard modulation 8K  1seg",  octopus_spal3_isdbt_8193_data_bin, sizeof(octopus_spal3_isdbt_8193_data_bin) },
   {"octopus-spal3-isdbt-2061_data.bin"  ,"isdbt standard modulation 2K"     ,  octopus_spal3_isdbt_2061_data_bin, sizeof(octopus_spal3_isdbt_2061_data_bin)  },
   {"octopus-spal3-isdbt-8195_data.bin"  ,"isdbt standard modulation 8K 3 seg", octopus_spal3_isdbt_8195_data_bin, sizeof(octopus_spal3_isdbt_8195_data_bin)  },
   {"octopus-spal3-isdbt-4109_data.bin"  ,"isdbt standard modulation 4K 13seg", octopus_spal3_isdbt_4109_data_bin, sizeof(octopus_spal3_isdbt_4109_data_bin)  },
#endif
#if DIB_DAB_STD == 1
   {"octopus-spal-dab.bin"          ,"dab standard code"             ,octopus_spal_dab_bin         ,  sizeof(octopus_spal_dab_bin)       },
   {"octopus-spal-dab_tm1_data.bin" ,"dab standard TMODE-I (2K)"     ,octopus_spal_dab_tm1_data_bin,  sizeof(octopus_spal_dab_tm1_data_bin)  },
   {"octopus-spal-dab_tm2_data.bin" ,"dab standard TMODE-II (1/2K)"  ,octopus_spal_dab_tm2_data_bin,  sizeof(octopus_spal_dab_tm2_data_bin)  },
   {"octopus-spal-dab_tm3_data.bin" ,"dab standard TMODE-III (1/4K)" ,octopus_spal_dab_tm3_data_bin,  sizeof(octopus_spal_dab_tm3_data_bin)  },
   {"octopus-spal-dab_tm4_data.bin" ,"dab standard TMODE-IV (2K)"    ,octopus_spal_dab_tm4_data_bin,  sizeof(octopus_spal_dab_tm4_data_bin)  },
#endif
  {""                       ,""                           ,0                            ,  0                              }
};

#endif
