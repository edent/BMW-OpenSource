/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeDataMscAudio.c"
* @brief Tdmb Handling.
*
***************************************************************************************************/
#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibBridgeTargetDebug.h"
#include "DibBridgeCommon.h"
#include "DibBridgeTarget.h"
#include "DibBridgeMailboxHandler.h"
#include "DibBridgePayloadCheckers.h"
#include "DibBridgeTestIf.h"
#include "DibBridge.h"
#include "DibBridgeData.h"

#if(DIB_DAB_DATA == 1)

void DibBridgeMscDone(struct DibBridgeContext *pContext, struct DibBridgeDmaCtx * pDmaCtx, ELEM_HDL Item)
{
#if (DIB_CHECK_MSC_DATA == 1)
#if (DIB_CHECK_DATA_IN_FILE == 1)
   static uint8_t FirstTime = 15;

   if(FirstTime > 0)
   {
      if(FirstTime == 5)
         DibBridgeCheckMscInit(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen, Item);
      FirstTime--;
   }
   else
   {
      DibBridgeCheckMscData(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen, Item);
   }
#else

   if(pContext->ItSvc[Item].DataLenRx == 0)
   {
      if(DibBridgeCheckMscInit(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen, Item) == 0)
         pContext->ItSvc[Item].DataLenRx = 0;
   }
   if(pContext->ItSvc[Item].DataLenRx != 0)
   {
      if(DibBridgeCheckMscData(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen, Item) == 0)
         pContext->ItSvc[Item].DataLenRx = 0;
   }   
#endif
#endif

/*   DibBridgeDesallocateRawBuffer(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen); */
}

#endif
