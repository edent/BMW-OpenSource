/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeFireflyData.h"
* @brief Firefly specific bridge functionnality.
*
***************************************************************************************************/
#ifndef DIB_BRIDGE_FIREFLY_DATA_H
#define DIB_BRIDGE_FIREFLY_DATA_H

#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibBridge.h"

#if (DIB_MPEFEC_DATA == 1)
void      DibBridgeFireflyGetCpt(struct DibBridgeContext *pContext, uint16_t * pDataMsg);
uint32_t  DibBridgeFireflyAssembleSlice(struct DibBridgeContext *pContext, struct DibBridgeDmaFlags *pFlags, uint32_t offs, uint32_t len);
DIBSTATUS DibBridgeFireflyHbmProfiler(struct DibBridgeContext *pContext, uint8_t idx, uint8_t page, uint8_t LastFrag);
DIBSTATUS DibBridgeFireflySendAck(struct DibBridgeContext *pContext, struct DibBridgeDmaFlags *pFlags, uint8_t failed);
#else
#define   DibBridgeFireflyGetCpt(pContext, pDataMsg)
#define   DibBridgeFireflyHbmProfiler(pContext, idx, page, LastFrag)   DIBSTATUS_SUCCESS
uint32_t  DibBridgeFireflyAssembleSlice(struct DibBridgeContext *pContext, struct DibBridgeDmaFlags *pFlags, uint32_t offs, uint32_t len)   {return 0;}
DIBSTATUS DibBridgeFireflySendAck(struct DibBridgeContext *pContext, struct DibBridgeDmaFlags *pFlags, uint8_t failed) { return DIBSTATUS_SUCCESS;}
#endif

#endif
