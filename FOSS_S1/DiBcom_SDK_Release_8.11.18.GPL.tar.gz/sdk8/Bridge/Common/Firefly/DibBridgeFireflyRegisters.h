/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeFireflyRegisters.h"
* @brief Firefly specific registers.
*
***************************************************************************************************/
#ifndef DIB_BRIDGE_FIREFLY_REGISTERS_H
#define DIB_BRIDGE_FIREFLY_REGISTERS_H

#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#define OUT_MSG_HBM_ACK            0

#define ID_RISCA                   0
#define ID_RISCB                   1

#define REG_MAC_CPUA_CTRL       1024
#define REG_MAC_CPUA_CADDR      1025
#define REG_MAC_CPUA_CDATA      1026
#define REG_MAC_MBXA_OUT        1027
#define REG_MAC_MBXA_IN         1028
#define REG_MAC_MBXA_DATA       1029

#define REG_MAC_CPUA_CKEY       1031

#define REG_MAC_CPUB_CTRL       1040
#define REG_MAC_CPUB_CADDR      1041
#define REG_MAC_CPUB_CDATA      1042
#define REG_MAC_MBXB_OUT        1043
#define REG_MAC_MBXB_IN         1044
#define REG_MAC_MBXB_DATA       1045

#define REG_MAC_CPUB_CKEY       1047

#define REG_RAMIF_MODE          1056
#define REG_RAMIF_BASEH         1057
#define REG_RAMIF_BASEL         1058
#define REG_RAMIF_MAXH          1059
#define REG_RAMIF_MAXL          1060
#define REG_RAMIF_MINH          1061
#define REG_RAMIF_MINL          1062
#define REG_RAMIF_DATA          1063

#define REG_RAMIF_NOJMP         1074
#define REG_RAMIF_JMP           1075
#define REG_RAMIF_IRAMCFG       1076

#define REG_MAC_IRQ_MASK        1224
#define REG_MAC_MEMCFG1         1225
#define REG_MAC_MEMCFG2         1226
#define REG_MAC_RESET           1227

#define REG_MAC_IRQ             1229

#define REG_MAC_APBSW           1237

#define REG_IPCRP_BSEL          1542

#define MASTER_IRQ_CTRL         1792

#define MBX_MAX_WORDS           (256 - 200 - 2)

#endif
