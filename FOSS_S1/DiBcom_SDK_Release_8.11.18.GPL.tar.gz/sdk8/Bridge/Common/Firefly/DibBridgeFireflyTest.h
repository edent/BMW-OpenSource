/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeFireflyTest.h"
* @brief Firefly sprecific bridge tests.
*
***************************************************************************************************/
#ifndef DIB_BRIDGE_FIREFLY_TEST_H
#define DIB_BRIDGE_FIREFLY_TEST_H

#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibBridge.h"
#include "DibBridgeTarget.h"

#define OFFSET_RAM_EXT    0x800000
#define OFFSET_RAM_INT    0

int32_t IntBridgeFireflyTestBasicRead(struct DibBridgeContext *pContext);
int32_t IntBridgeFireflyTestRegister(struct DibBridgeContext *pContext);
int32_t IntBridgeFireflyTestInternalRam(struct DibBridgeContext *pContext);
int32_t IntBridgeFireflyTestExternalRam(struct DibBridgeContext *pContext);
uint32_t DibBridgeFireflyGetRamAddr(struct DibBridgeContext *pContext);


#endif


 
