/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgePayloadCheckers.h"
* @brief Data check.
*
***************************************************************************************************/
#ifndef _PAYLOAD_CHECKERS_H_
#define _PAYLOAD_CHECKERS_H_

#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */

#if (DIB_CHECK_RAWTS_DATA == 1)
uint8_t DibBridgeCheckRawTsInit(void);
void DibBridgeCheckRawTsData(struct DibBridgeContext *pContext, uint8_t *pBuf, uint32_t Size, uint8_t Item);
#endif

#if (DIB_CHECK_FIG_DATA == 1)
uint8_t DibBridgeCheckFigInit(uint8_t *pBuf, uint32_t Size);
void    DibBridgeCheckFigData(struct DibBridgeContext *pContext, uint8_t *pBuf, uint32_t Size);
#endif

#if (DIB_CHECK_MSC_DATA == 1)
uint8_t DibBridgeCheckMscInit(struct DibBridgeContext *pContext, uint8_t *pBuf, uint32_t Size, ELEM_HDL Item);
uint8_t DibBridgeCheckMscData(struct DibBridgeContext *pContext, uint8_t *pBuf, uint32_t Size, ELEM_HDL Item);
uint8_t DibBridgeCheckMscDataGroup(struct DibBridgeContext *pContext, uint8_t *pBuf, uint32_t Size, ELEM_HDL Item);
#endif

#if (DIB_CHECK_IP_DATA == 1)
uint8_t DibBridgeCheckIpData(struct DibBridgeContext *pContext, uint8_t *pdata, uint32_t Cnt, uint8_t item);
#endif

#if (DIB_CHECK_RTP_DATA == 1)
void DibBridgeCheckRtpData(struct DibBridgeContext *pContext, uint8_t *pdata, uint32_t mpe_size, uint8_t item);
#endif

#if (DIB_CHECK_PES_DATA == 1)
void DibBridgeCheckPesData(struct DibBridgeContext *pContext, uint8_t *pBuf, struct DibBridgeDmaCtx * pDmaCtx);
#endif
#if (DIB_CHECK_PCR_DATA == 1)
void    DibBridgeCheckPcrData(struct DibBridgeContext *pContext, uint8_t *pBuf, uint32_t Size);
#endif

#if (DIB_CHECK_CMMB_DATA == 1)
void DibBridgeCheckCmmbMultiplexFrame(struct DibBridgeContext *pContext, uint8_t *Mf, uint32_t Size, uint32_t ItemId);
#endif /* DIB_CHECK_CMMB_DATA */

#endif 
