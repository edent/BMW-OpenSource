/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef MSG_GENERIC_IF_H
#define MSG_GENERIC_IF_H

/* Fast macro to look inside a 32 bit formatted buffer */
#define GET_MSG_SIZE(Header)         ((uint16_t)  ((Header) & 0x00000FFF))
#define GET_MSG_CHIP(Header)         ((int8_t)   (((Header) & 0x0000F000) >> 12))
#define GET_MSG_ID(Header)           ((uint16_t) (((Header) & 0x00FF0000) >> 16))
#define GET_MSG_SENDER(Header)       ((int8_t)   (((Header) & 0x0F000000) >> 24))
#define GET_MSG_TYPE_ID(Header)      ((int8_t)   (((Header) & 0xF0000000) >> 28))


#define SET_MSG_HEADER(MsgId, Size)  (((MsgId) << 16) | (Size))

#endif
