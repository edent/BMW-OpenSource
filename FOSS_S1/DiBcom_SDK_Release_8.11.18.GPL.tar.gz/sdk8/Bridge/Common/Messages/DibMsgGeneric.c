/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */




#include "DibMsgGeneric.h"

/**
 Header : first struct of all messages
 @param MsgSize Size in 32bits words of the message
 @param ChipId  Chip identification : HOST_IDENT for host, MASTER_IDENT for master, i for ith slave
 @param MsgId   Message identification associated to this "Type" of message
 @param Type    Type of message
 */

/* list of message types */

/* chipset identifiers */


void MsgHeaderPack(struct MsgHeader *s, struct SerialBuf *ctx)
{
   SerialBufWriteField(ctx, 12, s->MsgSize);
   SerialBufWriteField(ctx, 4, s->ChipId);
   SerialBufWriteField(ctx, 8, s->MsgId);
   SerialBufWriteField(ctx, 4, s->Sender);
   SerialBufWriteField(ctx, 4, s->Type);
}





/**
 Header : first struct of all messages
 @param MsgSize Size in 32bits words of the message
 @param ChipId  Chip identification : HOST_IDENT for host, MASTER_IDENT for master, i for ith slave
 @param MsgId   Message identification associated to this "Type" of message
 @param Type    Type of message
 */

/* list of message types */

/* chipset identifiers */


void MsgHeaderUnpack(struct SerialBuf *ctx, struct MsgHeader *s)
{
   s->MsgSize                     = SerialBufReadField(ctx, 12, 0);
   s->ChipId                      = SerialBufReadField(ctx, 4, 1);
   s->MsgId                       = SerialBufReadField(ctx, 8, 0);
   s->Sender                      = SerialBufReadField(ctx, 4, 1);
   s->Type                        = SerialBufReadField(ctx, 4, 0);
}


