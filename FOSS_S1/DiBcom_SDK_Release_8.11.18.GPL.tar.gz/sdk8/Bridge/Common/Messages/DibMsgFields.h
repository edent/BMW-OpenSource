/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

#ifndef FIELDS_H
#define FIELDS_H

#include "DibMsgTypes.h"

#ifdef __cplusplus
#define EXTERN extern "C"
#else
#define EXTERN
#endif

struct SerialBuf
{
   void   * buf;
   uint32_t w;
   uint32_t i;
   uint32_t j;
};

#define  GetWords(bits, width)           ((bits) + (width) - 1) / (width)

EXTERN void     SerialBufInit       (struct SerialBuf * ctx, void * buf, uint32_t width);
EXTERN void     SerialBufRestart    (struct SerialBuf * ctx);
EXTERN void     SerialBufAlign      (struct SerialBuf * ctx, uint32_t align);
EXTERN void     SerialBufWriteField (struct SerialBuf * ctx, uint32_t s, int32_t v);
EXTERN int32_t  SerialBufReadField  (struct SerialBuf * ctx, uint32_t s, uint32_t z);

#endif /* FIELDS_H */

