/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgePes.c"
* @brief Pes data Handling.
*
***************************************************************************************************/
#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibBridgeTargetDebug.h"
#include "DibBridgeCommon.h"
#include "DibBridgeTarget.h"
#include "DibBridgeMailboxHandler.h"
#include "DibBridgePayloadCheckers.h"
#include "DibBridgeTestIf.h"
#include "DibBridge.h"
#include "DibBridgeData.h"

#if (DIB_PES_DATA == 1)

void DibBridgePesDone(struct DibBridgeContext *pContext, struct DibBridgeDmaCtx * pDmaCtx)
{
#if (DIB_CHECK_PES_DATA == 1)
    DibBridgeCheckPesData(pContext, pDmaCtx->pHostAddr, pDmaCtx);
#endif
   DibBridgeDesallocateRawBuffer(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen);
}

void DibBridgePcrDone(struct DibBridgeContext *pContext, struct DibBridgeDmaCtx * pDmaCtx)
{
#if (DIB_CHECK_PCR_DATA == 1)
    DibBridgeCheckPcrData(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen);
#endif
   DibBridgeDesallocateRawBuffer(pContext, pDmaCtx->pHostAddr, pDmaCtx->DmaLen);
}


#endif
