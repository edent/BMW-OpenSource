/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeDragonfly.h"
* @brief Dragonfly sprecific bridge functionality.
*
***************************************************************************************************/
#ifndef DIB_BRIDGE_DRAGONFLY_DATA_H
#define DIB_BRIDGE_DRAGONFLY_DATA_H

#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibBridge.h"
#include "DibBridgeData.h"

/*************************************************************/
/*** RAWTS                                                ****/
/*************************************************************/
#if (DIB_RAWTS_DATA == 1)
#else
#endif

/*************************************************************/
/*** ELEMENTARY STREAM                                    ****/
/*************************************************************/
#if (DIB_PES_DATA == 1)
#else                        
#endif

/*************************************************************/
/*** SIPSI                                                ****/
/*************************************************************/
#if (DIB_SIPSI_DATA == 1)
#else                        
#endif


/*************************************************************/
/*** MPEFEC                                               ****/
/*************************************************************/
#if (DIB_MPEFEC_DATA == 1)
#undef   DIB_HBM_DATA
#define  DIB_HBM_DATA    1

#else

#endif

/*************************************************************/
/*** MPEIFEC                                              ****/
/*************************************************************/
#if (DIB_MPEIFEC_DATA == 1)
#undef   DIB_HBM_DATA
#define  DIB_HBM_DATA    1

DIBDMA DibBridgeDragonflyMoveData(struct DibBridgeContext * pContext, uint32_t * Data, uint32_t Size, uint8_t Move);
void   DibBridgeDragonflyReconstructBurst(struct DibBridgeContext * pContext, uint32_t * Data, uint32_t Size);
void   DibBridgeDragonflyResetTable(struct DibBridgeContext * pContext, uint32_t * Data);
DIBDMA DibBridgeDragonflyInfoMsgHandler(struct DibBridgeContext * pContext, uint32_t * Data, uint32_t Size);

#else
#define DibBridgeDragonflyMoveData(pContext, Data, Size, Move)    DIB_NO_DMA
#define DibBridgeDragonflyResetTable(pContext, Data)  
#define DibBridgeDragonflyReconstructBurst(pContext, Data, Size)  
#define DibBridgeDragonflyInfoMsgHandler(pContext, Data, Size)    DIB_NO_DMA

#endif

#if (DIB_HBM_DATA == 1)
uint32_t DibBridgeDragonflyAssembleSlice(struct DibBridgeContext *pContext, struct DibBridgeDmaFlags *pFlags, uint32_t offs, uint32_t len);
#else
static uint32_t DibBridgeDragonflyAssembleSlice(struct DibBridgeContext *pContext, struct DibBridgeDmaFlags *pFlags, uint32_t offs, uint32_t len) {return 0;}
#endif

#endif
