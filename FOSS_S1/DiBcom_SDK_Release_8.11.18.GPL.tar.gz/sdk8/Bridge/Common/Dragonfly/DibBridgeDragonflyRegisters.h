/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeDragonflyRegisters.h"
* @brief Dragonfly specific registers.
*
***************************************************************************************************/
#ifndef DIB_BRIDGE_DRAGONFLY_REGISTERS_H
#define DIB_BRIDGE_DRAGONFLY_REGISTERS_H

#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibMsgData.h"

/**************************************************************
 *
 *         Useful macro to read or write bit fields
 *
 *************************************************************/
#define FIELD(Size, Off)            ((Size) << 8 | (Off)) 
#define SHIFT(Field)                (Field & 0xFF) 
#define SIZE(Field)                 (Field >> 8) 
#define MASK(Field)                 ((0xFFFFFFFF >> (32-SIZE(Field))) << SHIFT(Field)) 
#define FIELD_ALL                   FIELD(32, 0) 
#define GFLD(RVal, Field)           ((RVal & MASK(Field)) >> SHIFT(Field))
#define SFLD(RVal, Data, Field)     ((RVal & ~MASK(Field)) | (Data << SHIFT(Field)));

/**************************************************************
 *
 *                  Host interface
 *
 *************************************************************/

#define REG_HOSTIF_OFFSET            0x8000B000
#define REG_HIF_INT_STAT            (REG_HOSTIF_OFFSET + 0x00)
#define REG_HIF_INT_SET             (REG_HOSTIF_OFFSET + 0x04)
#define REG_HIF_INT_CLR             (REG_HOSTIF_OFFSET + 0x08)
#define REG_HIF_INT_EN              (REG_HOSTIF_OFFSET + 0x0C)
#define REG_HIF_INT_MIRROR          (REG_HOSTIF_OFFSET + 0x10)

#define FLD_HIF_IRQ(Irq)            FIELD( 1, Irq)    /* [15: 0]  Bit wise interrupt flags   */
#define FLD_HIF_MBX_NEW             FIELD( 1, 0)      /* [    0]  New Message in Msg Box     */
#define FLD_HIF_MBX_OVF             FIELD( 1, 1)      /* [    1]  Message Box Overflow       */
#define FLD_HIF_IRQ_ALL             FIELD(16, 0)

#define REG_HIF_HOST_IRQ_MODE       (REG_HOSTIF_OFFSET + 0x14)
#define FLD_HIF_IRQ_OD              FIELD( 1, 0)      /* [    0]  host irq driven by...             */
#define FLD_HIF_IRQ_LEVEL           FIELD( 1, 1)      /* [    1]  1 if active high, 0 if active low */

#define REG_HIF_HOST_IRQ_EN         (REG_HOSTIF_OFFSET + 0x18)
#define REG_HIF_HOST_ADDR           (REG_HOSTIF_OFFSET + 0x1C)

#define REG_HIF_SDIO_IRQ_EN         (REG_HOSTIF_OFFSET + 0x24)
#define FLD_HIF_SDIO_INV               FIELD( 1, 0) /* [    0]  Polarity */
#define FLD_HIF_SDIO_EN                FIELD( 1, 1) /* [    1]  Enable SDIO irq engine */
#define FLD_HIF_SDIO_SWAP              FIELD( 1, 3) /* [    3]  Data swapping */

#endif


