/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeSiPSi.c"
* @brief SiPsi Data Handling.
*
***************************************************************************************************/
#include "DibBridgeConfig.h" /* Must be first include of all SDK files - Defines compilation options */
#include "DibBridgeTargetDebug.h"
#include "DibBridgeCommon.h"
#include "DibBridgeTarget.h"
#include "DibBridgeMailboxHandler.h"
#include "DibBridgePayloadCheckers.h"
#include "DibBridgeTestIf.h"
#include "DibBridge.h"
#include "DibBridgeData.h"

#if (DIB_SIPSI_DATA == 1)

/* ------------------------------------------------------------------------ */
void DibBridgeSiPsiDone(struct DibBridgeContext *pContext, struct DibBridgeDmaCtx * pDmaCtx)
{
   DIB_ASSERT(pDmaCtx->DmaLen > 0);
   DIB_ASSERT(pDmaCtx->pHostAddr);

   DibB2DFwdSiPsiBuf(pContext, pDmaCtx->DmaLen, pDmaCtx->pHostAddr);
}

/**
 * Transfert Sipsi request from chip memory to host memory
 * @param min: min base address in the firmware (circular buffer)
 * @param max: max base address in the firmware (circular buffer)
 * @param faddr: firwmare address where to find the sipsis
 * @return : The status of the dma transfert if occured.
 */
DIBDMA DibBridgeGetSipsi(struct DibBridgeContext *pContext, uint32_t min, uint32_t max, uint32_t faddr, uint32_t len, struct DibBridgeDmaFlags * pFlags)
{
   struct DibBridgeDmaCtx * pDmaCtx = &pContext->DmaCtx;

   memcpy(&pDmaCtx->DmaFlags, pFlags, sizeof(struct DibBridgeDmaFlags));

   pDmaCtx->Dir         = DIBBRIDGE_DMA_READ;
   pDmaCtx->ChipAddr    = faddr;
   pDmaCtx->ChipBaseMin = min;
   pDmaCtx->ChipBaseMax = max;
   pDmaCtx->DmaLen      = len;
   pDmaCtx->pHostAddr   = pContext->SiPsiBuf;

   DibBridgeSetupDma(pContext, pDmaCtx);

   return DibBridgeRequestDma(pContext, pDmaCtx);
}

#endif
