/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/****************************************************************************
 *
 *      Copyright (c) DiBcom SA.  All rights reserved.
 *
 *      THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 *      KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 *      IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 *      PURPOSE.
 *
 ****************************************************************************/
int DibSdioSpiRead(struct DibBridgeContext *pContext,unsigned int addr,unsigned char* buf, unsigned int size);
int DibSdioSpiWrite(struct DibBridgeContext *pContext,unsigned int addr,unsigned char* buf, unsigned int size);
int DibSdioSpiInitMode(struct DibBridgeContext *pContext);

void DibSdioSpiCmd52Write(struct DibBridgeContext *pContext,unsigned int Addr, unsigned char fct, unsigned char data);
unsigned char DibSdioSpiCmd53Read(struct DibBridgeContext *pContext,unsigned int Addr,unsigned char fct);
unsigned char DibSdioSpiCmd52Read(struct DibBridgeContext *pContext,unsigned int Addr,unsigned char fct);

#define SDIO_CMD_WRITE 		1
#define SDIO_CMD_READ 		0

#define SDIO_CMD_53 	 	53
#define SDIO_CMD_52 	 	52

#define SDIO_FCT_1 		1
#define SDIO_FCT_2 		2
#define SDIO_FCT_3 		3
#define SDIO_FCT_4 		4
#define SDIO_FCT_5 		5
#define SDIO_FCT_6 		6
#define SDIO_FCT_7 		7

