/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "DibBridgeTargetCommon.h"
* @brief Target Specific.
*
***************************************************************************************************/
#ifndef DIB_BRIDGE_TARGET_COMMON_H
#define DIB_BRIDGE_TARGET_COMMON_H

#include "DibDriverTarget.h"
#include <pthread.h>

/**********************************************************/
/****************** PLATFORM SPECIFIC FLAGS  **************/
/**********************************************************/
/** Supported Types of Physical Interface (DIBINTERF_PHY) */
#define DIBINTERF_PHY_SDIO       1
#define DIBINTERF_PHY_SRAM       2
#define DIBINTERF_PHY_SPI        3 
#define DIBINTERF_PHY_I2C        4 
#define DIBINTERF_PHY_SPITS      5 

/* Select Physical Interface */
#define DIBINTERF_PHY               DIBINTERF_PHY_I2C


#define USE_SDIOSPI_MODE	      0
#define USE_SDIOSPI_WORKAROUND	1
#define USE_DIBSPI_WORKAROUND	  0

#define DIBCTRL_ADDR DIBCTRL_DEFAULT_ADDR
#define DIBCTRL_DEFAULT_ADDR  0x40
#define DIBCTRL_DIV_ADDR      0x3F

/*** Test mode used internally to verify host interface using Dib0700 USB bridge **/
#define TEST_MODE_NONE		0	
#define TEST_MODE_HOOK		1	
#define TEST_MODE_SPP		  2	
#define DIBCOM_TEST_MODE 	TEST_MODE_NONE



#define INTERRUPT_MODE  USE_POLLING
/*************************************************************/
/*** Platform specific part of the Bridge Context structure.**/
/*************************************************************/

#if (DIBCOM_TEST_MODE == TEST_MODE_HOOK)
#include "Dib07x0.h"
#include "I2c.h"
#endif
#if (DIBCOM_TEST_MODE == TEST_MODE_SPP)
#include "I2c.h"
#endif
#if (DIBINTERF_PHY == DIBINTERF_PHY_I2C)
#include "I2c.h"
#endif


struct DibBridgeTargetServiceCtx
{
};

/* Specify we have a Target Context */
#define DIB_BRIDGE_TARGET_CTX    1

struct DibBridgeTargetCtx
{
   struct DibDriverContext *pDriverContext;

   /** High Priority thread variables */
   DIB_LOCK                IrqLock;
   pthread_t               IrqThread;
   struct sched_param      IrqSched;
   pthread_attr_t          IrqAttr;

#if (DIBCOM_TEST_MODE == TEST_MODE_HOOK)
   struct Dib07x0DeviceId  Id;      /* Device id                        */
   int32_t                 Unit;    /* Device number                    */
   int32_t                 CtrlFd;  /* Control file descriptor          */
   int32_t                 Ep2Fd;   /* USB : endpoint2 file descriptor  */
   int32_t                 BufFd;   /* PCIe: buffer file descriptor     */
   volatile uint8_t      * CtrlPtr; /* PCIe: control pointer            */
   volatile uint8_t      * BufPtr;  /* PCIe: buffer pointer             */
#endif
/*#if (DIBCOM_TEST_MODE == TEST_MODE_SPP)*/
#if (DIBINTERF_PHY == DIBINTERF_PHY_I2C)
   unsigned char DataBuffer[5+I2C_MAX_RDWR_SIZE];
#endif

};

#endif
