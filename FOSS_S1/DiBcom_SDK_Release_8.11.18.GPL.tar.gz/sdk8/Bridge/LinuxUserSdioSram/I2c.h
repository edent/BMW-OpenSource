/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "I2CSkeleton.h"
* @brief Target Specific.
*
***************************************************************************************************/
#include "SppI2C.h"

#define I2C_MAX_RDWR_SIZE 64
int  I2CInit(void);
int  I2CWrite(uint32_t dev_addr, uint8_t *txdata, uint32_t txlen, uint32_t byteMode);
int  I2CRead(uint32_t dev_addr, uint8_t *txdata, uint32_t txlen, uint8_t *rxdata, uint32_t rxlen, uint32_t byteMode );
