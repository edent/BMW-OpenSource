/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "I2c.c"
* @brief Target Specific.
*
***************************************************************************************************/
#include "DibBridgeCommon.h"
#include "DibBridgeTargetDebug.h"
#include "DibBridgeTarget.h"
#include "DibBridgeTargetCommon.h"
#include "DibBridge.h"

#if (DIBINTERF_PHY == DIBINTERF_PHY_I2C)

#if (DIBCOM_TEST_MODE == TEST_MODE_SPP)
#include "SppI2C.h"
#endif

extern struct DibBridgeContext *pLocalContext;
/****************************************************************************
* I2CInit
****************************************************************************/
int32_t I2CInit(void)
{
#if (DIBCOM_TEST_MODE == TEST_MODE_SPP)
   int32_t version;

   if (ExistPort(1)==0)
   {
      printf(CRB "NO PORT " CRA);

      return -1;
   }
   else
   {
      printf(CRB "PORT FIND " CRA);
   }

   return SppInit(1,10,&version);
#elif (DIBCOM_TEST_MODE == TEST_MODE_HOOK)
   DIBSTATUS retval = DIBSTATUS_ERROR;

   retval = HookInit(pLocalContext, 1, pLocalContext->BoardHdl);
#else
   return 0;
#endif
}

/****************************************************************************
* I2CWrite
****************************************************************************/
int32_t I2CWrite(uint32_t dev_addr, uint8_t *txdata, uint32_t txlen, uint32_t byteMode)
{
#if (DIBCOM_TEST_MODE == TEST_MODE_SPP)
   return SppI2CWrite(dev_addr, txdata, txlen );
#elif (DIBCOM_TEST_MODE == TEST_MODE_HOOK)
   return HookI2CWrite(pLocalContext, dev_addr, byteMode, txlen, txdata);
#else
   return 0;
#endif
}
/****************************************************************************
* I2CRead
****************************************************************************/
int32_t I2CRead(uint32_t dev_addr, uint8_t *txdata, uint32_t txlen, uint8_t *rxdata, uint32_t rxlen, uint32_t byteMode )
{
#if (DIBCOM_TEST_MODE == TEST_MODE_SPP)
   return SppI2CWriteRead(dev_addr, txdata, txlen, rxdata, rxlen); 
#elif (DIBCOM_TEST_MODE == TEST_MODE_HOOK)
    return HookI2CRead(pLocalContext, dev_addr, txdata, txlen, rxdata, rxlen, byteMode );
#else
   return 0;
#endif
}
#endif
