/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "Sram.h"
* @brief Target Specific.
*
***************************************************************************************************/


/*** Base Address of Memory Bank used for Dibcom Chip ****/
/*** Depends on customer design                       ****/

#define DIB_BASE    	 0x60000000 

#define DIB16_ADDR_MSB   (DIB_BASE + 0x3) 
#define DIB16_ADDR_LSB   (DIB_BASE + 0x2) 
#define DIB16_DATA_MSB   (DIB_BASE + 0x1) 
#define DIB16_DATA_LSB   (DIB_BASE + 0x0) 

#define DIB32_ADDR_MSB   (DIB_BASE + 0x7)
#define DIB32_ADDR_mSB   (DIB_BASE + 0x6)
#define DIB32_ADDR_lSB   (DIB_BASE + 0x5)
#define DIB32_ADDR_LSB   (DIB_BASE + 0x4)
#define DIB32_DATA_MSB   (DIB_BASE + 0x3)
#define DIB32_DATA_mSB   (DIB_BASE + 0x2)
#define DIB32_DATA_lSB   (DIB_BASE + 0x1)
#define DIB32_DATA_LSB   (DIB_BASE + 0x0)


#if (DIBCOM_TEST_MODE == TEST_MODE_HOOK)

void SramWrite(struct DibBridgeContext *pContext, uint32_t address, uint8_t Data);
uint8_t SramRead(struct DibBridgeContext *pContext, uint32_t address);

#else

#define DIB_ACCESS(a) (*(volatile uint8_t*)a)
#define SramWrite(p,a,b) DIB_ACCESS(a) = (b)
#define SramRead(p,a) DIB_ACCESS(a)

#endif

void SramInit(struct DibBridgeContext *pContext);
