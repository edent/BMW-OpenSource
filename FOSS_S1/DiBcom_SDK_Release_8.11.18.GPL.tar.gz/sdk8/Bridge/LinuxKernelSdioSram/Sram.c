/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "SramSkeleton.c"
* @brief Target Specific.
*
***************************************************************************************************/
#include "DibBridgeCommon.h"
#include "DibBridgeTargetDebug.h"
#include "DibBridgeTarget.h"
#include "DibBridgeTargetCommon.h"
#include "DibBridge.h"

#if (DIBINTERF_PHY == DIBINTERF_PHY_SRAM)

#include "Sram.h"

#if (DIBCOM_TEST_MODE == 1)
#include "Hook.h"
#endif

/****************************************************************************
* SramInit
****************************************************************************/
void SramInit(struct DibBridgeContext *pContext)
{
   /** Sram Controller Initialization code ***/

#if (DIBCOM_TEST_MODE == 1)
   HookInit(pContext,DIBBRIDGE_MODE_SRAM,pContext->BoardHdl);
   if(pContext->DibChip == DIB_FIREFLY)
     DibBridgeWriteReg16(pContext, 1817, 3);
#endif
}

#if (DIBCOM_TEST_MODE == 1)
/****************************************************************************
* SramWrite
****************************************************************************/
void SramWrite(struct DibBridgeContext *pContext, uint32_t address, uint8_t Data)
{
   HookSramBusWrite(pContext,address,Data);
}

/****************************************************************************
* SramRead
****************************************************************************/
uint8_t SramRead(struct DibBridgeContext *pContext, uint32_t address)
{
   uint8_t Data = 0;
   HookSramBusRead(pContext,address,&Data);
   return (Data);
}
#endif

#endif /* DIBINTERF_PHY_SRAM */
