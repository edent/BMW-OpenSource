/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/**************************************************************************************************
* @file "Compat.h"
* @brief .
*
***************************************************************************************************/
#ifndef _COMPAT_H_
#define _COMPAT_H_

#include <linux/version.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,14)
#define kzalloc(Size, flags)              \
({                                        \
void *__ret = kmalloc(Size, flags);       \
if (__ret)                                \
memset(__ret, 0, Size);                   \
   __ret;                                 \
})
#endif

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,13)
# define class class_simple
# define class_device_create(a, b, c, d, e, f...)  class_simple_device_add(a, c, d, e, f)
# define class_device_destroy(a, b)                class_simple_device_remove(b)
# define class_create(a, b)                        class_simple_create(a, b)
# define class_destroy(a)                          class_simple_destroy(a)
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,15)
# define class_device_create(a, b, c, d, e, f...) class_device_create(a, c, d, e, f)
#endif
#endif

#if LINUX_VERSION_CODE <= KERNEL_VERSION(2,6,15)

#define DEFINE_MUTEX(a)             DECLARE_MUTEX(a)
#define mutex_lock_interruptible(a) down_interruptible(a)
#define mutex_unlock(a)             up(a)
#define mutex_lock(a)               down(a)
#define mutex_init(a)               init_MUTEX(a)
#define mutex_trylock(a)            down_trylock(a)
#define mutex                       semaphore
#endif

#endif
