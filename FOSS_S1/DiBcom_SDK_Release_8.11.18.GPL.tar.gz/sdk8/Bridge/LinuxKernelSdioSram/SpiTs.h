/*
 * This file is part of dibbridge
 * 
 * dibbridge is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * dibbridge is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with dibbridge; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 */

/****************************************************************************
 *
 *      Copyright (c) DiBcom SA.  All rights reserved.
 *
 *      THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
 *      KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
 *      IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
 *      PURPOSE.
 *
 ****************************************************************************/

#define SPITS_MAX_RD_SIZE 		64	
#define SPITS_MAX_WR_SIZE 	        64	


int SpiTsInit(struct DibBridgeContext *pContext);
int SpiTsDeInit(struct DibBridgeContext *pContext);
int SpiTsSetClock(struct DibBridgeContext *pContext,unsigned int);
int SpiTsWrite(struct DibBridgeContext *pContext,unsigned int addr,unsigned char* buf, unsigned int);
int SpiTsRead(struct DibBridgeContext *pContext,unsigned int addr,unsigned char* buf, unsigned int);


