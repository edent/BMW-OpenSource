/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/


#include <pa_asrc.h>
#include <string.h>


/**
 * Initialize instance data for asynchronous sample rate conversion
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 *   - buf:                   pointer to buffered data used internally of size
 *                                                  max_samples * channels * 2
 *   - max_samples:           maximum amount of samples to be buffered (max latency)
 *   - min_samples:           minimum amount of samples to be buffered
 *   - channels:              number of interleaving audio channels to be processed
 *   - enableLog:             flag, wenn != 0 enable logging of sample insertion/removing
 *   - mutexAsrcPtr           pointer to mutex for access protection to obj
 *   - mutexLogPtr            pointer to mutex for access protection to logging object
 *   - malloc_fctPtr          pointer to memory allocation function (malloc)
 *   - free_fctPtr            pointer to memory release function (free)
 *   - mutex_lock_fctPtr      callback function to lock access to obj
 *   - mutex_unlock_fctPtr    callback function to unlock access to obj
 *
 * Returnparameter
 *   - R:                     negative error code or 0 in case of success
 */
int pa_asrc_init( pa_asrc_buf* obj,
                  int16_t* buf,
                  int32_t max_samples,
                  int32_t min_samples,
                  int channels,
                  int enableLog,
                  void* mutexAsrcPtr,
                  void* mutexLogPtr,
                  PA_ASRC_MALLOC_CALLBACK_PTR  malloc_fctPtr,
                  PA_ASRC_FREE_CALLBACK_PTR    free_fctPtr,
                  PA_ASRC_MUTEX_CALLBACK_PTR   mutex_lock_fctPtr,
                  PA_ASRC_MUTEX_CALLBACK_PTR   mutex_unlock_fctPtr,
                  PA_ASRC_PRINT_CALLBACK_PTR   message_fctPtr,
                  PA_ASRC_PRINT_CALLBACK_PTR   error_fctPtr )
{
  const int32_t buffer_size = max_samples * channels * sizeof(int16_t);
  int error_code;

  memset( obj, 0, sizeof(pa_asrc_buf) );

  obj->channels = channels;
  obj->min_samples = min_samples;
  obj->mutexPtr = mutexAsrcPtr;
  obj->log_after_frames = 20;

  if( malloc_fctPtr )
    pa_malloc = malloc_fctPtr;

  if( free_fctPtr )
    pa_free = free_fctPtr;

  if( mutex_lock_fctPtr )
    pa_lock = mutex_lock_fctPtr;

  if( mutex_unlock_fctPtr )
    pa_unlock = mutex_unlock_fctPtr;

  if( message_fctPtr )
    pa_message = message_fctPtr;

  if( error_fctPtr )
    pa_error = error_fctPtr;

  error_code = PA_ASRC_interstate_init( & obj->lagrange, 5 /* order */, 1 /* channels */, mutexAsrcPtr );
  if( ! error_code )
    return error_code;


  /*! three-step controller use as temporary implementation to deliver on schedule */
  obj->min_threshold = min_samples;
  obj->max_threshold = max_samples - min_samples;
  /* min samples is considered to be equiv. one alsa frame 20ms */
  obj->min_alpha = (int16_t) ( 16384.0 * min_samples * 0.98 / min_samples ); /* underflowing, slow consumption down by 2% */
  obj->max_alpha = (int16_t) ( 16384.0 * min_samples * 1.02 / min_samples ); /* overflowing, accelerate consumption by 2% */
  obj->alpha = 16384;


#ifdef ENABLE_SAMPLE_STREAM_LOGGING
  if( enableLog )
  {
    obj->ssLogPtr = create_ss_new_log( mutexLogPtr );
    if( obj->ssLogPtr == NULL )
      return -1;
  }
#endif

  return pa_ringBufInit( & obj->ring, (int8_t *)buf, buffer_size );
}


/**
 * Release instance data for asynchronous sample rate conversion
 *
 * This is exclusively requiresd for logging
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 */
void pa_asrc_release( pa_asrc_buf* obj )
{
#ifdef ENABLE_SAMPLE_STREAM_LOGGING
  release_ss_log( obj->ssLogPtr );
#endif
}


/**
 * Insert samples into asynchronous sample rate converter queue
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 *   - buf:                   pointer to sample buffer to be inserted
 *   - samples:               samples to insert in sample rate conversion queue
 *   - ts                     time stamp of first octett or 0 to use system time
 *
 * Return parameter
 *   - R:                     samples successfully inserted in conversion queue
 */
int32_t pa_asrc_put( pa_asrc_buf* obj, const int16_t* buf, int32_t samples, uint64_t ts )
{

  const int32_t put_size = samples * obj->channels * sizeof(int16_t);
  int32_t add_bytes;

  /* DUMMY IMPLEMENTATION! */
  pa_lock( obj->mutexPtr );
  add_bytes = pa_ringBufAddData( & obj->ring, (int8_t *)buf, put_size, 0 /* overwrite */ );
  pa_unlock( obj->mutexPtr );

  if( add_bytes < put_size )
  {
    ++obj->overflow_cnt;
    // pa_message("pa_asrc_put: jitter buffer overflow!\n");
  }

  /* log statistics */
  if( !(++obj->frames_inserted_cnt < obj->log_after_frames) )
  {
    pa_message( "pa_asrc_put: within last %d frames we got: %d lost\n",
                obj->log_after_frames, obj->overflow_cnt );
    obj->overflow_cnt = 0;
    obj->frames_inserted_cnt = 0;
  }

#ifdef ENABLE_SAMPLE_STREAM_LOGGING
  if( obj->ssLogPtr )
    add_ss_log_entry( obj->ssLogPtr, samples, ts );
#endif

  return( add_bytes / ( sizeof(int16_t) * obj->channels) );
}


/**
 * Read samples from asynchronous sample rate converter queue
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 *   - buf:                   pointer to sample buffer to be read
 *   - samples:               samples to read from sample rate conversion queue
 *   - ts                     time stamp of first octett or 0 to use system time
 *
 * Return parameter
 *   - R:                     samples successfully read in conversion queue
 */
int32_t pa_asrc_get( pa_asrc_buf* obj, int16_t* buf, int32_t samples, uint64_t ts )
{
  int32_t buffered_samples;
  static uint32_t frame_cnt = 0;
  static int underflowing_cnt = 0;
  static int overflowing_cnt = 0;

#ifdef TEST_BUFFERS_ONLY
  const int32_t get_size = samples * obj->channels * sizeof(int16_t);

  pa_lock( obj->mutexPtr );
  got_bytes = pa_ringBufGetData( & obj->ring, (int8_t *)buf, get_size );
  pa_unlock( obj->mutexPtr );
#else
  pa_lock( obj->mutexPtr );
  buffered_samples = obj->ring.uiFill / sizeof(int16_t);
  pa_unlock( obj->mutexPtr );

  if( buffered_samples < obj->min_samples )
  {
    memset( buf, 0, samples * sizeof( int16_t ) );
    ++obj->underflow_cnt;
    // pa_message("pa_asrc_get: jitter buffer underflow!\n");
  }
  else
  {
    PA_ASRC_buffer_interpol( & obj->lagrange, buf, samples, & obj->ring, obj->alpha );
  }


  /* temporarily used three-step controller for sample rate adaptation */
  if( buffered_samples < obj->min_threshold )
  {
    if( obj->alpha != obj->min_alpha )
    {
      ++obj->underflowing_cnt;
      // pa_message( "pa_asrc_get: underflowing, slow consumption!\n" );
      obj->alpha = obj->min_alpha;
    }
  }
  else if( buffered_samples > obj->max_threshold )
  {
    if( obj->alpha != obj->max_alpha )
    {
      ++obj->overflowing_cnt;
      // pa_message( "pa_asrc_get: overflowing, accelerate consumption!\n" );
      obj->alpha = obj->max_alpha;
    }
  }
  else
  {
    if( obj->alpha != 16384 )
    {
      // pa_message( "pa_asrc_get: switched to normal state!\n" );
      obj->alpha = 16384;
    }
  }

  /* log statistics */
  if( !(++obj->frames_removed_cnt < obj->log_after_frames) )
  {
    pa_message( "pa_asrc_get: within last %d frames we got: %d underlowing, %d overlfowing, %d lost\n",
                obj->log_after_frames, obj->underflowing_cnt, obj->overflowing_cnt, obj->underflow_cnt );
    obj->underflowing_cnt = 0;
    obj->overflowing_cnt = 0;
    obj->underflow_cnt = 0;
    obj->frames_removed_cnt = 0;
  }

#endif /* #ifdef TEST_BUFFERS_ONLY */

#ifdef ENABLE_SAMPLE_STREAM_LOGGING
  if( obj->ssLogPtr )
    add_ss_log_entry( obj->ssLogPtr, -samples, ts );
#endif

#ifdef TEST_BUFFERS_ONLY
  return( got_bytes / ( sizeof(int16_t) * obj->channels) );
#else
  return samples;
#endif
}

