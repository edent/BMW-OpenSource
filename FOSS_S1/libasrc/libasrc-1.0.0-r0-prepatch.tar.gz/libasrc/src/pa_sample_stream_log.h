/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/

#ifndef PA_SAMPLE_STREAM_LOG_H
#define PA_SAMPLE_STREAM_LOG_H

#include <stdint.h>
#include <pa_osal_cb.h>


typedef struct
{
  uint64_t              timestamp;   /*! point in time measured in os ticks when samples inserted/removed  */
  int16_t               samples_in;  /*! amount of samples inserted (postive value) or removed (negattive value) */
} pa_ss_log_entry_t;


typedef struct
{
  pa_ss_log_entry_t*    tab;
  long                  tab_len;
  long                  write_idx;
  long                  read_idx;
  long                  filled;
  long                  overflows;
  void*                 mutexPtr;
} pa_ss_log_t;



/*!
 * Allocate and initialize new sample stream log object
 *
 * Function parameters
 *   - mutexPtr               pointer to mutex for access protection to obj
 *
 * Returnparameter
 *   - R:                     pointer to object pa_ss_log_t or NULL in case of error
 */
pa_ss_log_t* create_ss_new_log( void* mutexPtr );


/*!
 * Allocate and initialize new sample stream log object
 *
 * Function parameters
 *   - p_log:                 pointer to object pa_ss_log_t
 */
void release_ss_log( pa_ss_log_t* p_log );


/*!
 * Add log entry to sample stream log object
 *
 * Function parameters
 *   - p_log:                 pointer to object pa_ss_log_t
 *   - samples_in             amount of samples inserted (postive value) or removed (negattive value)
 *   - ts                     time stamp of first octett or 0 to use system time
 *
 * Returnparameter
 *   - R:                     error code, in example -1 in case of overflow
 */
int add_ss_log_entry( pa_ss_log_t* obj, int16_t samples_in, uint64_t ts );


/*!
 * Read entries from sample stream log object
 *
 * Function parameters
 *   - p_log:                 pointer to object pa_ss_log_t
 *   - max_elements:          maximum amount of log entries to be buffered
 *   - entryPtr               pointer where read entries are written to
 *
 * Returnparameter
 *   - R:                     elements successfully read
 */
long read_ss_log_entries( pa_ss_log_t* obj, pa_ss_log_entry_t* entryPtr, long max_elements );



#endif /* #ifndef PA_SAMPLE_STREAM_LOG_H */
