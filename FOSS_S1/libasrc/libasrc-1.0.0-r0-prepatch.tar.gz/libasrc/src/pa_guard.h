/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

     Copyright by Peiker acustic, Friedrichsdorf / Germany

***************************************************************************/
/**
*  \defgroup aec Filterbank (SignalProcessing)
*  \author	Otto Linnemann
*  \date	04.05.2007
*  \version	$Revision: 1.1 $
*
*  \brief	Macros for checking and saturation of guard bits
*/
/*!	\addtogroup aec
***************************************************************************/


#ifndef PA_GUARD_H
#define PA_GUARD_H

/**************************************************************************
 INCLUDES
**************************************************************************/
/*lint -e829    Disable warning for using stdio.h */
#include <stdio.h>
/*lint +e829    Enable again */
#include <assert.h>
#include "pa_fract.h"

#define	ZERO_INT		((pa_int32)0)
#define	ZERO_UINT		((pa_uint32)0)
#define	ZERO_SHORT		((pa_int16)0)
#define	ZERO_USHORT		((pa_uint16)0)
#define	ONE_INT			((pa_int32)1)
#define	ONE_SHORT		((pa_int16)1)


/**
 * 	wrapping function to fprintf, used to be able to set a breakpoint in order
 *  to find out which portion of the code caused the overflow
 *
 * 	see printf, pa_guard.c
 */
int fprintf_overflow(FILE *fp, const char *fmt, ... );


/**
 *  Overflow observation takes only place if PA_LOG_OVERFLOW is defined
 */
#ifdef DEBUG
  #define PA_LOG_OVERFLOW
#endif


#ifdef PA_LOG_OVERFLOW
#define DEBUG_OVERFLOW(x)	fprintf_overflow( stderr, "OVERFLOW OF VALUE %ld OCCURED IN FILE: %s, LINE: %d\n", (long)(x), __FILE__, __LINE__),
#define ASSERT(x) if (!(x)) fprintf_overflow( stderr, "%d ASSERT OCCURED IN FILE: %s, LINE: %d\n", x,  __FILE__, __LINE__)
#define ASSERT_OVERFLOW_OCCURRED(x, f, l) if (!(x)) fprintf_overflow( stderr, "OVERFLOW OCCURRED IN FILE: %s, LINE: %d\n", f, l)
#define ASSERT_NEGATIV_SHIFT(x, f, l) if (!(x)) fprintf_overflow( stderr, "File: %s, Line: %d .... Attention: Negativ shift argument is not supported by most platforms!\n", f, l)


#define ASSERT_OVERFLOW_S32(x, nr_of_guard_bits) \
	(IS_OVERFLOW_S32(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x)  (x) : (x) )

#define ASSERT_OVERFLOW_S16(x, nr_of_guard_bits) \
	(IS_OVERFLOW_S16(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x)  (x) : (x) )

#define ASSERT_OVERFLOW_U32(x, nr_of_guard_bits) \
	(IS_OVERFLOW_U32(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x)  (x) : (x) )

#define ASSERT_OVERFLOW_U16(x, nr_of_guard_bits) \
	(IS_OVERFLOW_U16(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x)  (x) : (x) )

/*
#define ASSERT_OVERFLOW_S32(x, nr_of_guard_bits) ((void)0)
#define ASSERT_OVERFLOW_S16(x, nr_of_guard_bits) ((void)0)
#define ASSERT_OVERFLOW_U32(x, nr_of_guard_bits) ((void)0)
#define ASSERT_OVERFLOW_U16(x, nr_of_guard_bits) ((void)0)
*/

#else
#define					DEBUG_OVERFLOW(x) ((void)0),
#define                 ASSERT(x) ((void)0)
#define                 UELAUF(x, f, l) ((void)0)

#define ASSERT_OVERFLOW_S32(x, nr_of_guard_bits) ((void)0)
#define ASSERT_OVERFLOW_S16(x, nr_of_guard_bits) ((void)0)
#define ASSERT_OVERFLOW_U32(x, nr_of_guard_bits) ((void)0)
#define ASSERT_OVERFLOW_U16(x, nr_of_guard_bits) ((void)0)

#endif


/**
 *	Macro expressions for checking that nr_of_guard_bits are available (IS_OVERFLOW) and
 *  saturation to nr_of_guard_bits (GUARD_BITS)
 */

#define	IS_OVERFLOW_S32(x, nr_of_guard_bits)	\
	(((x)^((x)>>1)) & ((~ZERO_UINT)<< (32-(nr_of_guard_bits)-1) ))

#define	GUARD_BITS_S32(x, nr_of_guard_bits)		\
	(IS_OVERFLOW_S32(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x) ((x)<0	? (~ZERO_INT<<(32-(nr_of_guard_bits)-1)) \
															: ~(~ZERO_INT<<(32-(nr_of_guard_bits)-1))) \
												  : (x))

#define	IS_OVERFLOW_S16(x, nr_of_guard_bits)	\
	(((x)^((x)>>1)) & ((~ZERO_USHORT)<< (16-(nr_of_guard_bits)-1) ))

#define	GUARD_BITS_S16(x, nr_of_guard_bits)		\
	((SHORT)(IS_OVERFLOW_S16(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x) ((x)<0	? (~ZERO_SHORT<<(16-(nr_of_guard_bits)-1)) \
															: ~(~ZERO_SHORT<<(16-(nr_of_guard_bits)-1))) \
												  : (x)))

#define IS_OVERFLOW_U32(x, nr_of_guard_bits)	\
	( (x) & ((~ZERO_UINT) << (32-(nr_of_guard_bits)) ) )

#define GUARD_BITS_U32(x, nr_of_guard_bits)	\
	(IS_OVERFLOW_U32(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x) ~((~ZERO_INT) << (32-(nr_of_guard_bits))) : (x) )


#define IS_OVERFLOW_U16(x, nr_of_guard_bits)	\
	( (x) & ((~ZERO_USHORT) << (16-(nr_of_guard_bits)) ) )

#define GUARD_BITS_U16(x, nr_of_guard_bits)	\
	((USHORT)(IS_OVERFLOW_U16(x, nr_of_guard_bits) ? DEBUG_OVERFLOW(x) ~((~ZERO_SHORT) << (16-(nr_of_guard_bits))) : (x) ))


/**
 * 	Macro expressions for exclusivley logging violation of overflow assertion (ASSERT_OVERFLOW)
 */

#endif /* PA_GUARD_H */
