/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/**
*  \defgroup    asrc
*  \author      Otto Linnemann
*  \date        2009-02-11
*  \file        pa_asrc_lagrange.h
*
*  \brief       buffer conversion for asynchronous sample rate converion
*
*/
/*! \addtogroup asrc
* @{
***************************************************************************/


/* === Includes ========================================================== */

#ifndef _PA_ASRC_LAGRANGE_H
#define _PA_ASRC_LAGRANGE_H

#include <pa_asrc_cfg.h>
#include <pa_fixpoint.h>
#include <pa_buffer.h>


/*!
 *	Private module data
 */
typedef struct	{
							/* stores deviations for each channel */
	pa_fract16		derivationLine[PA_ASRC_MAX_CH][ PA_ASRC_INTERPOL_MAX_ORDER + 1 ];
  pa_fract16    derivationMem[PA_ASRC_MAX_CH][ PA_ASRC_INTERPOL_MAX_ORDER ];
	pa_int16		order;								/* order of the interpolation polynomial */
	pa_int16		nr_ch;								/* number of channels used */
#ifdef _PA_ASRC_INTERPOL_FLOAT
	float				index;	/* current time deviation from sample point is delta * T0 */
	float       fractIndexOld;
  float       multiplierChain[ PA_ASRC_INTERPOL_MAX_ORDER + 1 ];
#else
  pa_fract16  fr16index_shr2;  /* current time deviation from sample point is delta * T0 */
  pa_fract16  fr16indexOld_shr2;
  pa_fract16  fr16multiplierChain_shr4[ PA_ASRC_INTERPOL_MAX_ORDER + 1 ];
  pa_fract16  fr16lookupMultI[ PA_ASRC_INTERPOL_MAX_ORDER ];
  pa_fract16  fr16lookupAddI_shr2[ PA_ASRC_INTERPOL_MAX_ORDER ];
#endif
  void*       mutexPtr;
} pa_asrc_interstate;


/*!
 *	PA_ASRC_interstate_init
 *
 *	Initialization of state object for lagrange interpolation
 *
 *	Function parameters
 *
 *	- f :												instance data required for cyclic invocation
 *  - order :     							interpolation order
 *  - sample_rate :							output sample rate
 *  - nr_ch :										number of channels
 *  - mutexPtr;                 mutex for access protection of sample ring buffer
 *
 *	Returnparameters
 *	- R:												error code
 */
pa_int16  PA_ASRC_interstate_init(
  pa_asrc_interstate*   f,
  pa_int16              order,
  pa_int16              nr_ch,
  void*                 mutexPtr
);



/*!
 *	PA_ASRC_buffer_interpol()
 *																																									*/ /*!
 *	sample rate convertion based on polynom interpolation
 *
 *	Function parameters
 *
 *	- f :												instance data required for cyclic invocation
 *  - y :												sample output vector
 *  - samples_to_write					number of samples to store in y
 *	- samples_to_read,					number of sampels to read from the input ring buffer
 *  - inRingBuf :    						input ring buffer to read samples from
 *	- alpha :										sample period extension (positive) or contraction (negative) factor
 */
void PA_ASRC_buffer_interpol(
	pa_asrc_interstate*		f,
	pa_int16*							y,
	const pa_int16				samples_to_write,
	pa_ringBuf*    				inRingBuf,
#ifdef _PA_ASRC_INTERPOL_FLOAT
  const float           ratio,
#else
  const pa_fract16      fr16ratio_shr1
#endif
)
;

#endif /* #ifndef _PA_ASRC_LAGRANGE_H */

