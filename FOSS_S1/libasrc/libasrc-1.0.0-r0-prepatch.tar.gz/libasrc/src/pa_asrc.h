/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/

#ifndef PA_ASRC_H
#define PA_ASRC_H

#include <asrc_config.h>
#include <pa_asrc_lagrange.h>
#include <pa_buffer.h>
#include <pa_osal_cb.h>

#ifdef ENABLE_SAMPLE_STREAM_LOGGING
# include <pa_sample_stream_log.h>
#endif


typedef struct {
  pa_ringBuf                ring;
  int                       channels;
  int                       min_samples;
  void*                     mutexPtr;
  pa_asrc_interstate        lagrange;


  /* implementation based on a three-point controller */
  int                       min_threshold;
  int16_t                   min_alpha;     /* sample period extension when below min threshold */
  int                       max_threshold;
  int16_t                   max_alpha;     /* sample period contraction when above max treshold */
  int16_t                   alpha;

  int16_t                   frames_inserted_cnt;    /* counter for last frames inserted */
  int16_t                   frames_removed_cnt;     /* counter for last frames removed */
  int16_t                   log_after_frames;       /* logging frequency */
  int16_t                   overflow_cnt;           /* counts number of frames lost due to overflow */
  int16_t                   underflow_cnt;          /* counts number of frames lost due to underflow */
  int16_t                   overflowing_cnt;        /* counts number of frames overflowing */
  int16_t                   underflowing_cnt;       /* counts number of frames underflowing */

#ifdef ENABLE_SAMPLE_STREAM_LOGGING
  pa_ss_log_t*              ssLogPtr;
#endif
} pa_asrc_buf;


/**
 * Initialize instance data for asynchronous sample rate conversion
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 *   - buf:                   pointer to buffered data used internally of size
 *                                                  max_samples * channels * 2
 *   - max_samples:           maximum amount of samples to be buffered (max latency)
 *   - min_samples:           minimum amount of samples to be buffered
 *   - channels:              number of interleaving audio channels to be processed
 *   - enableLog:             flag, wenn != 0 enable logging of sample insertion/removing
 *   - mutexAsrcPtr           pointer to mutex for access protection to obj
 *   - mutexLogPtr            pointer to mutex for access protection to logging object
 *   - malloc_fctPtr          pointer to memory allocation function (malloc)
 *   - free_fctPtr            pointer to memory release function (free)
 *   - mutex_lock_fctPtr      callback function to lock access to obj
 *   - mutex_unlock_fctPtr    callback function to unlock access to obj
 *
 * Returnparameter
 *   - R:                     negative error code or 0 in case of success
 */
int pa_asrc_init( pa_asrc_buf* obj,
                  int16_t* buf,
                  int32_t max_samples,
                  int32_t min_samples,
                  int channels,
                  int enableLog,
                  void* mutexAsrcPtr,
                  void* mutexLogPtr,
                  PA_ASRC_MALLOC_CALLBACK_PTR  malloc_fctPtr,
                  PA_ASRC_FREE_CALLBACK_PTR    free_fctPtr,
                  PA_ASRC_MUTEX_CALLBACK_PTR   mutex_lock_fctPtr,
                  PA_ASRC_MUTEX_CALLBACK_PTR   mutex_unlock_fctPtr,
                  PA_ASRC_PRINT_CALLBACK_PTR   message_fctPtr,
                  PA_ASRC_PRINT_CALLBACK_PTR   error_fctPtr );


/**
 * Release instance data for asynchronous sample rate conversion
 *
 * This is exclusively requiresd for logging
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 */
void pa_asrc_release( pa_asrc_buf* obj );


/**
 * Insert samples into asynchronous sample rate converter queue
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 *   - buf:                   pointer to sample buffer to be inserted
 *   - samples:               samples to insert in sample rate conversion queue
 *   - ts                     time stamp of first octett or 0 to use system time
 *
 * Return parameter
 *   - R:                     samples successfully inserted in conversion queue
 */
int32_t pa_asrc_put( pa_asrc_buf* obj, const int16_t* buf, int32_t samples, uint64_t ts );


/**
 * Read samples from asynchronous sample rate converter queue
 *
 * Function parameters
 *   - obj:                   pointer to instance object data
 *   - buf:                   pointer to sample buffer to be read
 *   - samples:               samples to read from sample rate conversion queue
 *   - ts                     time stamp of first octett or 0 to use system time
 *
 * Return parameter
 *   - R:                     samples successfully read in conversion queue
 */
int32_t pa_asrc_get( pa_asrc_buf* obj, int16_t* buf, int32_t samples, uint64_t ts );



#endif  /* of PA_ASRC_H */

