/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *         A C U S T I C

 Copyright by Peiker acustic, Friedrichsdorf / Germany

***************************************************************************/
/**
*   \defgroup   PA_MATH
*   \date       15.01.2009
*
*   \brief      Standard integer types according to ISO C 99 specification
*
* @{
***************************************************************************/



#ifndef PA_STDINT_H
#define PA_STDINT_H

#ifdef HAVE_CONFIG_H
#include <asrc_config.h>
#endif

#ifdef HAVE_STDINT_H
#include <stdint.h>

/*
 *  If the compiler is ISO-C 99 compliant Peiker integer types are
 *  mapped to standard integer types
 */

typedef int8_t          pa_int8;
typedef int16_t         pa_int16;
typedef int32_t         pa_int32;
typedef int64_t         pa_int64;
typedef uint8_t         pa_uint8;
typedef uint16_t        pa_uint16;
typedef uint32_t        pa_uint32;

#else

/*
 *  Otherwise the Peiker integer types have to be mapped agains the
 *  appropriate ANSI-C base types. Make sure that the sizes match!
 */

#warning "Make sure that Peiker integer type definitions match to your platform!"


typedef char            pa_int8;
typedef short           pa_int16;
typedef long int        pa_int32;
typedef long long       pa_int64;
typedef unsigned char   pa_uint8;
typedef unsigned short  pa_uint16;
typedef unsigned long   pa_uint32;


#endif  /* #if defined __STDC_VERSION__  &&   __STDC_VERSION__ >= 199901L */


/*
 *  According to the ANSI-C standard int is considered the
 *  'natural' size of the underlying machine and therefore
 *  executed most efficiently on many platforms. For this
 *  reason we prefer the usage of int instead of a fixed
 *  size number for some counters in real time critical
 *  functions. Unfortunately lint complains if int is used
 *  outside a type definition which is done here.
 */
typedef int             pa_int;
typedef unsigned int		pa_uint;

#endif /* PA_STDINT_H */
