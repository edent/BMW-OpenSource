/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/**
*  \defgroup    asrc
*  \author      Patrick Vicinus
*  \date        2010-09-20
*  \file        pa_asrc_lagrange.c
*
*  \brief       buffer conversion for asynchronous sample rate conversion
*
*/
/*! \addtogroup asrc
* @{
***************************************************************************/


/* === Includes ========================================================== */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <assert.h>
#include <pa_osal_cb.h>
#include <pa_asrc_lagrange.h>
#include <pa_buffer.h>


/*!
 *  PA_ASRC_calcMultiplierChain
 *
 * calculates derivation line for interpolation
 *
 *
 *  Function parameters
 *
 *  - f :                       instance data required for cyclic invocation
 */
#ifdef _PA_ASRC_INTERPOL_FLOAT
void PA_ASRC_calcMultiplierChain(pa_asrc_interstate *f, float fractIndex)
{
    /*this function recursive calculates the multiplieres 2^k*(-D)^[k]/k!*/
    float multI, addI;
    f->multiplierChain[0] = 1;
    for (pa_int16 k = 1; k <= f->order; k++) {
      multI = -(1/(float)k);
      addI = (-floor(f->order/2) + k -1)/k;
      f->multiplierChain[k] = (float)f->multiplierChain[k-1] * 2 * (fractIndex*multI + addI);
    }
}
#else
void PA_ASRC_calcMultiplierChain(pa_asrc_interstate *f, pa_fract16 fr16Index_shr2)
{
    pa_int16 k;
    pa_fract16 fr16multI, fr16addI_shr2;
    /*this function recursive calculates the multiplieres 2^k*(-D)^[k]/k!*/
    f->fr16multiplierChain_shr4[0] = 0x8000L>>4;
    for (k = 1; k <= f->order; k++) {
      fr16multI = f->fr16lookupMultI[k-1];
      fr16addI_shr2 = f->fr16lookupAddI_shr2[k-1];
      f->fr16multiplierChain_shr4[k] = pa_shl(pa_mult(f->fr16multiplierChain_shr4[k-1], (pa_add(pa_mult(fr16Index_shr2, fr16multI), fr16addI_shr2))),2+1);
    }
}
#endif

/*!
 *  PA_ASRC_calcDerivations
 *
 * calculates derivation line for interpolation
 *
 *
 *  Function parameters
 *
 *  - f :                       instance data required for cyclic invocation
 *  - newSampleCh :             channel-vector of new sample
 */
void PA_ASRC_calcDerivations(pa_asrc_interstate *f, pa_fract16* newSamplesCh)
{
  pa_fract16 lastIterationOutput;
  pa_fract16 inValue;
  pa_int16 ch, k;

  /* nullte Ableitung */
  for (ch = 0; ch < f->nr_ch; ch++) {
    f->derivationLine[ch][0]= newSamplesCh[ch];
  }
  for (ch = 0; ch < f->nr_ch; ch++) {
    lastIterationOutput = f->derivationLine[ch][0];
    for (k = 1; k <= f->order; k++) {
      /* berechne recursive die folgenden Ableitungen bis Kter Ordnung divided by 2^k */
      inValue = pa_shr(lastIterationOutput, 1);
      lastIterationOutput = pa_sub(inValue, f->derivationMem[ch][k-1]);
      f->derivationMem[ch][k-1] = inValue;
      f->derivationLine[ch][k] = lastIterationOutput;
    }
  }
}

/*!
 *  PA_ASRC_calcNextSample
 *
 * calculates the next interpolated sample
 *
 * the next sample with a indexDelta of ratio is taken out of the global buffer
 * inputFile. The interpolation is done by Lagrange-Interpolation, calculated
 * in the by Cagatay Candan in "An Efficient Filtering Structure for Lagrange
 * Interpolation" suggested way. This method is modified only in one detail:
 * Candan suggested to implement the multipliers (-D)^[N])/N! recursivily after
 * each deviatio block. Becauser this implementation cannot handle modifications
 * of D while processing, these multipliers are shifted in front of the summation
 * of each stage. The new block diagram is:
 *
 *
 *->----- 1 - z^(-1) ------- 1 - z^(-1) ------- 1 - z^(-1)  ..... 1 - z^(-1) ---
 *  |                  |                  |                                    |
 *  |                  *(-D)              *(-D)(-D+1)/2                    (-D)^[N]/N!
 *  |                  |                  |                                    |
 *  -------------------+------------------+------------------------------------+---->
 *
 *  Function parameters
 *
 *  - f :                       instance data required for cyclic invocation
 *  - outCh :                   output buffer for the next sample of each channel
 *  - inRingBuf:                ring buffer of input data
 *  Returnparameters
 *  - R:                        error code
 */
#ifdef  _PA_ASRC_INTERPOL_FLOAT
void PA_ASRC_calcNextSample(pa_asrc_interstate *f, pa_int16 *outCh, pa_ringBuf *inRingBuf, float ratio)
#else
void PA_ASRC_calcNextSample(pa_asrc_interstate *f, pa_int16 *outCh, pa_ringBuf *inRingBuf, pa_fract16 fr16ratio_shr1)
#endif
{
  pa_int16 n, ch, k;
  pa_int16 deltaIndex;
  pa_int16 tempCh[PA_ASRC_INTERPOL_MAX_ORDER];
#ifdef  _PA_ASRC_INTERPOL_FLOAT
  float fractIndex;
  pa_fract16 out;
#else
  pa_fract16 fr16Index_shr2;
  pa_fract32 out_shr4;
#endif
  /* Calculates the integer index delta */
#ifdef _PA_ASRC_INTERPOL_FLOAT
  f->index = f->index + ratio;
  deltaIndex = floor(f->index);
  /* calcualtes new fraction index. "One minus" because the inpolation is done */
  /*     based on latest incoming sample - we have to look from right to left */
  f->index = f->index - deltaIndex;
  fractIndex = 1 - f->index;
#else
  f->fr16index_shr2 = pa_add(f->fr16index_shr2, pa_shr(fr16ratio_shr1, 1));
  deltaIndex = pa_shr(f->fr16index_shr2, 13);
  f->fr16index_shr2 = pa_sub(f->fr16index_shr2, pa_shl(deltaIndex, 13));
  fr16Index_shr2 = pa_sub((0x8000L>>2), f->fr16index_shr2);
#endif

  /* fill new samples in deviation line (if needed) */
  for (n = 0; n<deltaIndex; n++) {
    pa_lock( f->mutexPtr );
    pa_ringBufGetData(inRingBuf, (pa_int8 *) tempCh, f->nr_ch*sizeof(pa_int16) );
    pa_unlock( f->mutexPtr );
    PA_ASRC_calcDerivations(f, tempCh);
  }

  /* calculates new multiplier chain if needed */
#ifdef _PA_ASRC_INTERPOL_FLOAT
  if (fractIndex != f->fractIndexOld) {
    PA_ASRC_calcMultiplierChain(f, fractIndex);
    f->fractIndexOld = fractIndex;
  }
#else
  if (fr16Index_shr2 != f->fr16indexOld_shr2) {
    PA_ASRC_calcMultiplierChain(f, fr16Index_shr2);
    f->fr16indexOld_shr2 = fr16Index_shr2;
  }
#endif
  /* Calculate interpolator output */
  /* sample = multiplierChain'* derivationVector; */
  for (ch = 0; ch <  f->nr_ch; ch++) {
#ifdef _PA_ASRC_INTERPOL_FLOAT
    out = 0;
#else
    out_shr4 = 0;
#endif
    for (k = 0; k <= f->order; k++) {
#ifdef _PA_ASRC_INTERPOL_FLOAT
      out = out + f->multiplierChain[k] * f->derivationLine[ch][k];
#else
      out_shr4 = pa_L_add(out_shr4, pa_L_mult(f->fr16multiplierChain_shr4[k], f->derivationLine[ch][k]));
#endif
    }
#ifdef _PA_ASRC_INTERPOL_FLOAT
    outCh[ch] = (pa_fract16) out;
#else
    outCh[ch] = (pa_fract16) pa_extract_h(pa_L_shl_s(out_shr4, 4));
#endif
  }
}


/*!
 *	PA_ASRC_interstate_init
 *
 *	Initialization of state object for lagrange interpolation
 *
 *	Function parameters
 *
 *	- f :												instance data required for cyclic invocation
 *  - order :     							interpolation order
 *  - sample_rate :							output sample rate
 *  - nr_ch :										number of channels
 *  - mutexPtr;                 mutex for access protection of sample ring buffer
 *
 *	Returnparameters
 *	- R:												error code
 */
pa_int16  PA_ASRC_interstate_init(
  pa_asrc_interstate*   f,
  pa_int16              order,
  pa_int16              nr_ch,
  void*                 mutexPtr
)
{
#ifndef _PA_ASRC_INTERPOL_FLOAT
  pa_int16 k;
#endif
	memset( f, 0, sizeof(pa_asrc_interstate) );
	f->order								= order;
	f->nr_ch								= nr_ch;
  f->mutexPtr             = mutexPtr;

#ifndef _PA_ASRC_INTERPOL_FLOAT
	/* Initialisation of fixpoint-lookup tables */
  for (k = 1; k <= f->order; k++) {
    f->fr16lookupMultI[k-1] = -(1/(float)k)*pow(2,15);
    f->fr16lookupAddI_shr2[k-1] = ((-(float)(f->order-1)/2 + k -1)/(float)k) * pow(2,13) ;
  }
#endif
	return true;
}


/*!
 *	PA_ASRC_buffer_interpol()
 *																																									*/ /*!
 *	sample rate convertion based on polynom interpolation
 *
 *	Function parameters
 *
 *	- f :												instance data required for cyclic invocation
 *  - y :												sample output vector
 *  - samples_to_write					number of samples to store in y
 *	- samples_to_read,					number of sampels to read from the input ring buffer
 *  - inRingBuf :    						input ring buffer to read samples from
 *	- alpha :										sample period extension (positive) or contraction (negative) factor
 */
void PA_ASRC_buffer_interpol(
	pa_asrc_interstate*		f,
	pa_int16*							y,
	const pa_int16				samples_to_write,
	pa_ringBuf*    				inRingBuf,
#ifdef _PA_ASRC_INTERPOL_FLOAT
  const float           ratio,
#else
  const pa_fract16      fr16ratio_shr1
#endif
)
{
  pa_int16  outCh[PA_ASRC_MAX_CH];
	const int	nr_ch = f->nr_ch;
  pa_int16 i;

  for (i=0; i<samples_to_write; i++) {
    /* Calcualte next interpolated value for each channel */
#ifdef _PA_ASRC_INTERPOL_FLOAT
    PA_ASRC_calcNextSample(f, outCh, inRingBuf, ratio);
#else
    PA_ASRC_calcNextSample(f, outCh, inRingBuf, fr16ratio_shr1);
#endif
    /* store in output buffer */
    memcpy(&y[i*nr_ch], outCh, nr_ch*sizeof(pa_int16));
  }
}

