/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *         A C U S T I C

 Copyright by Peiker acustic, Friedrichsdorf / Germany

 ***************************************************************************/
/**
 *  \defgroup sr_est (SignalProcessing)
 *  \authors  Patrick Vicinus, Otto Linnemann
 *  \date 01.02.2008
 *  \version  $Revision: 1.1.2.2 $
 *
 *  \brief  Sample rate estimator
 *
 */
/*! \addtogroup asrc
 *  @{
 ***************************************************************************/


#ifndef PA_SR_ESTIMATE_CFG_H
#define PA_SR_ESTIMATE_CFG_H


/* === Defines =========================================================== */

/*!
 *		if _PA_ASRC_LAGRANGE is defined we use lagrange interpolation instead
 * 		of the up to now used sample strike out and reiteration algorithm
 */
#define _PA_ASRC_LAGRANGE


/*
 *    If PA_ASRC_ERROR_OUTPUT is defined, errors are logged at stderr
 */
#ifdef DEBUG
  #define PA_ASRC_ERROR_OUTPUT
#endif


/*
 *    If PA_ASRC_VERBOSE_OUTPUT is defined, verbose processing information
 *    is logged at stderr
 */
#ifdef DEBUG
  #define PA_ASRC_VERBOSE_OUTPUT
#endif


/*
 *    If PA_ASRC_DEBUG_OUTPUT is defined, all debugging output is printed
 *    to stderr (including all buffer conversion data)
 */
#ifdef DEBUG
// #define PA_ASRC_DEBUG_OUTPUT
#endif


/*!
 *	Including of floating point implementation
 */
//#define _PA_ASRC_INTERPOL_FLOAT


/* === Constants ========================================================= */


/**
 *    Defines the maximum number of insertions respectively deletions
 *    for one invocation of pa_aresamp
 */
#define  PA_ASRC_MAX_BUF_INSERTIONS_OR_DELETIONS         100




/**
 *    Time for short-term expectation [seconds]
 */
#define PA_ASRC_EXPECTATION_TIME                        1



/**
 *    Time for long-term expectation [seconds]
 */
#define PA_ASRC_RECURSIVE_EXPECTATION_TIME              30



/*!	
 * 	Maximal lagrange interpolation order required for buffer size limitation
 */
#define PA_ASRC_INTERPOL_MAX_ORDER		10

/*!
 *	Maximal number of channels to process required for buffer size limitation
 */
#define PA_ASRC_MAX_CH								2
/**
 *    Memory check for development if ASRC_CHECK_MEMORY is defined
 */
#define ASRC_CHECK_MEMORY


#ifdef ASRC_CHECK_MEMORY
  #define ASRC_CHECK_MEMORY_TABLE   checkMallocTable();
#else
  #define ASRC_CHECK_MEMORY_TABLE
#endif



/**
 *    Default configuration for the sample rate estimator
 */
#define PA_ASRC_EST_DEFAULT { \
      48000,      /* expected sample rate */ \
      1,          /* defines the number of ticks per frame */  \
      1024,       /* Number of expected Samples in investigated time-frame */  \
      80000,      /* external Buffersize */  \
      3 /* 3 */  /* normal max acceptable sample loss or gain per frame */  \
      }



/**
 *    Default configuration
 */
#define ASRC_DEFAULT_CONFIG { \
    PA_ASRC_EST_DEFAULT,  /* sample rate estimator configurtion (see above) */ \
    2,            /* number of channels */  \
    3,             /* wanted delta between adjoining samples */  \
    40000         /* prebuffering */ \
    }



#endif /* PA_SR_ESTIMATE_CFG_H */
