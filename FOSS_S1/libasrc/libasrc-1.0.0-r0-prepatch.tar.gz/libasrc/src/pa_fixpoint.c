/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/
/*
*  History:
*  $Log: pa_fixpoint.c,v $
*  Revision 1.3  2007/10/11 14:00:17  PEIKER\vic
*  MY09 PAEC Rel4 Build6
*
*  Revision 1.2  2007/08/28 15:32:42  PEIKER\vic
*  MY09 - Processing: Initial Version
*
*  Revision 1.1  2007/05/29 14:43:15  PEIKER\FA
*  initial
*
*  Revision 1.2  2007/04/22 15:12:55  GB
*  add a cast to correct problem of assignment bound
*
*  Revision 1.1.1.1  2007/01/17 15:02:49  NT-SERVER\FA
*  no message
*
*  Revision 1.2  2006/08/01 12:39:42  vic
*  Addaed agc-activated, impproved norm calculation
*
*  Revision 1.1  2006/06/27 22:09:09  vic
*  Initial Version
*
*
***************************************************************************/


// #define PA_FIX_PREC     (PA_FRACT16_BIT - 1)
// #define PA_FIX_SCALE    (((pa_fract16)1) << PA_FIX_PREC)
//
// #define PA_FLOAT2FIX(x) ((pa_fract16)((float)(x)*(float)PA_FIX_SCALE))
// #define PA_FIX2FLOAT(a) ((pa_real_t)(a)/(float)PA_FIX_SCALE)
// #define PA_INT2FIX(a)   ((pa_fract16)(a)<<PA_FIX_PREC)
// #define PA_FIX2INT(a)   ((int)(a)>>PA_FIX_PREC)
//
// #define FIXMUL(a,b,t,p)     ((t)(((long long)(a) * (long long)(b))>>p))
// #define FIXMUL_NOCARRY(a,b) FIXMUL(a,b,pa_fract16,PA_FIX_PREC)
// #define FIXMUL_CARRY(a,b)   FIXMUL(a,b,pa_carry_t,PA_FIX_PREC)

#include "pa_fixpoint.h"
#include <stdio.h>

void pa_f32MaxAbsVector(pa_fract32 *out, pa_fract32 *in, pa_int16 n)
/* Finde Maximum eines Vectors */
{
	int i;
    pa_fract32 fr32MaxPos = 0;
    pa_fract32 fr32MinNeg = 0;

	for (i=0; i<n; i++)
	{
		if (in[i]>fr32MaxPos)
		{
			fr32MaxPos = in[i];
			fr32MinNeg = -in[i];
		}
		else
		if (in[i]<fr32MinNeg)
		{
			fr32MinNeg = in[i];
			fr32MaxPos = -in[i];
		}
	}
	out[0] = fr32MaxPos;
}

pa_fract16 pa_vecmax_fr16(pa_fract16 *in, pa_int32 n)
/* Finde Maximum eines Vectors */
{
	int i;
    pa_fract16 fr16MaxPos = 0;

	for (i=0; i<n; i++)
	{
		if (in[i]>fr16MaxPos)
		{
			fr16MaxPos = in[i];
		}
	}
	return fr16MaxPos;
}

pa_fract32 pa_vecmax_fr32(pa_fract32 *in, pa_int32 n)
/* Finde Maximum eines Vectors */
{
	int i;
    pa_fract32 fr32MaxPos = 0;

	for (i=0; i<n; i++)
	{
		if (in[i]>fr32MaxPos)
		{
			fr32MaxPos = in[i];
		}
	}
	return fr32MaxPos;
}

pa_fract32 pa_vecmin_fr32(pa_fract32 *in, pa_int32 n)
/* Finde Maximum eines Vectors */
{
	int i;
    pa_fract32 fr32MinNeg = 0;

	for (i=0; i<n; i++)
	{
		if (in[i]<fr32MinNeg)
		{
			fr32MinNeg = in[i];
		}
	}
	return fr32MinNeg;
}

pa_fract16 pa_vecmin_fr16(pa_fract16 *in, pa_int32 n)
/* Finde Maximum eines Vectors */
{
	int i;
    pa_fract16 fr16MinNeg = 0;

	for (i=0; i<n; i++)
	{
		if (in[i]<fr16MinNeg)
		{
			fr16MinNeg = in[i];
		}
	}
	return fr16MinNeg;
}


// pa_uint16 pa_normPos(pa_fract32 in)
// /* Find leading zeros */
// {	int i;
// 	pa_fract32 t = in;
// 	if(t==0) return 0;
// 	else t=t>>1;
// 	for (i=30; i>=0; i--)
// 	{
// 		if(t==0) return i;
// 		else t=t>>1;
// 	}
// 	return 0;
// }

pa_uint16 pa_L_norm(pa_fract32 in)
/* Find leading zeros or ones */
{
	return pa_L_normPos(pa_L_abs_s(in));
}


// pa_uint16 pa_norm_l(pa_fract16 in)
// /* Find leading zeros or ones */
// {	int i;
// 	pa_fract16 t = pa_abs_s(in);
// 	if(t==0) return 0;
// 	else t=t>>1;
// 	for (i=14; i>=0; i--)
// 	{
// 		if(t==0) return i;
// 		else t=t>>1;
// 	}
// 	return 0;
// }

pa_uint16 pa_norm(pa_fract16 in)
/* Find leading zeros or ones */
{	int bitPos = -1;
	pa_uint16 mask = 0xff00;
	pa_int16 nextShift= 8;
	//pa_fract16 akt = in;
	pa_uint16 t = (pa_uint16) pa_abs_s(in);

	do
	{
		if ((t&mask) > 0)
		{
			nextShift=nextShift>>1;
			mask=mask<<nextShift;
		}
		else
	{
			bitPos+=nextShift;
			nextShift=nextShift>>1;
			mask=mask>>nextShift;
	}
	} while(nextShift);
	return bitPos;
}


void pa_vecvmlt_fr16(pa_fract16 *in0, pa_fract16 *in1, pa_fract16 *out, pa_int16 n)
{
	int i;
	for (i=0; i<n; i++)
	{
		out[i] = pa_mult(in0[i], in1[i]);
	}
}

void pa_vecsmlt_fr16(pa_fract16 *in, pa_fract16 scalar, pa_fract16 *out, pa_int16 n)
{
	int i;
	for (i=0; i<n; i++)
	{
		out[i] = pa_mult(in[i], scalar);
	}
}



