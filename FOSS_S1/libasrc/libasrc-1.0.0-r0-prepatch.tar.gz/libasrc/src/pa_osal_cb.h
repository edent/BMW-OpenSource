/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/

#ifndef PA_OSAL_CB_PROTOYPES_H
#define PA_OSAL_CB_PROTOYPES_H

#include <stdlib.h>
#include <stddef.h>

/*! Callback function pointer type which is used for mutual exclusion
 *  when accessing the element of the PA-DSP object */
typedef int (* PA_ASRC_MUTEX_CALLBACK_PTR )( void* mutexPtr );

/*! Callback function pointer type abstracting libc function malloc */
typedef void* (* PA_ASRC_MALLOC_CALLBACK_PTR )( size_t size );

/*! Callback function pointer type abstracting libc function free */
typedef void  (* PA_ASRC_FREE_CALLBACK_PTR )( void* p );

/*! Callback function pointer to printf like message logging function */
typedef int   (* PA_ASRC_PRINT_CALLBACK_PTR)( const char* format, ... );


extern PA_ASRC_MUTEX_CALLBACK_PTR  pa_lock;
extern PA_ASRC_MUTEX_CALLBACK_PTR  pa_unlock;
extern PA_ASRC_MALLOC_CALLBACK_PTR pa_malloc;
extern PA_ASRC_FREE_CALLBACK_PTR   pa_free;
extern PA_ASRC_PRINT_CALLBACK_PTR  pa_message;
extern PA_ASRC_PRINT_CALLBACK_PTR  pa_error;


#endif /* #ifndef PA_OSAL_CB_PROTOYPES_H */
