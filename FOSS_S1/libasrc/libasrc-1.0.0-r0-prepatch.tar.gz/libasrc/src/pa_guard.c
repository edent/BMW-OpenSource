/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

     Copyright by Peiker acustic, Friedrichsdorf / Germany

***************************************************************************/
/**
*  \defgroup aec Filterbank (SignalProcessing)
*  \author	Otto Linnemann
*  \date	04.05.2007
*  \version	$Revision: 1.1 $
*
*  \brief	Macros for checking and saturation of guard bits
*/
/*!	\addtogroup aec
***************************************************************************/


#include <stdio.h>
#include <stdarg.h>
#include "pa_guard.h"


/**
 * 	wrapping function to fprintf, used to be able to set a breakpoint in order
 *  to find out which portion of the code caused the overflow. Just add a 
 * 	break point to invocation of the vfprintf function
 * 
 * 	see printf
 */
int fprintf_overflow(FILE *fp, const char *fmt, ... )
{
	int retCode;
	
	va_list	ap;
	
	va_start( ap, fmt);
	retCode = vfprintf( fp, fmt, ap );
	va_end( ap );
	
	return retCode;
}
