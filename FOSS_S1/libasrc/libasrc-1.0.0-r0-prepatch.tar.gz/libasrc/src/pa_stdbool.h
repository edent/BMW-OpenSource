/**************************************************************************
  
       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *         A C U S T I C

 Copyright by Peiker acustic, Friedrichsdorf / Germany

***************************************************************************/
/**
*   \defgroup   PA_MATH 
*   \date       15.01.2009
*  
*   \brief      Standard bool type
*
* @{
***************************************************************************/


#ifndef PA_STDBOOL_H
#define PA_STDBOOL_H


#ifndef true
#define true    1U
#endif
#ifndef false
#define false   0U
#endif
#ifndef TRUE
#define TRUE    true
#endif
#ifndef FALSE
#define FALSE   false
#endif


/* changed this for better performance on most systems, 2009-01-15, OL */
/* typedef unsigned char   pa_bool; */

typedef unsigned int   pa_bool;

#endif /* PA_STDBOOL_H */
