/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/
/*
*  History:
*  $Log: pa_fixpoint.h,v $
*  Revision 1.3  2007/10/11 14:00:11  PEIKER\vic
*  MY09 PAEC Rel4 Build6
*
*  Revision 1.2  2007/08/28 15:33:03  PEIKER\vic
*  MY09 - Processing: Initial Version
*
*  Revision 1.1  2007/05/29 14:43:15  PEIKER\FA
*  initial
*
*  Revision 1.1.1.1  2007/01/17 15:02:49  NT-SERVER\FA
*  no message
*
*  Revision 1.2  2006/08/01 12:38:46  vic
*  updates
*
*  Revision 1.1  2006/06/27 22:09:55  vic
*  Initial Version
*
*
***************************************************************************/

#ifndef PA_FIXPOINT_H
#define PA_FIXPOINT_H


/**************************************************************************
 INCLUDES
**************************************************************************/
#ifdef HAVE_CONFIG_H
#include <asrc_config.h>
#endif

#include "pa_stdint.h"
#include "pa_stdbool.h"
#include "pa_fract.h"
#include "pa_guard.h"

/* ----------------------- Blackfin specific -----------------------------*/

#ifdef __blackfin__
#include "fract.h"
#include "libetsi.h"
#include <vector.h>
#endif





/**************************************************************************
 DEFINES
**************************************************************************/
/*lint -emacro(702,pa_shr)   shift right of signed entity is intended here */
/*lint -emacro(960,pa_shr)   bitwise operator applied to signed underlying type is intended here */

#define FIXPOINT


#define PA_FRACT16_BIT  16				/* bits in a fract16 */
#define PA_FRACT32_BIT  32     		/* bits in a fract32 */

#define PA_FRACT16_MAX  0x7fff			/* max value of a fract16 */
#define PA_FRACT16_MIN  (-0x7fff - 1)			/* min value of a fract16 */

#define PA_FRACT32_MAX  0x7fffffff	/* max value of a fract32 */
#define PA_FRACT32_MIN  (-0x7fffffff - 1)	/* min value of a fract32 */

/* Set fixpoint precision to 15 bit + sign bit */
#define PA_FIX_PREC     (PA_FRACT16_BIT - 1)
/* #define PA_FIX_SCALE    (((pa_fract16)1) << PA_FIX_PREC) corresponds to 32768 */
#define PA_FIX_SCALE		PA_FRACT16_MAX	/* we use 16 bit pos. max. value instead now */

#define pa_re(c)    ((c).re)
#define pa_im(c)    ((c).im)


/**************************************************************************
 TYPEDEFS
**************************************************************************/
#ifdef FIXPOINT
  #define pa_real		  float	  /* Floating point */
  #define pa_carry_t  fract32	/* 32 bit fractional fixpoint */
#else
  #define pa_real     float   /* Floating point precision */
  #define pa_fract16	float		/* Floating point precision */
  #define pa_carry_t	float		/* Floating point precision */
#endif

typedef short		pa_exponent;

void pa_f32MaxAbsVector(pa_fract32 *out, pa_fract32 *in, pa_int16 n);
pa_fract32 pa_f32MaxVector(pa_fract32 *in, pa_int32 n);
pa_fract32 pa_f32MinVector(pa_fract32 *in, pa_int32 n);
pa_fract16 pa_vecmax_fr16(pa_fract16 *in, pa_int32 n);
pa_fract16 pa_vecmin_fr16(pa_fract16 *in, pa_int32 n);
void pa_vecvmlt_fr16(pa_fract16 *in0, pa_fract16 *in1, pa_fract16 *out, pa_int16 n);
void pa_vecsmlt_fr16(pa_fract16 *in, pa_fract16 scalar, pa_fract16 *out, pa_int16 n);

static inline pa_uint16 pa_L_normPos(pa_fract32 in);
pa_uint16 pa_norm(pa_fract16 in);
pa_uint16 pa_L_norm(pa_fract32 in);

static __inline__ pa_fract16 pa_max_fr16(pa_fract16 a, pa_fract16 b);
static __inline__ pa_fract16 pa_min_fr16(pa_fract16 a, pa_fract16 b);
static __inline__ pa_fract32 pa_min_fr32(pa_fract32 a, pa_fract32 b);
static __inline__ pa_fract32 pa_max_fr32(pa_fract32 a, pa_fract32 b);
#ifdef PA_LOG_OVERFLOW
    #define pa_add(a,b)   pa_add_exe(a, b, __FILE__, __LINE__)
    static __inline__ pa_fract16 pa_add_exe(pa_fract16 a, pa_fract16 b, char* file, pa_uint16 line);
#else
    #define pa_add(a,b)   pa_add_exe(a, b)
    static __inline__ pa_fract16 pa_add_exe(pa_fract16 a, pa_fract16 b);
#endif

static __inline__ pa_fract16 pa_add_s(pa_fract16 a, pa_fract16 b);
static __inline__ pa_fract32 pa_L_add_s(pa_fract32 a, pa_fract32 b);
#ifdef PA_LOG_OVERFLOW
    #define pa_L_add(a,b)   pa_L_addDebug(a, b, __FILE__, __LINE__)
#else
    static __inline__ pa_fract32 pa_L_add(pa_fract32 a, pa_fract32 b);
#endif
static __inline__ pa_fract16 pa_sub(pa_fract16 a, pa_fract16 b);
static __inline__ pa_fract16 pa_sub_s(pa_fract16 a, pa_fract16 b);
#ifdef PA_LOG_OVERFLOW
    #define pa_L_sub(a,b)   pa_L_subDebug(a, b, __FILE__, __LINE__)
#else
    static __inline__ pa_fract32 pa_L_sub(pa_fract32 a, pa_fract32 b);
#endif
static __inline__ pa_fract16 pa_mult(pa_fract16 a, pa_fract16 b);
static __inline__ pa_fract16 pa_mult_r(pa_fract16 a, pa_fract16 b);
static __inline__ pa_fract32 pa_L_mult(pa_fract16 a, pa_fract16 b);
static __inline__ pa_fract32 pa_mult32_16(pa_fract32 a, pa_fract16 b);
static __inline__ pa_fract32 pa_mult32_16_add(pa_fract32 fr32a1, pa_fract16 fr16a2, pa_fract32 fr32b1, pa_fract16 fr16b2);
#ifdef PA_LOG_OVERFLOW
    #define pa_shr(a,b)   pa_shr_exe(a, b, __FILE__, __LINE__)
    static __inline__ pa_fract16 pa_shr_exe(pa_fract16 a, pa_int16 n, char* file, pa_uint16 line);

#else
	/* Compiler optimization for pa_shr_exe does not work properly on GHS Blackfin compiler. For this reason we use the normal C macro here */
    #define pa_shr(a,b)   ((a)>>(b))

	/* This implementation is currently not used due to GHS BlackFin compiler problems */
    static __inline__ pa_fract16 pa_shr_exe(pa_fract16 a, pa_int16 n);
#endif
static __inline__ pa_fract16 pa_shr_s(pa_fract16 a, pa_int16 n);
#ifdef PA_LOG_OVERFLOW
    #define pa_L_shr(a,b)   pa_L_shr_exe(a, b, __FILE__, __LINE__)
    static __inline__ pa_fract32 pa_L_shr_exe(pa_fract32 a, pa_int16 n, char* file, pa_uint16 line);

#else
    #define pa_L_shr(a,b)   pa_L_shr_exe(a, b)
    static __inline__ pa_fract32 pa_L_shr_exe(pa_fract32 a, pa_int16 n);
#endif
static __inline__ pa_fract32 pa_L_shr_s(pa_fract32 a, pa_int16 n);

#ifdef PA_LOG_OVERFLOW
    #define pa_shl(a,b)     pa_shl_debug( a, b, __FILE__, __LINE__)
    #define pa_shl_s(a,b)   pa_shl_s_exe( a, b, __FILE__, __LINE__)
#else
    #define pa_shl(a,b)     pa_shl_exe( a, b )
    #define pa_shl_s(a,b)   pa_shl_s_exe( a, b )
#endif

#ifdef PA_LOG_OVERFLOW
     static __inline__ pa_fract32 pa_L_shl_s_debug(pa_fract32 a, pa_int16 n, char* file, pa_uint16 line);
    #define pa_L_shl_s(a,b)   pa_L_shl_s_debug(a, b, __FILE__, __LINE__)
#else
    static __inline__ pa_fract32 pa_L_shl_s(pa_fract32 a, pa_int16 n);
#endif
#ifdef PA_LOG_OVERFLOW
     static __inline__ pa_fract32 pa_L_shl_debug(pa_fract32 a, pa_int16 n, char* file, pa_uint16 line);
    #define pa_L_shl(a,b)   pa_L_shl_debug(a, b, __FILE__, __LINE__)
#else
    static __inline__ pa_fract32 pa_L_shl(pa_fract32 a, pa_int16 n);
#endif
static __inline__ pa_fract16 pa_negate(pa_fract16 a);
static __inline__ pa_fract32 pa_L_negate(pa_fract32 a);
static __inline__ pa_fract16 pa_extract_l_sat(pa_fract32 a);
static __inline__ pa_fract16 pa_extract_h(pa_fract32 a);
static __inline__ pa_fract16 pa_extract_r(pa_fract32 a);
static __inline__ pa_fract16 pa_extract_s(pa_fract32 a);
static __inline__ pa_fract16 pa_abs_s(pa_fract16 a);
static __inline__ pa_fract32 pa_L_abs_s(pa_fract32 a);
static __inline__ pa_fract32 pa_L_deposit_h(pa_fract16 a);
static __inline__ pa_fract32 pa_L_deposit_l(pa_fract16 a);


/* Definition of inline function in the header file*/
/*lint -e960   : allow object/function definition in header files */
/*lint -e704 -e703 -e702 -e701 : allow shifts of signed quantities */
static __inline__ pa_fract16 pa_abs_s(pa_fract16 a)
{
	pa_fract16 ret;
  if (a<0)
	{
		ret = pa_negate(a);
	}
	else
	{
		ret = a;
	}
	return ret;
}

static __inline__ pa_fract32 pa_L_abs_s(pa_fract32 a)
{
	pa_fract32 ret;
  if (a<0)
	{
		ret = pa_L_negate(a);
	}
	else
	{
		ret = a;
	}
	return ret;
}


static __inline__ pa_fract16 pa_add_s(pa_fract16 a, pa_fract16 b)
{
/*#if  _ARM_VERSION < 4*/
	pa_fract32 ret_fr32;
	ret_fr32 = (pa_fract32)a + (pa_fract32)b;
	if (ret_fr32 < PA_FRACT16_MIN)
	{
		ret_fr32 = (pa_fract32) PA_FRACT16_MIN;
	}
	else
	if (ret_fr32 > PA_FRACT16_MAX)
	{
		ret_fr32 = (pa_fract32) PA_FRACT16_MAX;
	}
	return (pa_fract16) ret_fr32;
/*#else */
/*	return (pa_fract16) _mm_adds_pi16 ((__m64) a, (__m64) b);*/
/*#endif */
}

#ifdef PA_LOG_OVERFLOW
static __inline__ pa_fract16 pa_add_exe(pa_fract16 a, pa_fract16 b, char* file, pa_uint16 line)
#else
static __inline__ pa_fract16 pa_add_exe(pa_fract16 a, pa_fract16 b)
#endif
{
#ifdef PA_LOG_OVERFLOW
    ASSERT_OVERFLOW_OCCURRED((a+b) == pa_add_s(a,b), file, line);
#endif
	return a+b;
}

#ifndef PA_LOG_OVERFLOW
static __inline__ pa_fract32 pa_L_add(pa_fract32 a, pa_fract32 b)
{
	return a+b;
}
#else
static  __inline__ pa_fract32 pa_L_addDebug(pa_fract32 a, pa_fract32 b, char* file, pa_uint16 line)
{
    ASSERT_OVERFLOW_OCCURRED(pa_L_add_s(a, b)==(a+b), file, line);
	return a+b;
}
#endif

static pa_fract32 __inline__ pa_L_add_s(pa_fract32 a, pa_fract32 b)
{
    pa_fract32 ret;
    if ((a>0) && (b>0))
    {
        if (a >= PA_FRACT32_MAX-b)   ret = PA_FRACT32_MAX;
        else                         ret = a + b;
    }
    else if ((a<0) && (b<0))
    {
        if (a <= PA_FRACT32_MIN-b)   ret = PA_FRACT32_MIN;
        else                         ret = a + b;
    }
    else
    {
      ret = a + b;
    }
    return ret;
}

static __inline__ pa_fract16 pa_sub_s(pa_fract16 a, pa_fract16 b)
{
	return pa_add_s(a, -b);
}

static __inline__ pa_fract16 pa_sub(pa_fract16 a, pa_fract16 b)
{
    ASSERT((a-b) == pa_sub_s(a,b));
	return a-b;
}

#ifndef PA_LOG_OVERFLOW
static __inline__ pa_fract32 pa_L_sub(pa_fract32 a, pa_fract32 b)
{
	return a-b;
}
#else
static __inline__ pa_fract32 pa_L_subDebug(pa_fract32 a, pa_fract32 b, char* file, pa_uint16 line)
{
	ASSERT_OVERFLOW_OCCURRED(pa_L_add_s(a, -b)==(a-b), file, line);
    return a-b;
}
#endif
static __inline__ pa_fract16 pa_mult(pa_fract16 a, pa_fract16 b)
{
	return (pa_fract16)(((pa_fract32)a * (pa_fract32)b)>>15);
}
static __inline__ pa_fract16 pa_mult_r(pa_fract16 a, pa_fract16 b)
{
	pa_fract32 fr32res;
	pa_fract16 ret;
	pa_uint16 res_low;

	fr32res = pa_L_mult(a,b);
	res_low = (pa_uint16) fr32res;
	if (res_low > 0x8000U)
	{
		ret = pa_add((pa_fract16)(fr32res>>16),1);
	}
	else
	{
		ret = (pa_fract16) (fr32res>>16);
	}
	return ret;
}

static __inline__ pa_fract32 pa_L_mult(pa_fract16 a, pa_fract16 b)
{
//	pa_fract32 ret;
/*	ret = (pa_fract32)((pa_fract32)a * (pa_fract32)b);
	printf("l_mult:%d,%d,%ld\n", a, b, ret);
	return ret;*/
	return (pa_fract32)(((pa_fract32)a * (pa_fract32)b)<<1);
}

static __inline__ pa_fract32 pa_mult32_16(pa_fract32 a, pa_fract16 b)
{
#if defined(_ARM_VERSION) && _ARM_VERSION >= 4
  /* ARM v4 allows 64-Bit Multiplications */
	register pa_fract32 t1, t2, res_hi, res_lo;
	t1 = (pa_fract32)a;
	t2 = ((pa_fract32)b)<<16;
	asm ("smull %[lo],%[hi],%[a],%[b]"
	      : [lo] "=&r" (res_lo), [hi] "=&r" (res_hi)
	      : [a] "r" (t1), [b] "r" (t2));

	return
      ( (pa_fract32)res_hi << 1 )
#ifdef _ARM_BITEXACT
      | ( (res_lo & 0x80000000UL) >> 31 )
#endif
      ;

#elif defined(__blackfin__)
    return mult_fr1x32x32(a, pa_L_deposit_h(b));
#else
	return (pa_fract32) ((pa_fract64)((pa_fract64)a*((pa_fract64)b))>>15);
#endif
}

static __inline__ pa_fract32 pa_mult32_16_add(pa_fract32 fr32a1, pa_fract16 fr16a2, pa_fract32 fr32b1, pa_fract16 fr16b2)
//{ u = pa_mult32_16(x, c)-pa_mult32_16(y, s);  v = pa_mult32_16(x, s)+pa_mult32_16(y, c); }
{
#if defined(_ARM_VERSION) && (__ARM_VERSION >= 4) && (!defined( _ARM_BITEXACT ))
	/* ARM v4 allows 64-Bit Multiplications */
	register pa_fract32 t1, t2, t3, t4, res_hi, res_lo;
	t1 = (pa_fract32)fr32a1;
	t2 = ((pa_fract32)fr16a2)<<16;
	t3 = (pa_fract32)fr32b1;
	t4 = ((pa_fract32)fr16b2)<<16;
	asm ("smull %[lo],%[hi],%[a],%[b]"
	      : [lo] "=&r" (res_lo), [hi] "=&r" (res_hi)
	      : [a] "r" (t1), [b] "r" (t2));

	asm ("smlal %[lo],%[hi],%[a],%[b]"
	      : [lo] "+&r" (res_lo), [hi] "+&r" (res_hi)
	      : [a] "r" (t3), [b] "r" (t4));

  return( (pa_fract32)res_hi << 1 );
#else
//	return (pa_mult32_16(fr32a1, fr16a2) + pa_mult32_16(fr32b1, fr16b2));
    pa_fract32 temp, temp1, temp2;
    temp1 = pa_mult32_16(fr32a1, fr16a2);
    temp2 = pa_mult32_16(fr32b1, fr16b2);
	temp = pa_L_add(temp1, temp2);

    //ASSERT_OVERFLOW_S32(temp1, 1);
    //ASSERT_OVERFLOW_S32(temp2, 1);
	return temp;
#endif
}


#ifdef PA_LOG_OVERFLOW
static __inline__ pa_fract16 pa_shr_exe(pa_fract16 a, pa_int16 n, char* file, pa_uint16 line)
#else
static __inline__ pa_fract16 pa_shr_exe(pa_fract16 a, pa_int16 n)
#endif
{
#ifdef PA_LOG_OVERFLOW
    ASSERT_OVERFLOW_OCCURRED(n<16, file, line);
    ASSERT_NEGATIV_SHIFT(n>=0, file, line);
#endif
    /*lint --e{702} shift right of signed entity is intended here */
		return a>>n;
}

static __inline__ pa_fract16 pa_shr_s(pa_fract16 a, pa_int16 n)
{
  /* shift to zero (not to -1) */
	return ((n > 15) || ((a<0) && (a>(-1<<n)))) ? 0 : pa_shr(a, n);
}

#ifdef PA_LOG_OVERFLOW
static __inline__ pa_fract32 pa_L_shr_exe(pa_fract32 a, pa_int16 n, char* file, pa_uint16 line)
#else
static __inline__ pa_fract32 pa_L_shr_exe(pa_fract32 a, pa_int16 n)
#endif
{
#ifdef PA_LOG_OVERFLOW
    ASSERT_OVERFLOW_OCCURRED(n<32, file, line);
    ASSERT_NEGATIV_SHIFT(n>=0, file, line);
#endif
    return a>>n;
}

static __inline__ pa_fract32 pa_L_shr_s(pa_fract32 a, pa_int16 n)
{

	return n > 31 ? 0 : pa_L_shr(a, n);
}


#ifdef PA_LOG_OVERFLOW
static __inline__ pa_fract16 pa_shl_s_exe(pa_fract16 a, pa_int16 n, char* file, pa_uint16 line )
#else
static __inline__ pa_fract16 pa_shl_s_exe(pa_fract16 a, pa_int16 n )
#endif
{

#ifdef PA_LOG_OVERFLOW
  /*
   *  Saturation is implemented with the help of 32bit temporary values on ARM so
   *  we have to check that these values are not exceeded.
   */
  int k = (n>31) ? 31 : n;
  ASSERT_NEGATIV_SHIFT(n>=0, file, line);

  /* We use -2147483647L instead of -2147483648L because of GNU compiler restrictions for ARM platform */
  ASSERT_OVERFLOW_OCCURRED( a <= (2147483647L >> k)  &&  a >= (-2147483647L >> k) , file, line);

/*
  if( ! (a <= (2147483647L >> k)  &&  a >= (-2147483648L >> k) ) )
    printf(" !!!!");
*/
#endif


#ifdef __blackfin__
  /*
   *  Blackfin does it better. Only plattform so far with real saturated shift
   */
	return shl(a, n);

#elif defined(_ARM_VERSION) && (_ARM_VERSION >= 6)

	register pa_fract32 res = (pa_fract32)a;
  // asm("LSL %[res], %[a], %[b]" : [res] "=&r" (res) : [a] "r" (op), [b] "r" (n) );
  // asm("SSAT %[res], #16, %[a]" : [res] "=&r" (res) : [a] "r" (res) );

  asm("LSL %0, %1, %2" : "=r" (res) : "0" (res), "r" (n) );
  asm("SSAT %0, #16, %1" : "=r" (res) : "0" (res) );

  return (pa_fract16)res;

#else
  /*
   *  Reference implementation according to ARM platform
   *  We use temporary 32 bit calculation
   */
  pa_fract16 res_fr16;
  pa_fract32 res = (pa_fract32)a << (pa_fract32)n;

  if( res > 32767L )
  {
    res_fr16 = 32767;
  }
  else if( res < -32768L )
  {
    res_fr16 = -32768;
  }
  else
  {
    res_fr16 = (pa_fract16)res;
  }
  return res_fr16;

#if 0
	/* used until 18.05.09; implementation does not correctly handled saturations*/
	pa_fract32 fr32ret;
	fr32ret = ((pa_fract32) a)<<n ;
	if (fr32ret < (pa_fract32) PA_FRACT16_MIN)
	{
		fr32ret = (pa_fract32) PA_FRACT16_MIN;
	}
	else
	if (fr32ret > PA_FRACT16_MAX)
	{
		fr32ret = (pa_fract32) PA_FRACT16_MAX;
	}

	return (pa_fract16) fr32ret;
#endif

#endif
}


#ifdef PA_LOG_OVERFLOW
static __inline__ pa_fract32 pa_L_shl_s_debug(pa_fract32 a, pa_int16 n, char* file, pa_uint16 line)
#else
static __inline__ pa_fract32 pa_L_shl_s(pa_fract32 a, pa_int16 n)
#endif
{
#ifdef PA_LOG_OVERFLOW
    ASSERT_NEGATIV_SHIFT(n>=0, file, line);
    ASSERT_OVERFLOW_OCCURRED(n<32, file, line);
#endif

/*
      if( ! (n<32) )
        printf(" !!!!");
*/


#ifdef __blackfin__
    return L_shl(a,n);
#else
    pa_fract32 ret;
    if (a > (PA_FRACT32_MAX >> n) )
    {
      ret = PA_FRACT32_MAX;
    }
    else if (a < (PA_FRACT32_MIN >> n) )
    {
      /* with respect to bit exactness to some DSP implementations (Blackfin)
       * we are using the 2's complement minimum value instead of PA_FRACT32_MIN */
      ret = PA_FRACT32_MIN;
    }
    else
    {
      ret = a<<n;
    }
    return ret;
#endif
}




#ifdef PA_LOG_OVERFLOW
static __inline__ pa_fract16 pa_shl_debug(pa_fract16 a, pa_int16 n, char* file, pa_uint16 line)
{
    ASSERT_NEGATIV_SHIFT(n>=0, file, line);
    ASSERT_OVERFLOW_OCCURRED((a<<n)==pa_shl_s(a, n), file, line);
    return a<<n;
}
#else
static __inline__ pa_fract16 pa_shl(pa_fract16 a, pa_int16 n)
{
    /*lint --e{373} bitwise operator on signed is intended here */
    return a<<n;
}
#endif


#ifdef PA_LOG_OVERFLOW
static __inline__ pa_fract32 pa_L_shl_debug(pa_fract32 a, pa_int16 n, char* file, pa_uint16 line)
{
        ASSERT_NEGATIV_SHIFT(n>=0, file, line);
        ASSERT_OVERFLOW_OCCURRED((a<<n)==pa_L_shl_s_debug(a, n, file, line), file, line);
  return a<<n;
}
#else
static __inline__ pa_fract32 pa_L_shl(pa_fract32 a, pa_int16 n)
{
	return a<<n;
}
#endif

static __inline__ pa_fract16 pa_negate(pa_fract16 a)
{
  pa_fract16 ret;
	if (a <= PA_FRACT16_MIN) ret = PA_FRACT16_MAX;
	else ret = (-a);

	return ret;
}

static __inline__ pa_fract32 pa_L_negate(pa_fract32 a)
{
  pa_fract32 ret;
	if (a <= PA_FRACT32_MIN) ret = PA_FRACT32_MAX;
	else ret = (-a);

	return ret;
}

static __inline__ pa_fract16 pa_extract_l_sat(pa_fract32 a)
{
	pa_fract16 ret;
  if (a < (pa_fract32) PA_FRACT16_MIN)
	{
		ret = PA_FRACT16_MIN;
	}
	else
	if (a > (pa_fract32) PA_FRACT16_MAX)
	{
		ret = PA_FRACT16_MAX;
	}
	else
	{
		ret = (pa_fract16) a;
	}
  return ret;
}

static __inline__ pa_fract16 pa_extract_h(pa_fract32 a)
{
		return (pa_fract16) (a>>16);
}
static __inline__ pa_fract16 pa_extract_r(pa_fract32 a)
/* As pa_extract_h, but rounds result before */
{
  pa_fract16 ret;
  if (a < 0 && a > PA_FRACT32_MIN+0x8000L) {
    ret = pa_extract_h(a-0x8000L);
  }
  else
  if (a > 0 && a < PA_FRACT32_MAX-0x8000L) {
    ret = pa_extract_h(a+0x8000L);
  }
  else {
    ret = pa_extract_h(a);
  }
  return ret;
}

static __inline__ pa_fract16 pa_extract_s(pa_fract32 a)
/* always round towards zero */
{
  return a < 0 ? pa_extract_h(a+0x10000L): pa_extract_h(a);
}

static __inline__ pa_fract32 pa_L_deposit_h(pa_fract16 a)
{
		return ((pa_fract32) a)<<PA_FRACT16_BIT;
}
static __inline__ pa_fract32 pa_L_deposit_l(pa_fract16 a)
{
		return (pa_fract32) a;
}

static __inline__ pa_fract16 pa_max_fr16(pa_fract16 a, pa_fract16 b)
{
	return a>b ? a : b;
}
static __inline__ pa_fract16 pa_min_fr16(pa_fract16 a, pa_fract16 b)
{
	return a<b ? a : b;
}

static __inline__ pa_fract32 pa_min_fr32(pa_fract32 a, pa_fract32 b)
{
	return a<b ? a : b;
}
static __inline__ pa_fract32 pa_max_fr32(pa_fract32 a, pa_fract32 b)
{
	return a>b ? a : b;
}

static inline pa_uint16 pa_L_normPos(pa_fract32 in)
{
/* Find leading zeros */



#ifdef __blackfin__

  ASSERT( in >= 0 );
  return (in == 0) ? PA_FRACT32_BIT-1 : norm_l(in);

#elif defined(_ARM_VERSION) && (_ARM_VERSION >= 5)


  ASSERT( in >= 0 );
  asm("CLZ %0, %1" : "=r" (in) : "0" (in) );
  return ( in-1 );

#else
  pa_int16 bitPos = -1;
  pa_uint32 mask = 0xffff0000UL;
  pa_int16 nextShift= 16;
  pa_uint32 t = (pa_uint32) in;

  do
  {
    if ((t&mask) > 0)
    {
      nextShift=nextShift>>1;
      mask=mask<<nextShift;
    }
    else
    {
      bitPos+=nextShift;
      nextShift=nextShift>>1;
      mask=mask>>nextShift;
    }
  } while(nextShift);
  return (pa_uint16) bitPos;
#endif
}
/*lint +e960         : no object/function definition in header files */
/*lint +e704 +e703 +e702 +e701   : info, if shifts of signed quantities */



#endif  /* of PA_FIXPOINT_H */

/**************************************************************************
 eof pa_fixpoint.h'
**************************************************************************/

