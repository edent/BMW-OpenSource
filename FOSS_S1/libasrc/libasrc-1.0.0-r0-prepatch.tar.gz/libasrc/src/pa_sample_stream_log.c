/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/


#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include <pa_sample_stream_log.h>
#include <asrc_config.h>

#define MIN(x,y) ( (x) < (y) ? (x) : (y) )


/*!
 * Read wallclock in ms()
 *
 * Returnparameter
 *   - R:                     wall clock in ms
 */
static uint64_t get_wallclock_ms( void )
{
	struct timespec ts;

	if (clock_gettime(CLOCK_MONOTONIC,&ts)<0){
		pa_error("clock_gettime() doesn't work: %s", strerror(errno) );
	}
	return (ts.tv_sec*1000LL) + ((ts.tv_nsec+500000LL)/1000000LL);
}


/*!
 * Allocate and initialize new sample stream log object
 *
 * Function parameters
 *   - mutexPtr               pointer to mutex for access protection to obj
 *
 * Returnparameter
 *   - R:                     pointer to object pa_ss_log_t or NULL in case of error
 */
pa_ss_log_t* create_ss_new_log( void* mutexPtr )
{
  pa_ss_log_t* p = pa_malloc( sizeof( pa_ss_log_t ) );

  if( p )
  {
    p->tab = pa_malloc( sizeof( pa_ss_log_entry_t ) * PA_SS_LOG_BUF_LEN );
    if( p->tab == NULL )
    {
      pa_free( p );
      return NULL;
    }
  }

  p->tab_len = PA_SS_LOG_BUF_LEN;
  p->write_idx = p->read_idx = p->filled = p->overflows = 0;
  p->mutexPtr = mutexPtr;
  return p;
}


/*!
 * Allocate and initialize new sample stream log object
 *
 * Function parameters
 *   - p_log:                 pointer to object pa_ss_log_t
 */
void release_ss_log( pa_ss_log_t* p_log )
{
  if( p_log )
  {
    if( p_log->tab )
      pa_free( p_log->tab );

    pa_free( p_log );
  }
}


/*!
 * Add log entry to sample stream log object
 *
 * Function parameters
 *   - p_log:                 pointer to object pa_ss_log_t
 *   - samples_in             amount of samples inserted (postive value) or removed (negattive value)
 *   - ts                     time stamp of first octett or 0 to use system time
 *
 * Returnparameter
 *   - R:                     error code, in example -1 in case of overflow
 */
int add_ss_log_entry( pa_ss_log_t* obj, int16_t samples_in, uint64_t ts )
{
  long idx, prev_idx;
  int error = 0;

  pa_lock( obj->mutexPtr );

  idx = obj->write_idx;

  if( obj->filled < obj->tab_len )
  {
    obj->tab[idx].samples_in = samples_in;
    obj->tab[idx].timestamp = (ts ? ts : get_wallclock_ms() );

    if( ++idx < obj->tab_len )
      obj->write_idx = idx;
    else
      obj->write_idx = 0;

    ++(obj->filled);
  }
  else
  {
    /* overflow case, do not add further log entries */
    pa_message("add_ss_log_entry: sample stream log overflow occurred!\n");

    /* mark overflow case in log for later identification */
    prev_idx = (idx - 1) < 0 ? (obj->tab_len - 1) : (idx - 1);
    obj->tab[prev_idx].timestamp = 0LL;
    error = -1;
    ++(obj->overflows);
  }

  pa_unlock( obj->mutexPtr );

  return error;
}


/*!
 * Read entries from sample stream log object
 *
 * Function parameters
 *   - p_log:                 pointer to object pa_ss_log_t
 *   - max_elements:          maximum amount of log entries to be buffered
 *   - entryPtr               pointer where read entries are written to
 *
 * Returnparameter
 *   - R:                     elements successfully read
 */
long read_ss_log_entries( pa_ss_log_t* obj, pa_ss_log_entry_t* entryPtr, long max_elements )
{
  long read, to_read1, to_read2;

  pa_lock( obj->mutexPtr );

  read = to_read1 = to_read2 = MIN( max_elements, obj->filled );

  if( obj->read_idx + to_read1 < obj->tab_len )
  {
    memcpy( & entryPtr[0], &obj->tab[ obj->read_idx ], to_read1 * sizeof( pa_ss_log_entry_t )  );
    obj->read_idx += to_read1;
  }
  else
  {
    to_read1 = obj->tab_len - obj->read_idx;
    to_read2 -= to_read1;

    memcpy( & entryPtr[0], &obj->tab[ obj->read_idx ], to_read1 * sizeof( pa_ss_log_entry_t )  );
    memcpy( & entryPtr[to_read1], &obj->tab[ 0 ], to_read2 * sizeof( pa_ss_log_entry_t )  );
    obj->read_idx = to_read2;
  }

  obj->filled -= read;

  pa_unlock( obj->mutexPtr );

  return read;
}



