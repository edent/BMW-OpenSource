/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/
/*
*  History:
*  $Log: pa_fract.h,v $
*  Revision 1.2  2007/08/28 15:33:04  PEIKER\vic
*  MY09 - Processing: Initial Version
*
*  Revision 1.1  2007/05/29 14:43:15  PEIKER\FA
*  initial
*
*  Revision 1.1.1.1  2007/01/17 15:02:49  NT-SERVER\FA
*  no message
*
*  Revision 1.1  2006/06/27 22:09:55  vic
*  Initial Version
*
*
***************************************************************************/
#ifndef PA_FRACT_H
#define PA_FRACT_H
typedef signed short int pa_fract16;
typedef signed long int pa_fract32;
typedef signed long long pa_fract64;
#endif
