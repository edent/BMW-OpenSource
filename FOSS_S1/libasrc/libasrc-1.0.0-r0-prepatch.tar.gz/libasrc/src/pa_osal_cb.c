/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <pa_osal_cb.h>

/*! dummy implementation, replace e.g. by pthread mutex functions */
int mutex_void_lock_unlock( void *p ) { return 0; }

PA_ASRC_MUTEX_CALLBACK_PTR   pa_lock = mutex_void_lock_unlock;
PA_ASRC_MUTEX_CALLBACK_PTR   pa_unlock = mutex_void_lock_unlock;
PA_ASRC_MALLOC_CALLBACK_PTR  pa_malloc = malloc;
PA_ASRC_FREE_CALLBACK_PTR    pa_free = free;
PA_ASRC_PRINT_CALLBACK_PTR   pa_message = printf;
PA_ASRC_PRINT_CALLBACK_PTR   pa_error = printf;
