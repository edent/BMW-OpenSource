/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/

#ifndef ASRC_SS_LOG_THREAD_H
#define ASRC_SS_LOG_THREAD_H

#ifdef HAVE_CONFIG_H
# include <asrc_config.h>
#endif

#include <stdio.h>
#include <pa_asrc.h>

#ifdef HAVE_LIBPTHREAD
 #include <pthread.h>
# ifdef ENABLE_SAMPLE_STREAM_LOGGING

//#define ASRC_LOG_FILENAME           "/var/log/asrc"
#define ASRC_LOG_FILENAME           "/tmp/asrc"
#define ASRC_MAX_LOG_ROTATE_NR      10
#define ASRC_LOG_ELEMENTS_PER_FILE  2000  /* 1000 elements a 20ms correspond to approx 20s */
#define ASRC_LOG_ELEMENTS_PER_CHUNK 100   /* 50 elements a 20ms corresponds approx to 1s */
#define ASRC_LOG_THREAD_IDLE_MS     100


/*!
 * background thread local data
 */
typedef struct {
  int          log_nr;
  int          max_log_nr;
  FILE*        fp;
  pa_asrc_buf* p_asrc_obj;
  int          run;
  int          error;
  pthread_mutex_t  mutex;                     /** mutex for this object */
} log_thread_data_t;


/*!
 * thread object data for stream statistic log file generator
 */
typedef struct {
  pthread_t         thread;
  log_thread_data_t data;
} log_data_thread_t;


/*!
 * Allocate, create and run background thread for generating stream statistic log files
 *
 * Function parameters
 *   - p_asrc_obj:            pointer to asrc instance object data
 *
 * Returnparameter
 *   - R:                     pointer to thread object or NULL if allocation failed
 */
log_data_thread_t* create_asrc_log_thread( pa_asrc_buf* p_asrc_obj );


/*!
 * Stop and release background thread for generating stream statistic log files
 *
 * Function parameters
 *   - p_thread:              pointer to thread object to be stopped
 */
void stop_asrc_log_thread( log_data_thread_t* p_thread );


# endif /* # ifdef ENABLE_SAMPLE_STREAM_LOGGING */
#endif /* #ifdef HAVE_LIBPTHREAD */


#endif /* #ifndef ASRC_SS_LOG_THREAD_H */
