/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
 *  \brief  test programm for asynchronous sample rate conversion
*	@{
***************************************************************************/
#include <asrc_ss_log_thread.h>
#include <unistd.h>
#include <assert.h>

int main()
{
  pa_asrc_buf   asrcObj;
  const int     channels = 1;
  const int32_t max_samples = 3 /* no frames */  *   20 /*ms*/  *  16 /*kHz*/  *  channels;
  const int32_t min_samples = 1 /* no frames */  *   20 /*ms*/  *  16 /*kHz*/  *  channels;
  int16_t*      sampleBuf;
  int           err;
  int           i, j;
  long          frame_cnt = 0L;
  int16_t       buf[640];
#ifdef ENABLE_SAMPLE_STREAM_LOGGING
  pa_ss_log_entry_t logtab[20];

# ifdef HAVE_LIBPTHREAD
  log_data_thread_t*          p_log_thread;
  pthread_mutex_t             stream_mutex, log_mutex;
  pthread_mutex_t             *p_stream_mutex = & stream_mutex, *p_log_mutex= & log_mutex;
  PA_ASRC_MUTEX_CALLBACK_PTR  lock_fct = (PA_ASRC_MUTEX_CALLBACK_PTR)pthread_mutex_lock;
  PA_ASRC_MUTEX_CALLBACK_PTR  unlock_fct = (PA_ASRC_MUTEX_CALLBACK_PTR)pthread_mutex_unlock;
# else
  pthread_mutex_t             *p_stream_mutex = NULL, *p_log_mutex= NULL;
  PA_ASRC_MUTEX_CALLBACK_PTR  lock_fct = NULL;
  PA_ASRC_MUTEX_CALLBACK_PTR  unlock_fct = NULL;
# endif


#else
  pthread_mutex_t             *p_stream_mutex = NULL, *p_log_mutex= NULL;
  PA_ASRC_MUTEX_CALLBACK_PTR  lock_fct = NULL;
  PA_ASRC_MUTEX_CALLBACK_PTR  unlock_fct = NULL;
#endif /* #ifdef ENABLE_SAMPLE_STREAM_LOGGING */


  sampleBuf = malloc(max_samples * sizeof( int16_t ) );
  if( sampleBuf == NULL )
  {
    fprintf( stderr, "could not allocate asrc audio sample queue error!\n");
    return -1;
  }

  /*
   * initialize asrc object
   */
  err = pa_asrc_init( &asrcObj, sampleBuf, max_samples, min_samples, channels, 1 /*enable logging */,
                      p_stream_mutex /* mutexAsrcPtr */,
                      p_log_mutex /* mutexLogPtr */,
                      NULL /* malloc_fctPtr */,
                      NULL /* free_fctPtr */,
                      lock_fct /* mutex_lock_fctPtr */,
                      unlock_fct /* mutex_unlock_fctPtr */,
                      NULL /* message_fctPtr */,
                      NULL /* error_fctPtr */ );

  if( err )
  {
    fprintf( stderr, "could not initialize asrc error!\n");
    return err;
  }


#if defined( HAVE_LIBPTHREAD ) && defined( ENABLE_SAMPLE_STREAM_LOGGING )
  /*
   * initialize Logger Thread if configured
   */
  err = pthread_mutex_init( p_stream_mutex, 0 );
  if( !err )
    err = pthread_mutex_init( p_log_mutex, 0 );
  if( err )
  {
    fprintf( stderr, "could not initialize mutexes!\n");
    return err;
  }

  p_log_thread =  create_asrc_log_thread( &asrcObj );
  if( p_log_thread == NULL )
  {
    fprintf( stderr, "could not initialize logging thread!\n");
    return -1;
  }
#endif


  printf("asrc test successfully intialized!\n");
#ifdef ENABLE_SAMPLE_STREAM_LOGGING
  printf("sample stream logging is enabled!\n");
# ifdef HAVE_LIBPTHREAD
  printf("run multi thread based test ...\n");
# else
  printf("run single thread based test ...\n");
# endif
#endif /* #ifdef ENABLE_SAMPLE_STREAM_LOGGING */

  /*
   * loop for test data generation corresponding to 1 minute
   */
  for( i=0; i < (60 * 5); ++i )
  {
    for( j=0; j < 10; ++j )
    {
      assert( pa_asrc_put( & asrcObj, buf, 320, 0LL ) == 320 );
      assert( pa_asrc_get( & asrcObj, buf, 320, 0LL ) == 320 );

      /* simulate overflow */
      if( frame_cnt * 20 == 20000 )
        assert( pa_asrc_put( & asrcObj, buf, 500, 0LL ) == 500 );


      /* simulate underflow */
      if( frame_cnt * 20 == 40000 )
        assert( pa_asrc_get( & asrcObj, buf, 500, 0LL ) == 500 );

      printf("%ld ms, filling state: %d ...\n", frame_cnt++ * 20, asrcObj.ring.uiFill );
      usleep( 20000 );
    }
#ifdef ENABLE_SAMPLE_STREAM_LOGGING
# ifdef HAVE_LIBPTHREAD
# else
    assert( read_ss_log_entries( asrcObj.ssLogPtr, logtab, 20 ) == 20 );
    for( j=0; j<20; ++j)
    {
      printf("%ld.%ld : %d\n", logtab[j].timestamp.tv_sec, logtab[j].timestamp.tv_usec, logtab[j].samples_in );
    }
# endif /* # ifndef HAVE_LIBPTHREAD */
#endif /* #ifdef ENABLE_SAMPLE_STREAM_LOGGING */
  }


  /*
   * release
   */
#ifdef ENABLE_SAMPLE_STREAM_LOGGING
# ifdef HAVE_LIBPTHREAD
  stop_asrc_log_thread( p_log_thread );
# endif
  pa_asrc_release( & asrcObj );
#endif
  free( sampleBuf );

  return 0;
}

