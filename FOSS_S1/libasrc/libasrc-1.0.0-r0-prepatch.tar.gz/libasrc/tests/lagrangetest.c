/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
 *  \brief  test programm for lagrange interpolation
*	@{
***************************************************************************/

#include <pa_asrc_lagrange.h>
#include <assert.h>
#include <pa_buffer.h>
#include <string.h>
#include <math.h>

#define PI 3.1415926535897932384626433832795

int save_vector( const char* filename, pa_int16 *p, int samples_to_write )
{
  FILE* fp;
  int samples_written;
  int errcode;

  fp = fopen( filename, "wb" );
  if( fp == NULL )
    return -1;

  samples_written = fwrite( p, sizeof(pa_int16), samples_to_write, fp );
  fclose( fp );

  errcode = ! (samples_written == samples_to_write);
  if( errcode )
    fprintf( stderr, "Error while saving file %s occured!\n", filename);
  return errcode;
}

int main()
{
  pa_asrc_interstate asrc_interstate;
  pa_int16 error_code;
  pa_int16 x[100], y[120];
  int x_len = sizeof(x)/sizeof(pa_int16);
  int y_len = sizeof(y)/sizeof(pa_int16);
  pa_ringBuf ringBuf;
  const char* infilename = "in.raw";
  const char* outfilename = "out.raw";
  int i;


  printf("Testing ground for lagrange interpolation\n\n");
  printf("Initializing ...\n");
  error_code = pa_ringBufInit( &ringBuf, (int8_t*)x, sizeof(x) );
  if( error_code )
    return error_code;
  error_code = PA_ASRC_interstate_init( & asrc_interstate, 5, 1, NULL );
  if( ! error_code  )
    return error_code;
  printf("PA_ASRC_interstate_init [ok]\n");


  printf("Generating test file %s with %d data points ...\n", infilename, x_len );
  for( i=0; i<x_len; ++i)
    x[i] = 8000 * sin( 2.0*PI*(double)i / x_len );
  pa_ringBufAddData( & ringBuf, (int8_t*)x, sizeof(x), 0 );
  memset( y, 0, sizeof(y) );

  printf("Resampling to output file %s with %d data points ...\n", outfilename, y_len );
  PA_ASRC_buffer_interpol(
    & asrc_interstate, y, y_len, & ringBuf,
#ifdef _PA_ASRC_INTERPOL_FLOAT
    // 100.0 / 120.0,
    // 100.0 / 80.0,
    (double)sizeof(x) / (double)sizeof(y),
#else
    16384 * sizeof(x) / sizeof(y)
#endif
    );

  printf("Save output files to disc ...\n");
  error_code = save_vector( infilename, x, x_len );
  error_code |= save_vector( outfilename, y, y_len );

  if( ! error_code )
    printf("Sucessfully created demonstration files %s, %s!\n",
           infilename, outfilename);

  return error_code;
}

