/* Test operators */

main() {
    int a;
    a = a++;
}
