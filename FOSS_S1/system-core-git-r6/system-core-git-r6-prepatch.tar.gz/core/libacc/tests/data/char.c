char ga;
char gb;

int main() {
    char a = 'c';
    char b = a * 3;
    printf("a = %d, b = %d\n", a, b);
    ga = 'd';
    gb = ga * 3;
    printf("ga = %d, gb = %d\n", ga, gb);
    return 0;
}

