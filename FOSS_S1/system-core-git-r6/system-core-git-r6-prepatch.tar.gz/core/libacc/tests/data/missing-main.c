/* No main. */

a() {
}