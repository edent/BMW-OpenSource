// Check integer operations

int main() {
    int a = 0;
    printf("%d\n", a++);
    printf("%d\n", a++);
    printf("%d\n", a--);
    printf("%d\n", a--);
    printf("%d\n", ++a);
    printf("%d\n", ++a);
    printf("%d\n", --a);
    printf("%d\n", --a);
    return a;
}
