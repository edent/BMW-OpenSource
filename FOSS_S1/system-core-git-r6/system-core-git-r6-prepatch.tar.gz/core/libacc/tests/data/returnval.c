main() {
  return 42;
}

