double atof(char *nptr);

int main() {
    printf("Value = %g\n", atof("10.42"));
    return 0;
}

