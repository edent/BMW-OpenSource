int main() {
    return printf("Hello" "," " world\n");
}

