int f(int a,int, int c) {
    return a + c;
}

int main() {
    return f(1,2,3);
}

