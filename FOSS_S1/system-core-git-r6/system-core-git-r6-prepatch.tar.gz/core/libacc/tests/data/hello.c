main(a,b) {
    printf("Hello, world\n");
}
