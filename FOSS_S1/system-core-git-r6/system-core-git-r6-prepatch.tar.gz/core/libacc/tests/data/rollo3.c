
float fabsf(float);

int main(void* con, int ft, int launchID)
{
   float f =  fabsf(-10.0f);
   return f;
}

