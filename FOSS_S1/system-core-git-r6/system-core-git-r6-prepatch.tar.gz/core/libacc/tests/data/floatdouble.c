int main()
{
    // Test coercing values when storing.
    float a = 0.002;
    double b = 0.1f;
    int c = 10.002;
    printf("%g %g %d\n", a, b, c);
    return 0;
}
