#line 3776 "ifupdown.nw"
unsigned int mylinuxver();
unsigned int mylinux(int,int,int);
int execable(char *);
