#ifndef SYS_BLDT_H_
#define SYS_BLDT_H_
/*===========================================================================

            B L D T  Partition Information Coding

===========================================================================*/

/*===========================================================================
GENERAL DESCRIPTION

This defines the information shared between Flash loader and Boot loader as
well as target specific configurations used for various models

===========================================================================*/

/*
 *
 * This software is the property of PEIKER acustic GmbH & Co KG and contains
 * proprietary information that is a trade secret of PEIKER acustic GmbH
 * & Co KG and is also protected as an unpublished work under international
 * copyright laws and treaties.
 *
 * Usage of this software is restricted solely to those rights that are
 * contained in a prior written agreement with PEIKER acustic GmbH & Co KG.
 *
 * Copyright (c) 2008-2012 PEIKER acustic GmbH & Co KG
 * All rights reserved
 *
 */

/*===========================================================================

                      EDIT HISTORY FOR FILE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

when       who     what, where, why
--------   ---     ----------------------------------------------------------
07.12.12   jkom    modified to reflect changes from workshop with vector

===========================================================================*/
/*
BLDT:
+
| HEADER SECTION
+
| TARGET SPECIFIC SECTION 1
+
| TARGET SPECIFIC SECTION 2
+
:
*/

/*
 * 
 * IMPORTANT: Unfortunately, this file must be duplicated between boot_image and apps_proc
 * 
*/
#include "comdef.h"
#define BLDT_NAME_SBL "0:BLDT" /* partition acces name as used in SBL */
#define BLDT_NAME_ABOOT "bldt" /* mtd partition name used in aboot (lk)and Linux */

#define BLDT_SECTION_SIZE 2048U /* this is the size for each section in BLDT */
#define BLDT_MAGIC_NUMBER_1 0x3ec6d73cU /* totally random, but unique number for swe_compat_magic entry.
                                              This should be changed each time the format of 0:BLDT data changes */

/* This is the Header structure as written to or read from the 0:BLDT structure.
 * This has to be the first data in partition 0:BLDT */
typedef struct _SYS_BLDT_HDR_t{
  uint32      magic; /* BLDT MAGIC NUMBER to distinguish between formats */
  uint32      system_type; /* one of the below system types */
  uint32      boot_param[30]; /* parameters for bootloader as per system type */
} SYS_BLDT_HDR_t;

#define BL_VALUE_INVALID            0xFFFFFFFF  /* this is the default value read from flash when empty /unused */
#define BL_SYSTYPE_NONE             BL_VALUE_INVALID  /* id no system type specified = QC native behaviour */

#define BL_SYSTYPE_EVAL_ATM         0x00000001  /* EVAL board with ATM behaviour */
#define BL_SYSTYPE_ATM              0x00000002  /* ATM board */

/* boot_param indizes for boot_param for SYSTYPE_EVAL_ATM and SYSTYPE_ATM */
#define BOOT_P_UPDATE_GPIO 0                 /* coded paramter [config + port] to enter Update mode */
#define BOOT_P_UPDATE_GPIO_ACTIVE_VALUE 1    /* value for GPIO to enter Update mode */
#define BOOT_P_EMER_DLOAD_SBL2_GPIO 2        /* coded paramter [config + port] to enter DLOAD mode unconditionally */
#define BOOT_P_EMER_DLOAD_SBL2_ACTIVE_VALUE 3       /* value for GPIO to enter DLOAD mode unconditionally */
#define BOOT_P_EMER_FASTB_ABOOT_GPIO 4       /* coded paramter [config + port] to enter fastboot mode unconditionally */
#define BOOT_P_EMER_FASTB_ABOOT_ACTIVE_VALUE 5      /* value for GPIO to enter fastboot mode unconditionally */

/* further definitions for system types BL_SYSTYPE_EVAL_ATM and BL_SYSTYPE_ATM */
#define BLDT_HDR_OFFSET             (0U)
#define BLDT_SVK_OFFSET             (1U*BLDT_SECTION_SIZE)
#define BLDT_FLSL_SWEHDR_OFFSET     (2U*BLDT_SECTION_SIZE)
#define BLDT_MODEM_SWEHDR_OFFSET    (3U*BLDT_SECTION_SIZE)
#define BLDT_SYSMAIN_SWEHDR_OFFSET  (4U*BLDT_SECTION_SIZE)
#define BLDT_APPLMAIN_SWEHDR_OFFSET (5U*BLDT_SECTION_SIZE)
#define BLDT_FLUP_SWEHDR_OFFSET     (6U*BLDT_SECTION_SIZE)
#define BLDT_MACADDR_OFFSET         (7U*BLDT_SECTION_SIZE)
#endif /* SYS_BLDT_H */
