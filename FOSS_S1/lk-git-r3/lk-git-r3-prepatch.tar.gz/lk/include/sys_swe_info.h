#ifndef SYS_SWE_INFO_H_
#define SYS_SWE_INFO_H_
/*===========================================================================

            T C B   S W E   S V K   I N F O

===========================================================================*/

/*===========================================================================
GENERAL DESCRIPTION

This defines the information shared between Flash loader, Boot loader and AMSS
to deal with SWE information as used between NAD and CAN Controller

In particular the information used in the READ_SVK request message.

===========================================================================*/

/*
 *
 * This software is the property of PEIKER acustic GmbH & Co KG and contains
 * proprietary information that is a trade secret of PEIKER acustic GmbH
 * & Co KG and is also protected as an unpublished work under international
 * copyright laws and treaties.
 *
 * Usage of this software is restricted solely to those rights that are
 * contained in a prior written agreement with PEIKER acustic GmbH & Co KG.
 *
 * Copyright (c) 2008-2009 PEIKER acustic GmbH & Co KG
 * All rights reserved
 *
 */

/*===========================================================================

                      EDIT HISTORY FOR FILE

  This section contains comments describing changes made to the module.
  Notice that changes are listed in reverse chronological order.

when       who     what, where, why
--------   ---     ----------------------------------------------------------
03.03.10   jle     Initial version.
08.03.10   jkom    modified to reflect changes from workshop with vector

===========================================================================*/
#include "comdef.h"
#define SWE_HEADER_SIZE 2048U /* this is the header size that will be loaded before the actual image */
#define SWE_ID_OFFSET 0U
#define SWE_CLASS_IDX 0U           /* this is the class Id, i.e., FLUP,FLSL,SWFL */
#define SWE_MAJOR_IDX 5U           /* this is major SW version number */
#define SWE_MINOR_IDX 6U           /* this is minor SW version number */
#define SWE_PATCH_IDX 7U           /* this is SW patch version number */
#define SWE_SGBM_ID_OFFSET 1U      /* where the 4 Byte Module Id is stored */
#define SWE_FULL_SGBM_ID_SIZE 8U        /* The size of a full BMW Logistics SGBM Id ( Class + Module Id + 3 Byte Versions */
#define SWE_SIGNATURE_OFFSET 8U    /* this is where the signature will be stored by SWE generator */
#define SWE_LENGTH_OFFSET 512U     /* this is where the image length for signature calculations will be stored */
#define SWE_DEV_INFO_OFFSET 640U   /* this is where the DEVINFO data will be stored in SWE */
#define SWE_FLUP_INFO_OFFSET 768U  /* this is where the information for FLUP will be stored in SWE. FLUP only. */
#define SWE_FLSL_INFO_OFFSET 1024U /* this is where the information for FLSL will be stored in SWE. FLUP only. */
#define SWE_VERSION_SIZE 3U        /* the size of the Version Bytes */
#define SWE_SGBM_IDENT_SIZE 4U     /* the size of the SGBM Module Ident */
#define SWE_MAX_SIZE 0x6000000U    /* SWE is maximum 96MB; This is the absolute maximum for any uncompressed SWE image */

#define SWE_COMPAT_UART_BL_IDX (SWE_DEV_INFO_OFFSET + 0u) /* Compatibilty UART Interface Bloader Level */
#define SWE_COMPAT_UART_API_IDX (SWE_DEV_INFO_OFFSET + 1u)/* C. UART API (Remote procedure call, etc.) */
#define SWE_COMPAT_UART_APPLICATION_IDX (SWE_DEV_INFO_OFFSET + 2u) /* C. Application Data ( message contents) */
#define SWE_COMPAT_NAD_SBL_MODEM_IDX (SWE_DEV_INFO_OFFSET + 4u) /* C. between Modem and SBL  */
#define SWE_COMPAT_NAD_SBL_SYSMAIN_IDX (SWE_DEV_INFO_OFFSET + 5u) /* C. between Aplication and SBL */
#define SWE_COMPAT_NAD_SBL_FILESYS_IDX (SWE_DEV_INFO_OFFSET + 6u) /* C. between Filesystems and SBL */
#define SWE_COMPAT_NAD_MODEM_APPL_IDX (SWE_DEV_INFO_OFFSET + 7u) /* C. between Linux and MODEM */
#define SWE_COMPAT_NAD_MODEM_FILE_IDX (SWE_DEV_INFO_OFFSET + 8u) /* C. between File system and MODEM */
#define SWE_COMPAT_NAD_APPL_FILE_IDX (SWE_DEV_INFO_OFFSET + 9u) /* C. between SYSMAIN and file systems */
#define SWE_COMPAT_OFFSET_HW 32u /* this is the offset within FLUP SWE compatibility section for NAD HW Revision Compatibility data */
#define SWE_COMPAT_OFFSET_HW_IDX (SWE_DEV_INFO_OFFSET + SWE_COMPAT_OFFSET_HW) /* this is the offset within FLUP SWE for NAD HW Revision Compatibility data */

#define SWE_FLUP_MODE_OFFSET (SWE_DEV_INFO_OFFSET + 64u) /* offset in FLUP SWE where flag is stored whether to use flash writer or Linux updater for flup writing */
/* possible values for flup type flag */
#define SWE_FLUP_MODE_FLASHWRITER_ELF 0x00U  /* FLUP in 0:BLSW starts with an ELF image */ 
#define SWE_FLUP_MODE_FLASHWRITER_ABOOT 0x01U /*FLUP in 0:BLSW starts with an appsboot image */
#define SWE_FLUP_MODE_UPDATER 0xFFU /* Update only Updater image via old aboot */
/*
 * SWE valid flag
 */
typedef unsigned int m_uint32;
typedef enum _SWE_VALID_t {
  SWE_VALID   = 0u,
  SWE_CHECKED = 0x1u,
  SWE_INVALID = 0xffu
} SWE_VALID_t;


/*
 * SWE class
 */
typedef enum _SWE_CLASS_t {
  SWE_CLASS_HWEL = 0x01u, /* [nur CAN MCU ]Hardware (Elektronik) Steuerger�t, Steckkarte, Platine */
  SWE_CLASS_HWAP = 0x02u, /* Hardwareauspr�gung Nicht programmiertechnisch relevante Auspr�gung der Hardware z.B. Geh�useform, Befestigung, Funkfrequenz */
  SWE_CLASS_BTLD = 0x06u, /* [nur CAN MCU ] Bootloader-Software, die den f�r die Fahrzeugprogrammierung notwendigen Flashloader enth�lt */
  SWE_CLASS_FLSL = 0x07u, /* [nur NAD] Flashloader Software, die den f�r die Fahrzeugprogrammierung notwendigen Flashloader f�r Slave-Prozessoren bei Mehrprozessorsystemen enth�lt */
  SWE_CLASS_SWFL = 0x08u, /* Software ECU-Speicherimage Software f�r Flashspeicher-ECU mit Applikation, Funktionen,Parameter, Daten, Kennlinien */
  SWE_CLASS_FLUP = 0x1du, /* [nur NAD] Flashloader-Update-Applikation Software, mit der eine FLSL-SWE in das Steuerger�t eingespielt wird */
  SWE_CLASS_NONE = 0xffu
} SWE_CLASS_t;


/*
 * Data of one SWE in SVK_READ
 */
/* these are offsets in below swe_version array where the mentioned version data is stored */
/* Do NOT confuse with SWE_XXX_IDX, which is the index within the SGBM Id in the SWE Header! */
#define SWE_VERS_MAJ_IDX 0U
#define SWE_VERS_MIN_IDX 1U
#define SWE_VERS_PAT_IDX 2U
#define SWE_INVALID_VERSION 0xFFU

typedef PACK(struct) _SWE_INFO_t {
  uint8       valid_flag;
  uint8       swe_class;
  uint8       swe_ident[SWE_SGBM_IDENT_SIZE];
  uint8       swe_version[SWE_VERSION_SIZE];
  uint8       swe_dev_info_UART_BL;
  uint8       swe_dev_info_UART_API;
  uint8       swe_dev_info_APPLICATION;
} SWE_INFO_t;

/*
 * Number of SWEs in SVK_READ
 */
/* Indices in svk for swe_info array to identify the appropriate swe_info object */

#define SWE_IDX_FLSL 0U /* SBL1,SBL2,RPM,Appsbl,Partition table, Linux updater image */
#define SWE_IDX_MODEM 1U  /* DSP1..3 */
#define SWE_IDX_SYSMAIN 2U /* Linux kernel */
#define SWE_IDX_APPLMAIN 3U /* Linux file systems */
#define SWE_IDX_FLUP 4U   /* This is the new to be installed FLSL just downloaded. Note: this MUST be last!!! */
#define MAX_NAD_SWE 5U  /* Maximum number of SWE stored in persistency partition */

#define SYS_MAX_NAD_SWE (MAX_NAD_SWE) /* Historical cross define */

#define SWE_MAX_COMPAT (MAX_NAD_SWE) /* This should be the same as the max. no of SWE */
/*
 * SVK_READ parameter data
 */
typedef PACK(struct) _SYS_SVK_t {
  m_uint32    swe_number;
  SWE_INFO_t  swe_info[SYS_MAX_NAD_SWE];
} SYS_SVK_t;

typedef PACK(struct) _NAD_COMPAT_t {
  uint8       sbl_modem;
  uint8       sbl_appl;
  uint8       sbl_filesys;
  uint8       modem_appl;
  uint8       modem_filesys;
  uint8       appl_filesys;
  uint8       hw_revision;
} NAD_COMPAT_t;
typedef PACK(struct) _SWE_COMPAT_t {
  m_uint32    swe_compat_magic; /* MAGIC NUMBER to distinguish between formats */
  NAD_COMPAT_t swe_nad_compat[SWE_MAX_COMPAT];
} SWE_COMPAT_t;

#define SWE_COMPAT_MAGIC_NUMBER_1 0xa2b56d4aU /* totally random, but unique number for swe_compat_magic entry.
                                              This should be changed each time the format of SWE_COMPAT_t changes */
#define SWE_COMPAT_NO_DEPENDENCY 0xffU  /* [Default] Compatibility value for no restrictions (wildcard) */
#define SWE_HW_COMPAT_REV_0 0u    /* Potential readouts for HW Revisions */
#define SWE_HW_COMPAT_REV_1 1u
#define SWE_HW_COMPAT_REV_2 2u
#define SWE_HW_COMPAT_REV_3 3u
#define SWE_HW_COMPAT_REV_4 4u
#define SWE_HW_COMPAT_REV_5 5u
#define SWE_HW_COMPAT_REV_6 6u
#define SWE_HW_COMPAT_REV_7 7u
#define SWE_HW_COMPAT_REV_8 8u
#define SWE_HW_COMPAT_REV_9 9u
#define SWE_HW_COMPAT_REV_10 10u
#define SWE_HW_COMPAT_REV_11 11u
#define SWE_HW_COMPAT_REV_12 12u
#define SWE_HW_COMPAT_REV_13 13u
#define SWE_HW_COMPAT_REV_14 14u
#define SWE_HW_COMPAT_REV_15 15u
#define SWE_HW_COMPAT_REV_NONE 0xFFu

/* This is the structure as written to or read from the 0:BLDT structure in the SVK SECTION. see sys_bldt.h */

#define BLDT_SVK_MAGIC_NUMBER_ATM 0x4b93f279U /* totally random, but unique number for swe_compat_magic entry.
                                              This should be changed each time the format of 0:BLDT data changes */
typedef PACK(struct) _SYS_BLDT_SVK_t{
  m_uint32     magic; /* MAGIC NUMBER to distinguish between formats */
  SYS_SVK_t    system_svk_info;
  SWE_COMPAT_t system_compat_info;
} SYS_BLDT_SVK_t;

#endif /* SYS_SWE_INFO_H_ */
