#define UTIL_LINUX_VERSION "2.12"
#define util_linux_version "util-linux-2.12"

#define HAVE_blkpg_h
#define HAVE_kd_h
#define HAVE_locale_h
#define HAVE_langinfo_h
#define HAVE_sys_user_h
#define HAVE_asm_types_h
//#define NEED_tqueue_h
