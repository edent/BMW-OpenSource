#define SWAPON_HAS_TWO_ARGS
#include <asm/page.h>
#include <sys/swap.h>
