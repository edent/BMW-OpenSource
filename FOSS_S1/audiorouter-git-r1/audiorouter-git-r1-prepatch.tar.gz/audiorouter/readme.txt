audio routing on application processor

      * emergency call via external codec, mic, backup speaker
      * assist call via headunit based on voip (ethernet), not implemented yet
      * eol, diagnosis capabilities, not implemented yet

At the moment the router daemon is not implemented. For testing purposes there is
a startup script, which initializes voice audio via the external codec.

2012-09-18, @peiker/ol
