#ifndef XGETLOADAVG_H
#define XGETLOADAVG_H


double xgetloadavg(void);


#endif
