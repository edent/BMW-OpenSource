/*
mediastreamer2 library - modular sound and video processing and streaming
Copyright (C) 2006  Simon MORLAT (simon.morlat@linphone.org)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#if defined(HAVE_CONFIG_H)
#include "mediastreamer-config.h"
#endif

#include <alsa/asoundlib.h>


#include "mediastreamer2/msfilter.h"
#include "mediastreamer2/msticker.h"
#include "mediastreamer2/mssndcard.h"

#include <values.h> /* for MAXLONG */
#include <stdio.h>


#include <pthread.h>
#include <sched.h>        /* for Linux realtime scheduling */
#include "pa_buffer.h"

#ifdef ENABLE_ALSA_ASRC
#include <pa_asrc.h>
#include <asrc_ss_log_thread.h>
#endif

#ifdef TEST_SINE_STIMULUS
#include <math.h>
#endif


/* ----------------- handling of entangled audio devices  ----------------- */
/*
 * The Qualcomm host pcm interface for low latency access to voice audio data
 * (modem uplink and downlink) has serveral restrictions. First it requires
 * an active voice call, secondly both of the audio channels for capturing
 * and playing audio data must be opened and initialized correctly.
 * Otherwise host pcm interface will not deliver any audio data causing a
 * deadlock situation within incoming calls (from PSTN to MDM9625 to an external
 * VoIP client). As a workaround we open all entangled audio devices in case its
 * necessary.
 */

#define ALSA_HOSTPCM_CAPTURE_DEV  "hw:0,11"
#define ALSA_HOSTPCM_PLAYBACK_DEV "hw:0,14"

#define HOST_PCM_ATOMIC_SAMPLES                320              /* corresponing to 20ms */
#define HOST_PCM_PLAYBACK_JITTER_BUF_SAMPLES   (3 * HOST_PCM_ATOMIC_SAMPLES)

/**
 * maximum read/write errors on the alsa interface allowed before closing
 * worker thread. When underlying audio subsystem is reconfigured e.g.
 * when call is terminated early we can get a lot of errors, flodding
 * syslog and buffers leading utlimately to malfuntions of voice audio.
 */
#define ALSA_MAX_ERRORS_ALLOWED   10


/**
 * disable usage of jitter buffer for lowest possible latency which will
 * cause audio glidges from time to time. Usage of this option is not
 * recommeded.
 */
// #define HOST_PCM_DISABLE_JITTER_BUFFER


/**
 * configuration flag to indicate that Qualcomms infamous host pcm interface is
 * is used. The flag is initialized in ms_alsa_card_new_custom() which
 * is invoked when application is started up.
 */
int g_use_hostpcm_interface = 0;


/*!
 *  true when range shift from 14 to 16 bit and vice versa is required
 *  for GSM case
 */
static int need_alsa_gsm_format_adjustment( void )
{
#ifdef ALSA_GSM_FORMAT_ADJUSTMENT
  return 1;
#else
  return( g_use_hostpcm_interface );
#endif
}


typedef struct {
  char*              name;
  snd_pcm_stream_t   stream;
} t_entangled_pcm_dev;


static t_entangled_pcm_dev entangled_pcm_dev_list[] = {
  { ALSA_HOSTPCM_CAPTURE_DEV,  SND_PCM_STREAM_CAPTURE },
  { ALSA_HOSTPCM_PLAYBACK_DEV, SND_PCM_STREAM_PLAYBACK },
  { NULL, 0 }
};

typedef struct _AlsaReadData  AlsaReadData;
typedef struct _AlsaReadData  AlsaWriteData;

typedef struct
{
  pthread_t         thread;
  int               run;                        /** exit threads when run = 0 */
  long              frame_cnt;

  AlsaReadData*     alsaReadDataPtr;
  AlsaWriteData*    alsaWriteDataPtr;

  snd_pcm_t*        pcm_capture_ptr;
  snd_pcm_t*        pcm_playback_ptr;

  int16_t*          capture_backend_ptr;        /** ping-pong buffer host pcm side for capturing */
  int16_t*          capture_frontend_ptr;       /** ping-pong buffer alsa read side */

  int16_t*          playback_backend_ptr;       /** ping-pong buffer host pcm side for playback */
  int16_t*          playback_frontend_ptr;      /** ping-pong buffer alsa write side */

  int16_t*          capture_frontend_r_ptr;
  int16_t*          capture_frontend_w_ptr;
  int16_t*          playback_frontend_r_ptr;
  int16_t*          playback_frontend_w_ptr;

  int16_t*          capture_heap_ptr;           /** all captured data (front- and backend */
  int16_t*          playback_heap_ptr;          /** all data to be played back (front- and backend */

  int16_t           error_cnt;                  /** counter of occured alsa error  */
  int16_t           max_errors;                 /** maximum number of errors before closed worker thread */

#ifdef ENABLE_ALSA_ASRC
  pa_asrc_buf*      playback_asrc_ptr;          /** jitter ring buffer struct where ASRC is operating on */
  log_data_thread_t* p_log_thread;              /** pointer to sample stream logger thread */
  pthread_mutex_t*  pLogSSMutex;                /** mutex for sample steram logger */
#else
  pa_ringBuf*       playback_jitter_ring;       /** jitter ring buffer struct where ASRC is operating on */
#endif
  int16_t*          playback_jitter_heap;       /** mananged internallyinternally  by playback_jitter_ring */

  pthread_mutex_t*  pMutex;                     /** mutex for this object */

  int               initialized;

} t_asrc_thread_data;

struct _AlsaReadData{
	char *pcmdev;
	snd_pcm_t *handle;
	int rate;
	int nchannels;
	uint64_t wc_offset;
	uint64_t read_samples;
	double av_skew;

  t_asrc_thread_data* hostPcmDataPtr;

#ifdef THREADED_VERSION
	ms_thread_t thread;
	ms_mutex_t mutex;
	MSBufferizer * bufferizer;
	bool_t read_started;
	bool_t write_started;
#endif
};


#ifdef TEST_SINE_STIMULUS
static int16_t sine400[320]; /* 20ms for 400Hz test data */
#endif

/**
 * if the given alsa pcm device name is entangled return the corresponding
 * element in entangled device list, otherise NULL.
 */
static t_entangled_pcm_dev* alsa_get_entangled_asrc_dev_for_name( const char *name )
{
  int d;

  for( d=0;  entangled_pcm_dev_list[d].name != NULL; ++d)
  {
    if( strcmp( entangled_pcm_dev_list[d].name, name ) == 0 )
    {
      ms_message( "alsa_get_entangled_dev_for_name: audio device %s is entangled, open up all", name );
      break;
    }
  }

  if( entangled_pcm_dev_list[d].name )
    return ( & entangled_pcm_dev_list[d] );
  else
    return NULL;
}

static snd_pcm_t * alsa_open_r(const char *pcmdev,int bits,int stereo,int rate);
static snd_pcm_t * alsa_open_w(const char *pcmdev,int bits,int stereo,int rate);


/**
 */
static int alsa_open_asrc_devices( t_asrc_thread_data* p )
{
  if( p->alsaReadDataPtr == NULL || p->alsaReadDataPtr == NULL )
  {
    ms_error( "alsa_open_asrc_devices: alsa thread data not correctly initialized error!" );
    return -1;
  }

  p->pcm_capture_ptr = alsa_open_r( p->alsaReadDataPtr->pcmdev, 16 /* bits */, 0/* stereo */, 16000 /* rate */ );
  if( p->pcm_capture_ptr != NULL )
  {
    p->pcm_playback_ptr = alsa_open_w( p->alsaWriteDataPtr->pcmdev, 16 /* bits */, 0/* stereo */, 16000 /* rate */ );
    if( p->pcm_playback_ptr != NULL )
      return 0;
    else
      ms_error("alsa_open_asrc_devices: could not open playback device error!");
  }
  else
  {
    ms_error("alsa_open_asrc_devices: could not open capture device error!");
  }

  return -1;
}


static int alsa_close_asrc_devices( t_asrc_thread_data* p )
{
  int err;

  if( p->pcm_playback_ptr != NULL )
    err = snd_pcm_close( p->pcm_playback_ptr );

  if( p->pcm_capture_ptr != NULL )
    err |= snd_pcm_close( p->pcm_capture_ptr );

  return err;
}



/* --- utility functions for format conversions (GMS/UMTS is 14 bit encoded) */
static void frame_copy_and_shift_left( int16_t* dest, const int16_t* source, const int shifts, const int elements )
{
  int     i, overflow = 0;
  int32_t e;

  for( i=0; i<elements; ++i )
  {
    e= (int32_t) source[i];
    e <<= shifts;

    if( e < -32768 )
    {
      e = -32768;
      overflow = 1;
    }
    else if( e > 32767 )
    {
      e = 32767;
      overflow = 1;
    }

    dest[i] = (int16_t)e;
  }

  if( overflow )
    ms_error( "frame_copy_and_shift_left: overflow error!\n");
}

static void frame_copy_and_shift_right( int16_t* dest, const int16_t* source, const int shifts, const int elements )
{
  int i;

  for( i=0; i<elements; ++i )
  {
    dest[i] = source[i] >> shifts;
  }
}


static void* asrc_proc_function( void* threadData )
{
  t_asrc_thread_data* p = (t_asrc_thread_data *)threadData;
  struct sched_param  sc_param;
  int frames_read, frames_written = 0, frames_to_playback;
  int16_t* tmpPtr;
  int stopped = 0;
#if !defined(HOST_PCM_DISABLE_JITTER_BUFFER) && !defined(ENABLE_ALSA_ASRC)
  int filling_state;
#endif

  /*
   *  On Linux activate real time scheduling for more precise profiling
   */
  sc_param.sched_priority = sched_get_priority_max( SCHED_FIFO );
  sched_setscheduler( 0, SCHED_FIFO, & sc_param );

  stopped = ( alsa_open_asrc_devices( threadData ) != 0);

  /*
   * Host PCM Interface Processing Loop for Operating entangled ALSA R/W Devices
   */
  ms_message("asrc_proc_function: thread started" );
  while( p->run && !stopped )
  {
    /*
     * --- read data from pcm interface ---
     */
    if ((frames_read = snd_pcm_readi( p->pcm_capture_ptr,
                                    p->capture_backend_ptr,
                                    HOST_PCM_ATOMIC_SAMPLES)) < 0)
    {
      ms_error( "asrc_proc_function: snd_pcm_readi( codec ) -> error %d in frame %ld!",
                frames_read,
                p->frame_cnt );

      /* exit working thread when too much errors occur */
      if( ++(p->error_cnt) >  p->max_errors )
      {
        ms_error("asrc_proc_function: got %d errors on alsa interface, stop worker thread now!",
                 p->max_errors );
        stopped = 1;
      }
    }

    if( need_alsa_gsm_format_adjustment() )
      frame_copy_and_shift_left( p->capture_backend_ptr, p->capture_backend_ptr, 2, HOST_PCM_ATOMIC_SAMPLES );


    /*
     * --- copy read data to front end pong bufer which is process outside this thread ---
     */
#ifdef HOST_PCM_DISABLE_JITTER_BUFFER
    pthread_mutex_lock ( p->pMutex );
    frames_to_playback = p->playback_frontend_w_ptr - p->playback_frontend_r_ptr;
    memcpy( p->playback_backend_ptr, p->playback_frontend_ptr, frames_to_playback * sizeof(int16_t) );
    /* mute empty frames which shall never happen */
    memset( p->playback_backend_ptr + frames_to_playback, 0,
            (HOST_PCM_ATOMIC_SAMPLES - frames_to_playback) * sizeof(int16_t) );
    pthread_mutex_unlock ( p->pMutex );
#elif defined( ENABLE_ALSA_ASRC )
    frames_to_playback = pa_asrc_get( p->playback_asrc_ptr,
                                      (int16_t *)p->playback_backend_ptr,
                                      HOST_PCM_ATOMIC_SAMPLES,
                                      0ULL );
#else
    pthread_mutex_lock ( p->pMutex );
    filling_state = p->playback_jitter_ring->uiFill;
    if( p->playback_jitter_ring->uiFill < HOST_PCM_ATOMIC_SAMPLES * sizeof(int16_t) )
    {
      frames_to_playback = 0;
      memset( p->playback_backend_ptr, 0, HOST_PCM_ATOMIC_SAMPLES * sizeof(int16_t) );
      ms_warning("\t- host pcm playback jitter buffer underun!");
    }
    else
    {
      frames_to_playback = _pa_ringBufGetData( p->playback_jitter_ring,
                                              (int8_t *)p->playback_backend_ptr,
                                              HOST_PCM_ATOMIC_SAMPLES * sizeof(int16_t) ) >> 1;
    }
    pthread_mutex_unlock ( p->pMutex );
#endif



#if !defined(HOST_PCM_DISABLE_JITTER_BUFFER) && !defined(ENABLE_ALSA_ASRC)
    if( !( p->frame_cnt % 500 ) )
      ms_message("\t@: %d", filling_state );
#endif


    /*
     * --- write data to pcm interface ---
     */
    if( need_alsa_gsm_format_adjustment() )
      frame_copy_and_shift_right( p->playback_backend_ptr, p->playback_backend_ptr, 2, HOST_PCM_ATOMIC_SAMPLES );

    if ((frames_written = snd_pcm_writei( p->pcm_playback_ptr,
                                          p->playback_backend_ptr,
                                          HOST_PCM_ATOMIC_SAMPLES)) != HOST_PCM_ATOMIC_SAMPLES )
    {
      ms_error( "snd_pcm_writei( codec ) -> error %d in frame %ld!",
                frames_written,
                p->frame_cnt );
      /* exit working thread when too much errors occur */
      if( ++(p->error_cnt) >  p->max_errors )
      {
        ms_error("asrc_proc_function: got %d errors on alsa interface, stop worker thread now!",
                 p->max_errors );
        stopped = 1;
      }
    }

    /*
     * --- swap front end and back end ping-pong pointers ---
     */
    pthread_mutex_lock ( p->pMutex );

    /* loopback test case */
    /* memcpy( p->playback_frontend_ptr, p->capture_backend_ptr, HOST_PCM_ATOMIC_SAMPLES * sizeof(int16_t) ); */

    tmpPtr = p->playback_backend_ptr;
    p->playback_backend_ptr = p->playback_frontend_ptr;
    p->playback_frontend_ptr = tmpPtr;

    tmpPtr = p->capture_backend_ptr;
    p->capture_backend_ptr = p->capture_frontend_ptr;
    p->capture_frontend_ptr = tmpPtr;

    /* and reset front end read/write pointers */
    p->capture_frontend_r_ptr = p->capture_frontend_ptr;
    p->capture_frontend_w_ptr = p->capture_frontend_ptr + HOST_PCM_ATOMIC_SAMPLES;

    /* these pointers are be used to mute missing frames later on */
    p->playback_frontend_r_ptr = p->playback_frontend_ptr;
    p->playback_frontend_w_ptr = p->playback_frontend_ptr;

    ++p->frame_cnt;

    pthread_mutex_unlock ( p->pMutex );

  } /* while( p->run && !stopped ) */


  alsa_close_asrc_devices( threadData );

  ms_message( "asrc_proc_function: host pcm closed" );
  if(0) ms_message("%d", frames_to_playback ); /* just to avoid not used warning */

  return( (void *)NULL );
}


int mutex_lock( void* mutexPtr )
{
  return pthread_mutex_lock( (pthread_mutex_t*) mutexPtr );
}


int mutex_unlock( void* mutexPtr )
{
  return pthread_mutex_unlock( (pthread_mutex_t*) mutexPtr );
}


static int init_asrc_thread_data( t_asrc_thread_data** threadDataHandle )
{
  static t_asrc_thread_data hostPcmThreadObj = { .initialized = 0 };
  t_asrc_thread_data* threadDataPtr = &hostPcmThreadObj;
  const int jitter_buffer_samples = HOST_PCM_PLAYBACK_JITTER_BUF_SAMPLES;
  const int jitter_buffer_size = jitter_buffer_samples * sizeof(int16_t);

  ms_message( "init_asrc_thread_data: got init request");

  /* singleton, only intialize once */
  if( threadDataPtr->initialized )
  {
    *threadDataHandle = threadDataPtr;

    ms_message( "init_asrc_thread_data: already initialized, return: %lx", (unsigned long) threadDataPtr );
    return 0;
  }

  ms_message( "init_asrc_thread_data: start initializing ...");

  memset( threadDataPtr, 0, sizeof( t_asrc_thread_data ) );

  threadDataPtr->capture_heap_ptr = malloc( HOST_PCM_ATOMIC_SAMPLES * sizeof(int16_t) * 2 /* ping pong */ );
  if( threadDataPtr->capture_heap_ptr == NULL )
  {
    ms_error( "init_asrc_thread_data: could not allocate capture ping pong buffers!");
    goto init_asrc_thread_error;
  }
  threadDataPtr->capture_backend_ptr = threadDataPtr->capture_heap_ptr;
  threadDataPtr->capture_frontend_ptr = & threadDataPtr->capture_heap_ptr[HOST_PCM_ATOMIC_SAMPLES];
  threadDataPtr->capture_frontend_r_ptr = threadDataPtr->capture_frontend_ptr;
  threadDataPtr->capture_frontend_w_ptr = threadDataPtr->capture_frontend_ptr;

  threadDataPtr->playback_heap_ptr = malloc( HOST_PCM_ATOMIC_SAMPLES * sizeof(int16_t) * 2 /* ping pong */ );
  if( threadDataPtr->playback_heap_ptr == NULL )
  {
    ms_error( "init_asrc_thread_data: could not allocate playback ping pong buffers!");
    goto init_asrc_thread_error;
  }
  threadDataPtr->playback_backend_ptr = threadDataPtr->playback_heap_ptr;
  threadDataPtr->playback_frontend_ptr = & threadDataPtr->playback_heap_ptr[HOST_PCM_ATOMIC_SAMPLES];
  threadDataPtr->playback_frontend_r_ptr = threadDataPtr->playback_frontend_ptr;
  threadDataPtr->playback_frontend_w_ptr = threadDataPtr->playback_frontend_ptr;


#ifdef ENABLE_ALSA_ASRC
  threadDataPtr->playback_asrc_ptr = malloc( sizeof( pa_asrc_buf ) );
  if( threadDataPtr->playback_asrc_ptr == NULL )
#else
  threadDataPtr->playback_jitter_ring = malloc( sizeof( pa_ringBuf ) );
  if( threadDataPtr->playback_jitter_ring == NULL )
#endif
  {
    ms_error( "init_asrc_thread_data: could not allocate data for jitter buffer object!");
    goto init_asrc_thread_error;
  }

  threadDataPtr->playback_jitter_heap = malloc( jitter_buffer_size );
  if( threadDataPtr->playback_jitter_heap == NULL )
  {
    ms_error( "init_asrc_thread_data: could not allocate jitter buffer heap!");
    goto init_asrc_thread_error;
  }

  threadDataPtr->pMutex = malloc( sizeof(pthread_mutex_t) );
  if( threadDataPtr->pMutex == NULL )
  {
    ms_error( "init_asrc_thread_data: could not allocate mutex object!");
    goto init_asrc_thread_error;
  }

  if( pthread_mutex_init( threadDataPtr->pMutex, 0 ) != 0 )
  {
    ms_error( "init_asrc_thread_data: could not initialize mutex object!");
    free( threadDataPtr->pMutex );
    threadDataPtr->pMutex = NULL;
    goto init_asrc_thread_error;
  }

#ifdef ENABLE_ALSA_ASRC
  threadDataPtr->pLogSSMutex = malloc( sizeof(pthread_mutex_t) );
  if( threadDataPtr->pLogSSMutex == NULL )
  {
    ms_error( "init_asrc_thread_data: could not allocate logger mutex object!");
    goto init_asrc_thread_error;
  }

  if( pthread_mutex_init( threadDataPtr->pLogSSMutex, 0 ) != 0 )
  {
    ms_error( "init_asrc_thread_data: could not initialize mutex object!");
    free( threadDataPtr->pLogSSMutex );
    threadDataPtr->pLogSSMutex = NULL;
    goto init_asrc_thread_error;
  }

  assert( pa_asrc_init( threadDataPtr->playback_asrc_ptr,
                        (void *)threadDataPtr->playback_jitter_heap,
                        jitter_buffer_samples,
                        HOST_PCM_ATOMIC_SAMPLES,
                        1, /* channels */
                        1, /* enable log */
                        threadDataPtr->pMutex,
                        threadDataPtr->pLogSSMutex, /* mutexLogPtr */
                        malloc,
                        free,
                        mutex_lock,
                        mutex_unlock,
                        (PA_ASRC_PRINT_CALLBACK_PTR)ms_message,
                        (PA_ASRC_PRINT_CALLBACK_PTR)ms_error ) == 0 );

  threadDataPtr->p_log_thread = create_asrc_log_thread( threadDataPtr->playback_asrc_ptr );
  if( threadDataPtr->p_log_thread == NULL )
  {
    ms_error( "init_asrc_thread_data: could not initialize logging thread!");
    return -1;
  }
#else
  assert( _pa_ringBufInit( threadDataPtr->playback_jitter_ring,
                          (int8_t *)threadDataPtr->playback_jitter_heap,
                          jitter_buffer_size ) == 0 );
#endif

  threadDataPtr->initialized = 1;
  *threadDataHandle = threadDataPtr;

  #ifdef TEST_SINE_STIMULUS
  {
    const double amp = 32767.0 / 8.0;
    const double pi = 3.1415;
    int i;
    // printf( "sinetab --->\n" );
    for( i=0; i<320; ++i )
    {
      sine400[i] = amp * sin( 2 * pi * 400.0 * i / 16000.0  );

      /*
      printf("%d, ", sine400[i] );
      if( !(i%6)  )
        printf("\n");
      */
    }
  }
  #endif


  ms_message( "init_asrc_thread_data: init_asrc_thread_data: initializing successful, return: %lx", (unsigned long)threadDataPtr );
  return 0;

init_asrc_thread_error:
  if( threadDataPtr->capture_heap_ptr )
    free( threadDataPtr->capture_heap_ptr );

  if( threadDataPtr->playback_heap_ptr )
    free( threadDataPtr->playback_heap_ptr );

#ifdef ENABLE_ALSA_ASRC
  if( threadDataPtr->playback_asrc_ptr )
    free( threadDataPtr->playback_asrc_ptr );
#else
  if( threadDataPtr->playback_jitter_ring )
    free( threadDataPtr->playback_jitter_ring );
#endif

  if( threadDataPtr->playback_jitter_heap )
    free( threadDataPtr->playback_jitter_heap );

  if( threadDataPtr->pMutex )
  {
    pthread_mutex_destroy( threadDataPtr->pMutex );
    free( threadDataPtr->pMutex );
  }

#ifdef ENABLE_ALSA_ASRC
  threadDataPtr->pLogSSMutex = malloc( sizeof(pthread_mutex_t) );
  if( threadDataPtr->pLogSSMutex )
  {
    pthread_mutex_destroy( threadDataPtr->pLogSSMutex );
    free( threadDataPtr->pLogSSMutex );
  }
#endif

  threadDataPtr->initialized = 0;

  ms_error( "init_asrc_thread_data: initializing error" );
  return -1;
}

static int start_asrc_thread( t_asrc_thread_data* threadDataPtr )
{
  struct sched_param sched_param;
  sched_param.sched_priority = sched_get_priority_max( SCHED_FIFO );
  int retcode;

  pthread_mutex_lock ( threadDataPtr->pMutex );
  if( threadDataPtr != NULL &&  !threadDataPtr->run )
  {
    threadDataPtr->run = 1;
    threadDataPtr->error_cnt = 0;
    threadDataPtr->max_errors = ALSA_MAX_ERRORS_ALLOWED;
    pthread_create( & threadDataPtr->thread, 0, asrc_proc_function, threadDataPtr );
    pthread_setschedparam( threadDataPtr->thread, SCHED_FIFO, &sched_param );

    retcode = 0;
  }
  else
  {
    retcode = -1;
  }
  pthread_mutex_unlock ( threadDataPtr->pMutex );

  return retcode;
}

static void stop_asrc_thread( t_asrc_thread_data* threadDataPtr )
{
  if( !threadDataPtr->initialized )
  {
    ms_error( "stop_asrc_thread: not initialized!" );
    return;
  }

  ms_message( "stop_asrc_thread: got request to stop!" );
  if( threadDataPtr->run )
  {
    pthread_mutex_lock ( threadDataPtr->pMutex );
    threadDataPtr->run = 0;
    pthread_mutex_unlock ( threadDataPtr->pMutex );

    ms_message( "stop_asrc_thread: waiting to be stopped ..." );
    pthread_join( threadDataPtr->thread, NULL );
    ms_message( "stop_asrc_thread: thread stopped" );
  }
  else
  {
    ms_message( "stop_asrc_thread: already stopped" );
  }
}

static void release_asrc_thread_data( t_asrc_thread_data* threadDataPtr )
{
  ms_message( "release_asrc_thread_data: got request to release host pcm thread data" );
  if( threadDataPtr!=NULL && threadDataPtr->initialized )
  {
    ms_message( "releasing asrc thread data ..." );

    /* stop wait for asrc threads to be stopped */
#ifdef ENABLE_ALSA_ASRC
    stop_asrc_log_thread( threadDataPtr->p_log_thread );
#endif
    stop_asrc_thread( threadDataPtr );
    ms_message( "release_asrc_thread_data: subprocess stopped" );
    pthread_mutex_destroy( threadDataPtr->pMutex );
    free( threadDataPtr->pMutex );

#ifdef ENABLE_ALSA_ASRC
    ms_message( "release_asrc_thread_data: destroy ss logger mutex ...");
    pthread_mutex_destroy( threadDataPtr->pLogSSMutex );
    free( threadDataPtr->pLogSSMutex );
#endif

    ms_message( "release_asrc_thread_data: free ping-pong buffers ...");
    free( threadDataPtr->capture_heap_ptr );
    free( threadDataPtr->playback_heap_ptr );
#ifdef ENABLE_ALSA_ASRC
    free( threadDataPtr->playback_asrc_ptr );
#else
    free( threadDataPtr->playback_jitter_ring );
#endif
    free( threadDataPtr->playback_jitter_heap );

    threadDataPtr->initialized = 0;
  }
  ms_message( "host pcm thread data released!" );
}



/**
 * when defined print out the filling states of the alsa fifo buffer
 * to standard output (console).
 * 2013-02-25 @peiker/ol
 */
// #define SHOW_ALSA_FILLING_STATES


/*
 * when ALSA_TRACE_AUDIO_DATA defined write audio data at alsa stubs
 * to filesystem for later analysis.
 * Use ./configure --enable-alsa-trace-audio to enable this.
 * 2013-02-25 @peiker/ol
 */
#ifdef ALSA_TRACE_AUDIO_DATA

# include <stdio.h>
# define TRACE_AUDIO_WRITE_FILENAME "/var/log/alsawritetrace.raw"
# define TRACE_AUDIO_READ_FILENAME  "/var/log/alsareadtrace.raw"
# define TRACE_AUDIO_MAX_FRAMES 3000 /* one minute trace data */

typedef struct {
  const char*            filename;
  FILE*                  fp;
  long                   max_traced_frames;
  long                   frame_cnt;
  int                    initialized;
} trace_audio_data_t;


/**
 * initialize audio data logger
 */
static int trace_audio_data_init( trace_audio_data_t* data,
                           const char* filename,
                           const long max_traced_frames )
{
  int rc = 0;

  data->filename = filename;
  data->max_traced_frames = max_traced_frames;

  data->fp = fopen( filename, "wb" );
  rc = (data->fp == NULL);
  data->initialized = 1;

  return rc;
}

/**
 * release audio data logger
 */
static void trace_audio_data_release( trace_audio_data_t* data )
{
  ms_message( "trace_audio_data_release: releasing ..." );
  if( data && data->fp )
  {
    ms_message( "trace_audio_data_release: closing file descriptors ..." );
    fclose( data->fp );
    data->fp = NULL;
    data->frame_cnt = 0;
    data->initialized = 0;
  }
  ms_message( "trace_audio_data_release: released" );
}

/**
 * read or write audio trace data
 */
static int trace_audio_data_process( trace_audio_data_t* data, const void* buf, const size_t size )
{
  int rc = 0;

  if( data->frame_cnt < data->max_traced_frames  &&  data->fp != NULL )
  {
    rc = (fwrite( buf, 1, size, data->fp ) != size);
    ++data->frame_cnt;
  }

  return rc;
}

static trace_audio_data_t  trace_alsa_read_data;
static trace_audio_data_t  trace_alsa_write_data;

#endif /* #ifdef ALSA_TRACE_AUDIO_DATA */






static int forced_rate=-1;

void ms_alsa_card_set_forced_sample_rate(int samplerate){
	if (samplerate==0 || samplerate<-1) {
		ms_warning("ms_alsa_card_set_forced_sample_rate(): bad value %i",samplerate);
		return;
	}
	forced_rate=samplerate;
}

//#define THREADED_VERSION

/*in case of troubles with a particular driver, try incrementing ALSA_PERIOD_SIZE
to 512, 1024, 2048, 4096...
then try incrementing the number of periods*/

/* for GSM/UMTS - VOIP gateway we use a period size of 20ms and 2 periods
   with respect to minimal latency. 2013-02-19 @peiker/ol */
#define ALSA_PERIODS 2
#define ALSA_PERIOD_TIME 20 /* alsa period time in ms (linphone uses normally 32ms for speex) */

/*uncomment the following line if you have problems with an alsa driver
having sound quality trouble:*/
/*#define EPIPE_BUGFIX 1*/

static MSSndCard * alsa_card_new(int id);
static MSSndCard *alsa_card_duplicate(MSSndCard *obj);
static MSFilter * ms_alsa_read_new(const char *dev);
static MSFilter * ms_alsa_write_new(const char *dev);


struct _AlsaData{
	char *pcmdev;
	char *mixdev;
};

typedef struct _AlsaData AlsaData;


static void alsa_resume(snd_pcm_t *handle){
	int err;
	snd_pcm_status_t *status=NULL;

	snd_pcm_status_alloca(&status);

	if ((err=snd_pcm_status(handle,status))!=0){
		ms_warning("snd_pcm_status() failed: %s",snd_strerror(err));
		return;
	}

	if (snd_pcm_status_get_state(status)==SND_PCM_STATE_SUSPENDED){
		ms_warning("Maybe suspended, trying resume");
		if ((err=snd_pcm_resume(handle))!=0){
			if (err!=EWOULDBLOCK) ms_warning("snd_pcm_resume() failed: %s",snd_strerror(err));
		}
	}
}

static int alsa_set_params(snd_pcm_t *pcm_handle, int rw, int bits, int stereo, int rate)
{
	snd_pcm_hw_params_t *hwparams=NULL;
	snd_pcm_sw_params_t *swparams=NULL;
	int dir;
	uint exact_uvalue;
	unsigned long exact_ulvalue;
	int channels;
	int periods=ALSA_PERIODS;
	int periodsize;
	snd_pcm_uframes_t buffersize;
	int err;
	int format;

	/* Allocate the snd_pcm_hw_params_t structure on the stack. */
	snd_pcm_hw_params_alloca(&hwparams);

	/* Init hwparams with full configuration space */
	if (snd_pcm_hw_params_any(pcm_handle, hwparams) < 0) {
		ms_warning("alsa_set_params: Cannot configure this PCM device.");
		return -1;
	}

	if (snd_pcm_hw_params_set_access(pcm_handle, hwparams, SND_PCM_ACCESS_RW_INTERLEAVED) < 0) {
		ms_warning("alsa_set_params: Error setting access.");
		return -1;
	}
	/* Set sample format */
	format=SND_PCM_FORMAT_S16;
	if (snd_pcm_hw_params_set_format(pcm_handle, hwparams, format) < 0) {
		ms_warning("alsa_set_params: Error setting format.");
		return -1;
	}
	/* Set number of channels */
	if (stereo) channels=2;
	else channels=1;
	if (snd_pcm_hw_params_set_channels(pcm_handle, hwparams, channels) < 0) {
		ms_warning("alsa_set_params: Error setting channels.");
		return -1;
	}
	/* Set sample rate. If the exact rate is not supported */
	/* by the hardware, use nearest possible rate.         */
	exact_uvalue=rate;
	dir=0;
	if ((err=snd_pcm_hw_params_set_rate_near(pcm_handle, hwparams, &exact_uvalue, &dir))<0){
		ms_warning("alsa_set_params: Error setting rate to %i:%s",rate,snd_strerror(err));
		return -1;
	}
	if (dir != 0) {
		ms_warning("alsa_set_params: The rate %d Hz is not supported by your hardware.\n "
		"==> Using %d Hz instead.", rate, exact_uvalue);
	}
	/* choose greater period size when rate is high */
	periodsize=ALSA_PERIOD_TIME * rate / 1000;

	/* Set buffer size (in frames). The resulting latency is given by */
	/* latency = periodsize * periods / (rate * bytes_per_frame)     */
	/* set period size */
	exact_ulvalue=periodsize;
	dir=0;
	if (snd_pcm_hw_params_set_period_size_near(pcm_handle, hwparams, &exact_ulvalue, &dir) < 0) {
		ms_warning("alsa_set_params: Error setting period size.");
		return -1;
	}
	if (dir != 0) {
		ms_warning("alsa_set_params: The period size %d is not supported by your hardware.\n "
		"==> Using %d instead.", periodsize, (int)exact_ulvalue);
	}
	ms_warning("alsa_set_params: periodsize:%d Using %d", periodsize, (int)exact_ulvalue);
	periodsize=exact_ulvalue;
	/* Set number of periods. Periods used to be called fragments. */
	exact_uvalue=periods;
	dir=0;
	if (snd_pcm_hw_params_set_periods_near(pcm_handle, hwparams, &exact_uvalue, &dir) < 0) {
		ms_warning("alsa_set_params: Error setting periods.");
		return -1;
	}
	ms_warning("alsa_set_params: period:%d Using %d", periods, exact_uvalue);
	if (dir != 0) {
		ms_warning("alsa_set_params: The number of periods %d is not supported by your hardware.\n "
		"==> Using %d instead.", periods, exact_uvalue);
	}
	periods = (int)exact_uvalue;

	if (snd_pcm_hw_params_get_buffer_size(hwparams, &buffersize)<0){
		buffersize=0;
		ms_warning("alsa_set_params: could not obtain hw buffer size.");
	}

	/* Apply HW parameter settings to */
	/* PCM device and prepare device  */
	if ((err=snd_pcm_hw_params(pcm_handle, hwparams)) < 0) {
		ms_warning("alsa_set_params: Error setting HW params:%s",snd_strerror(err));
		return -1;
	}
	/*prepare sw params */
	if (rw){
		snd_pcm_sw_params_alloca(&swparams);
		snd_pcm_sw_params_current(pcm_handle, swparams);
		ms_message("periodsize=%i, buffersize=%i",(int) periodsize,(int)buffersize);
    /* set start threshold to only one frame which is the least possible value on MDM9615
       2013-02-26 @peiker/ol */
		if ((err=snd_pcm_sw_params_set_start_threshold( pcm_handle, swparams, periodsize ))<0){
			ms_warning("alsa_set_params: Error setting start threshold:%s",snd_strerror(err));
		}
    /* changed stop threshold to maxlong which - hopefully - should disable complete filling
       of alsa fifo buffers (periods) on MDM9615 with respect to minimal latency.
       2013-02-19 @peiker/ol */
		if ((err=snd_pcm_sw_params_set_stop_threshold(pcm_handle, swparams,MAXLONG))<0){
			ms_warning("alsa_set_params: Error setting stop threshold:%s",snd_strerror(err));
		}
		if ((err=snd_pcm_sw_params(pcm_handle, swparams))<0){
			ms_warning("alsa_set_params: Error setting SW params:%s",snd_strerror(err));
			return -1;
		}
	}
	return 0;
}

#ifdef EPIPE_BUGFIX
static void alsa_fill_w (snd_pcm_t *pcm_handle)
{
	snd_pcm_hw_params_t *hwparams=NULL;
	int channels;
  snd_pcm_uframes_t buffer_size;
  unsigned int val;
	int buffer_size_bytes;
	void *buffer;

	/* Allocate the snd_pcm_hw_params_t structure on the stack. */
	snd_pcm_hw_params_alloca(&hwparams);
	snd_pcm_hw_params_current(pcm_handle, hwparams);

	/* get channels */
	snd_pcm_hw_params_get_channels (hwparams, &val);
  channels = (int)val;

	/* get buffer size */
	snd_pcm_hw_params_get_buffer_size (hwparams, &buffer_size);

	/* fill half */
	buffer_size /= 2;

	/* allocate buffer assuming 2 bytes per sample */
	buffer_size_bytes = buffer_size * channels * 2;
	buffer = alloca (buffer_size_bytes);
	memset (buffer, 0, buffer_size_bytes);

	/* write data */
	snd_pcm_writei(pcm_handle, buffer, buffer_size);
}
#endif

static snd_pcm_t * alsa_open_r(const char *pcmdev,int bits,int stereo,int rate)
{
	snd_pcm_t *pcm_handle;
	int err;
#if defined(THREADED_VERSION) || defined(ENABLE_ALSA_ASRC)
	/* want blocking mode for threaded version and asrc */
  int mode = 0;
#else
	/* otherwise non blocking */
  int mode = SND_PCM_NONBLOCK;
#endif

	ms_message("alsa_open_r: opening %s at %iHz, bits=%i, stereo=%i",pcmdev,rate,bits,stereo);


	if (snd_pcm_open(&pcm_handle, pcmdev,SND_PCM_STREAM_CAPTURE,mode) < 0) {
		ms_warning("alsa_open_r: Error opening PCM device %s",pcmdev );
		return NULL;
	}
	{
	struct timeval tv1;
	struct timeval tv2;
	struct timezone tz;
	int diff = 0;
	err = gettimeofday(&tv1, &tz);
	while (1) {
		/* if (!(alsa_set_params(pcm_handle,0,bits,stereo,rate)<0)){ */
    /* changed to enable sw parameters
       2012-02-25 @peiker/ol */
		if (!(alsa_set_params(pcm_handle,1,bits,stereo,rate)<0)){
			ms_message("alsa_open_r: Audio params set");
			break;
		}
		if (!gettimeofday(&tv2, &tz) && !err) {
			diff = ((tv2.tv_sec - tv1.tv_sec) * 1000000) + (tv2.tv_usec - tv1.tv_usec);
		} else {
			diff = -1;
		}
		if ((diff < 0) || (diff > 3000000)) { /* 3 secondes */
			ms_error("alsa_open_r: Error setting params for more than 3 seconds");
			snd_pcm_close(pcm_handle);
			return NULL;
		}
		ms_warning("alsa_open_r: Error setting params (for %d micros)", diff);
		usleep(200000);
	}
	}

	err=snd_pcm_start(pcm_handle);
	if (err<0){
		ms_warning("snd_pcm_start() failed: %s", snd_strerror(err));
	}
	return pcm_handle;
}

static snd_pcm_t * alsa_open_w(const char *pcmdev,int bits,int stereo,int rate)
{
	snd_pcm_t *pcm_handle;

#ifdef ENABLE_ALSA_ASRC
  int mode = 0;
#else
  int mode = SND_PCM_NONBLOCK;
#endif

	ms_message("alsa_open_w: opening %s at %iHz, bits=%i, stereo=%i",pcmdev,rate,bits,stereo);

	if (snd_pcm_open(&pcm_handle, pcmdev,SND_PCM_STREAM_PLAYBACK,mode) < 0) {
		ms_warning("alsa_open_w: Error opening PCM device %s",pcmdev );
		return NULL;
	}
	alsa_resume(pcm_handle);
	{
	struct timeval tv1;
	struct timeval tv2;
	struct timezone tz;
	int diff = 0;
	int err;
	err = gettimeofday(&tv1, &tz);
	while (1) {
		if (!(alsa_set_params(pcm_handle,1,bits,stereo,rate)<0)){
			ms_message("alsa_open_w: Audio params set");
			break;
		}
		if (!gettimeofday(&tv2, &tz) && !err) {
			diff = ((tv2.tv_sec - tv1.tv_sec) * 1000000) + (tv2.tv_usec - tv1.tv_usec);
		} else {
			diff = -1;
		}
		if ((diff < 0) || (diff > 3000000)) { /* 3 secondes */
			ms_error("alsa_open_w: Error setting params for more than 3 seconds");
			snd_pcm_close(pcm_handle);
			return NULL;
		}
		ms_warning("alsa_open_w: Error setting params (for %d micros)", diff);
		usleep(200000);
	}
	}

	return pcm_handle;
}

static int alsa_can_read(snd_pcm_t *dev)
{
	snd_pcm_sframes_t avail;
	int err;

	alsa_resume(dev);
	avail = snd_pcm_avail_update(dev);
	/* A buggy driver does not return an error while being in Xrun */
	if (avail >= 0 && snd_pcm_state(dev) == SND_PCM_STATE_XRUN) avail=-EPIPE;
	if (avail < 0) {
		ms_error("snd_pcm_avail_update: %s", snd_strerror(avail));	// most probably -EPIPE
		/* overrun occured, snd_pcm_state() would return SND_PCM_STATE_XRUN
		 FIXME: handle other error conditions*/
		ms_error("*** alsa_can_read fixup, trying to recover");
		snd_pcm_drain(dev); /* Ignore possible error, at least -EAGAIN.*/
		err = snd_pcm_recover(dev, avail, 0);
		if (err){
			ms_error("snd_pcm_recover() failed with err %d: %s", err, snd_strerror(err));
			return -1;
		}
		err = snd_pcm_start(dev);
		if (err){
			ms_error("snd_pcm_start() failed with err %d: %s", err, snd_strerror(err));
			return -1;
		}
		ms_message("Recovery done");
	}
	return avail;
}


static int alsa_read(snd_pcm_t *handle,unsigned char *buf,int nsamples)
{
	int err;
#ifdef SHOW_ALSA_FILLING_STATES
  static long cnt = 0;
#endif /* #ifdef SHOW_ALSA_FILLING_STATES */

	err=snd_pcm_readi(handle,buf,nsamples);
	if (err<0) {
		ms_warning("alsa_read: snd_pcm_readi() returned %i",err);
		if (err==-EPIPE){
			snd_pcm_prepare(handle);
			err=snd_pcm_readi(handle,buf,nsamples);
			if (err<0) ms_warning("alsa_read: snd_pcm_readi() failed:%s.",snd_strerror(err));
		}else if (err==-ESTRPIPE){
			alsa_resume(handle);
		}else if (err!=-EWOULDBLOCK){
			ms_warning("alsa_read: snd_pcm_readi() failed:%s.",snd_strerror(err));
		}
	}else if (err==0){
		ms_warning("alsa_read: snd_pcm_readi() returned 0");
	}


#ifdef ALSA_TRACE_AUDIO_DATA
  /* trace audio data */
  if( ! trace_alsa_read_data.initialized )
  {
    if( trace_audio_data_init( &trace_alsa_read_data, TRACE_AUDIO_READ_FILENAME, TRACE_AUDIO_MAX_FRAMES ) )
    {
      ms_error( "alsa_read: initialization of alsa read trace process failed!");
    }
  }

  if( trace_audio_data_process( &trace_alsa_read_data, buf, nsamples * 2 ) )
  {
    ms_error( "alsa_read: read trace process failed!");
  }
#endif /* #ifdef ALSA_TRACE_AUDIO_DATA */

#ifdef SHOW_ALSA_FILLING_STATES
  if( !(cnt % 50) )
  {
    snd_pcm_sframes_t avail;
    avail = snd_pcm_avail_update( handle );

    ms_message("alsa_read %d samples, available samples after read %ld", nsamples, (long)avail );
  }

  ++cnt;
#endif /* #ifdef SHOW_ALSA_FILLING_STATES */

	return err;
}

static int alsa_write(snd_pcm_t *handle,unsigned char *buf,int nsamples)
{
	int err;
#ifdef SHOW_ALSA_FILLING_STATES
  static long cnt = 0;
#endif /* #ifdef SHOW_ALSA_FILLING_STATES */


	if ((err=snd_pcm_writei(handle,buf,nsamples))<0){
		if (err==-EPIPE){
			snd_pcm_prepare(handle);
#ifdef EPIPE_BUGFIX
			alsa_fill_w (handle);
#endif
			err=snd_pcm_writei(handle,buf,nsamples);
			if (err<0) ms_warning("alsa_card_write: Error writing sound buffer (nsamples=%i):%s",nsamples,snd_strerror(err));
		}else if (err==-ESTRPIPE){
			alsa_resume(handle);
		}else if (err!=-EWOULDBLOCK){
			ms_warning("alsa_card_write: snd_pcm_writei() failed:%s.",snd_strerror(err));
		}
	}else if (err!=nsamples) {
		ms_debug("Only %i samples written instead of %i",err,nsamples);
	}


#ifdef ALSA_TRACE_AUDIO_DATA
  /* trace audio data */
  if( ! trace_alsa_write_data.initialized )
  {
    if( trace_audio_data_init( &trace_alsa_write_data, TRACE_AUDIO_WRITE_FILENAME, TRACE_AUDIO_MAX_FRAMES ) )
    {
      ms_error( "alsa-write: initialization of alsa write trace process failed!");
    }
  }

  if( trace_audio_data_process( &trace_alsa_write_data, buf, nsamples * 2 ) )
  {
    ms_error( "write trace process failed!\n");
  }
#endif /* #ifdef ALSA_TRACE_AUDIO_DATA */


#ifdef SHOW_ALSA_FILLING_STATES
  if( !(cnt % 50) )
  {
    snd_pcm_sframes_t avail;
    avail = snd_pcm_avail_update( handle );

    ms_message("alsa_write %d samples, available samples after write %ld", nsamples, (long)avail );
  }

  ++cnt;
#endif /* #ifdef SHOW_ALSA_FILLING_STATES */



	return err;
}


static snd_mixer_t *alsa_mixer_open(const char *mixdev){
	snd_mixer_t *mixer=NULL;
	int err;
	err=snd_mixer_open(&mixer,0);
	if (err<0){
		ms_warning("Could not open alsa mixer: %s",snd_strerror(err));
		return NULL;
	}
	if ((err = snd_mixer_attach (mixer, mixdev)) < 0){
		ms_warning("Could not attach mixer to card: %s",snd_strerror(err));
		snd_mixer_close(mixer);
		return NULL;
	}
	if ((err = snd_mixer_selem_register (mixer, NULL, NULL)) < 0){
		ms_warning("snd_mixer_selem_register: %s",snd_strerror(err));
		snd_mixer_close(mixer);
		return NULL;
	}
	if ((err = snd_mixer_load (mixer)) < 0){
		ms_warning("snd_mixer_load: %s",snd_strerror(err));
		snd_mixer_close(mixer);
		return NULL;
	}
	return mixer;
}

static void alsa_mixer_close(snd_mixer_t *mix){
	snd_mixer_close(mix);
}

typedef enum {CAPTURE, PLAYBACK, CAPTURE_SWITCH, PLAYBACK_SWITCH} MixerAction;

static int get_mixer_element(snd_mixer_t *mixer,const char *name, MixerAction action){
	long value=0;
	const char *elemname;
	snd_mixer_elem_t *elem;
	int err;
	long sndMixerPMin=0;
	long sndMixerPMax=0;
	long newvol=0;
	elem=snd_mixer_first_elem(mixer);
	while (elem!=NULL){
		elemname=snd_mixer_selem_get_name(elem);
		//ms_message("Found alsa mixer element %s.",elemname);
		if (strcmp(elemname,name)==0){
			switch (action){
				case CAPTURE:
				if (snd_mixer_selem_has_capture_volume(elem)){
					snd_mixer_selem_get_capture_volume_range(elem, &sndMixerPMin, &sndMixerPMax);
					err=snd_mixer_selem_get_capture_volume(elem,SND_MIXER_SCHN_UNKNOWN,&newvol);
					newvol-=sndMixerPMin;
					value=(100*newvol)/(sndMixerPMax-sndMixerPMin);
					if (err<0) ms_warning("Could not get capture volume for %s:%s",name,snd_strerror(err));
					//else ms_message("Successfully get capture level for %s.",elemname);
					break;
				}
				break;
				case PLAYBACK:
				if (snd_mixer_selem_has_playback_volume(elem)){
					snd_mixer_selem_get_playback_volume_range(elem, &sndMixerPMin, &sndMixerPMax);
					err=snd_mixer_selem_get_playback_volume(elem,SND_MIXER_SCHN_FRONT_LEFT,&newvol);
					newvol-=sndMixerPMin;
					value=(100*newvol)/(sndMixerPMax-sndMixerPMin);
					if (err<0) ms_warning("Could not get playback volume for %s:%s",name,snd_strerror(err));
					//else ms_message("Successfully get playback level for %s.",elemname);
					break;
				}
				break;
				case CAPTURE_SWITCH:

				break;
				case PLAYBACK_SWITCH:

				break;
			}
		}
		elem=snd_mixer_elem_next(elem);
	}

	return value;
}


static void set_mixer_element(snd_mixer_t *mixer,const char *name, int level,MixerAction action){
	const char *elemname;
	snd_mixer_elem_t *elem;
	long sndMixerPMin=0;
	long sndMixerPMax=0;
	long newvol=0;

	elem=snd_mixer_first_elem(mixer);

	while (elem!=NULL){
		elemname=snd_mixer_selem_get_name(elem);
		//ms_message("Found alsa mixer element %s.",elemname);
		if (strcmp(elemname,name)==0){
			switch(action){
				case CAPTURE:
				if (snd_mixer_selem_has_capture_volume(elem)){
					snd_mixer_selem_get_capture_volume_range(elem, &sndMixerPMin, &sndMixerPMax);
					newvol=(((sndMixerPMax-sndMixerPMin)*level)/100)+sndMixerPMin;
					snd_mixer_selem_set_capture_volume_all(elem,newvol);
					//ms_message("Successfully set capture level for %s.",elemname);
					return;
				}
				break;
				case PLAYBACK:
				if (snd_mixer_selem_has_playback_volume(elem)){
					snd_mixer_selem_get_playback_volume_range(elem, &sndMixerPMin, &sndMixerPMax);
					newvol=(((sndMixerPMax-sndMixerPMin)*level)/100)+sndMixerPMin;
					snd_mixer_selem_set_playback_volume_all(elem,newvol);
					//ms_message("Successfully set playback level for %s.",elemname);
					return;
				}
				break;
				case CAPTURE_SWITCH:
				if (snd_mixer_selem_has_capture_switch(elem)){
					snd_mixer_selem_set_capture_switch_all(elem,level);
					//ms_message("Successfully set capture switch for %s.",elemname);
				}
				break;
				case PLAYBACK_SWITCH:
				if (snd_mixer_selem_has_playback_switch(elem)){
					snd_mixer_selem_set_playback_switch_all(elem,level);
					//ms_message("Successfully set capture switch for %s.",elemname);
				}
				break;

			}
		}
		elem=snd_mixer_elem_next(elem);
	}

	return ;
}


static void alsa_card_set_level(MSSndCard *obj,MSSndCardMixerElem e,int a)
{
	snd_mixer_t *mixer;
	AlsaData *ad=(AlsaData*)obj->data;
	mixer=alsa_mixer_open(ad->mixdev);
	if (mixer==NULL) return ;
	switch(e){
		case MS_SND_CARD_MASTER:
			set_mixer_element(mixer,"Master",a,PLAYBACK);
		break;
		case MS_SND_CARD_CAPTURE:
			set_mixer_element(mixer,"Capture",a,CAPTURE);
		break;
		case MS_SND_CARD_PLAYBACK:
			set_mixer_element(mixer,"PCM",a,PLAYBACK);
		break;
		default:
			ms_warning("alsa_card_set_level: unsupported command.");
	}
	alsa_mixer_close(mixer);
}

static int alsa_card_get_level(MSSndCard *obj, MSSndCardMixerElem e)
{
	snd_mixer_t *mixer;
	AlsaData *ad=(AlsaData*)obj->data;
	int value = -1;
	mixer=alsa_mixer_open(ad->mixdev);
	if (mixer==NULL) return 0;
	switch(e){
		case MS_SND_CARD_MASTER:
			value=get_mixer_element(mixer,"Master",PLAYBACK);
			break;
		case MS_SND_CARD_CAPTURE:
			value=get_mixer_element(mixer,"Capture",CAPTURE);
			break;
		case MS_SND_CARD_PLAYBACK:
			value=get_mixer_element(mixer,"PCM",PLAYBACK);
			break;
		default:
			ms_warning("alsa_card_set_level: unsupported command.");
	}
	alsa_mixer_close(mixer);
	return value;
}

static void alsa_card_set_source(MSSndCard *obj,MSSndCardCapture source)
{
	snd_mixer_t *mixer;
	AlsaData *ad=(AlsaData*)obj->data;
	mixer=alsa_mixer_open(ad->mixdev);
	if (mixer==NULL) return;
	switch (source){
		case MS_SND_CARD_MIC:
			set_mixer_element(mixer,"Mic",1,CAPTURE_SWITCH);
			set_mixer_element(mixer,"Capture",1,CAPTURE_SWITCH);
			break;
		case MS_SND_CARD_LINE:
			set_mixer_element(mixer,"Line",1,CAPTURE_SWITCH);
			set_mixer_element(mixer,"Capture",1,CAPTURE_SWITCH);
			break;
	}
	alsa_mixer_close(mixer);
}

static MSFilter *alsa_card_create_reader(MSSndCard *card)
{
	AlsaData *ad=(AlsaData*)card->data;
	MSFilter *f=ms_alsa_read_new(ad->pcmdev);
	return f;
}

static MSFilter *alsa_card_create_writer(MSSndCard *card)
{
	AlsaData *ad=(AlsaData*)card->data;
	MSFilter *f=ms_alsa_write_new(ad->pcmdev);
	return f;
}


static void alsa_card_init(MSSndCard *obj){
	AlsaData *ad=ms_new0(AlsaData,1);
	obj->data=ad;
}

static void alsa_card_uninit(MSSndCard *obj){
	AlsaData *ad=(AlsaData*)obj->data;
	if (ad->pcmdev!=NULL) ms_free(ad->pcmdev);
	if (ad->mixdev!=NULL) ms_free(ad->mixdev);
	ms_free(ad);
}

static void alsa_card_detect(MSSndCardManager *m){
	int i;
	for (i=-1;i<10;i++){
		MSSndCard *card=alsa_card_new(i);
		if (card!=NULL)
			ms_snd_card_manager_add_card(m,card);
	}
	atexit((void(*)(void))snd_config_update_free_global);
}

MSSndCardDesc alsa_card_desc={
	.driver_type="ALSA",
	.detect=alsa_card_detect,
	.init=alsa_card_init,
	.set_level=alsa_card_set_level,
	.get_level=alsa_card_get_level,
	.set_capture=alsa_card_set_source,
	.set_control=NULL,
	.get_control=NULL,
	.create_reader=alsa_card_create_reader,
	.create_writer=alsa_card_create_writer,
	.uninit=alsa_card_uninit,
	.duplicate=alsa_card_duplicate
};

static MSSndCard *alsa_card_duplicate(MSSndCard *obj){
	MSSndCard *card=ms_snd_card_new(&alsa_card_desc);
	AlsaData* dcard=(AlsaData*)card->data;
	AlsaData* dobj=(AlsaData*)obj->data;
	card->name=ms_strdup(obj->name);
	card->id=ms_strdup(obj->id);
	dcard->pcmdev=ms_strdup(dobj->pcmdev);
	dcard->mixdev=ms_strdup(dobj->mixdev);
	return card;
}

void alsa_read_asrc_init(MSFilter *obj);
void alsa_read_asrc_uninit(MSFilter *obj);
void alsa_write_asrc_init(MSFilter *obj);
void alsa_write_asrc_uninit(MSFilter *obj);
void asrc_read_process(MSFilter *obj);
void asrc_write_process(MSFilter *obj);

void alsa_read_process(MSFilter *obj);
void alsa_write_process(MSFilter *obj);

MSSndCard * ms_alsa_card_new_custom(const char *pcmdev, const char *mixdev){
	MSSndCard * obj;
	AlsaData *ad;
	#ifdef ENABLE_ALSA_ASRC
  extern MSFilterDesc alsa_write_desc;
  extern MSFilterDesc alsa_read_desc;
  #endif

	obj=ms_snd_card_new(&alsa_card_desc);
	ad=(AlsaData*)obj->data;
	obj->name=ms_strdup(pcmdev);
	ad->pcmdev=ms_strdup(pcmdev);
	ad->mixdev=ms_strdup(mixdev);

	if( alsa_get_entangled_asrc_dev_for_name( pcmdev ) )
	{
    g_use_hostpcm_interface = 1;
#ifdef ENABLE_ALSA_ASRC
    ms_message("ms_alsa_card_new_custom: entangled audio devices present, so ensure to open up ms_filter chain only once!" );
#else
    ms_error("ms_alsa_card_new_custom: asrc must be enabled when using Qualcomm host pcm interface devices!" );
    ms_error("ms_alsa_card_new_custom:      compile library mediastreamer2 with configure option --enable_alsa_asrc");
    exit(-1);
#endif
  }

	#ifdef ENABLE_ALSA_ASRC
  alsa_read_desc.init = alsa_read_asrc_init;
  alsa_read_desc.uninit = alsa_read_asrc_uninit;
  alsa_read_desc.process = asrc_read_process;
  // alsa_read_desc.process = alsa_read_process;
  alsa_write_desc.init = alsa_write_asrc_init;
  alsa_write_desc.uninit = alsa_write_asrc_uninit;
  alsa_write_desc.process = asrc_write_process;
  // alsa_write_desc.process = alsa_write_process;
  ms_message("ms_alsa_card_new_custom: using asynchronous sample rate conversion within background threads!" );
  #endif

	return obj;
}

static unsigned int get_card_capabilities(const char *devname){
	snd_pcm_t *pcm_handle;
	unsigned int ret=0;
	if (snd_pcm_open(&pcm_handle,devname,SND_PCM_STREAM_CAPTURE,SND_PCM_NONBLOCK)==0) {
		ret|=MS_SND_CARD_CAP_CAPTURE;
		snd_pcm_close(pcm_handle);
	}
	if (snd_pcm_open(&pcm_handle,devname,SND_PCM_STREAM_PLAYBACK,SND_PCM_NONBLOCK)==0) {
		ret|=MS_SND_CARD_CAP_PLAYBACK;
		snd_pcm_close(pcm_handle);
	}
	return ret;
}

static MSSndCard * alsa_card_new(int id)
{
	MSSndCard * obj;
	char *name=NULL;
	AlsaData *ad;
	int err;

	if (id!=-1){
		err=snd_card_get_name(id,&name);
		if (err<0) {
			return NULL;
		}
	}
	obj=ms_snd_card_new(&alsa_card_desc);
	ad=(AlsaData*)obj->data;
	if (id==-1) {
		/* the default pcm device */
		obj->name=ms_strdup("default device");
		ad->pcmdev=ms_strdup("default");
		ad->mixdev=ms_strdup("default");
	}else{
		/* remove trailing spaces from card name */
		char *pos1, *pos2;
		pos1=ms_strdup(name);
		pos2=pos1+strlen(pos1)-1;
		for (; pos2>pos1 && *pos2==' '; pos2--) *pos2='\0';
		obj->name=pos1;
		ad->pcmdev=ms_strdup_printf("default:%i",id);
		ad->mixdev=ms_strdup_printf("default:%i",id);
		{
			snd_mixer_t *mixer;
			mixer = alsa_mixer_open(ad->mixdev);
			if (mixer==NULL) {
				ms_free(ad->mixdev);
				ad->mixdev=ms_strdup_printf("hw:%i",id);
			} else {
				alsa_mixer_close(mixer);
			}
		}
	}
	/*check card capabilities: */
	obj->capabilities=get_card_capabilities(ad->pcmdev);
	if (obj->capabilities==0){
		ms_warning("Strange, sound card %s does not seems to be capable of anything, retrying with plughw...",obj->name);
		/*retry with plughw: this workarounds an alsa bug*/
		ms_free(ad->pcmdev);
		ad->pcmdev=ms_strdup_printf("plughw:%i",id);
		obj->capabilities=get_card_capabilities(ad->pcmdev);
		if (obj->capabilities==0){
			ms_warning("Strange, sound card %s seems totally unusable.",obj->name);
		}
	}
	free(name);
	/*ms_message("alsa device %s found",obj->name);*/
	return obj;
}


void alsa_read_init(MSFilter *obj){
	AlsaReadData *ad=ms_new(AlsaReadData,1);
	ad->pcmdev=NULL;
	ad->handle=NULL;
	ad->rate=forced_rate!=-1 ? forced_rate : 8000;
	ad->nchannels=1;
	ad->av_skew=0;
	obj->data=ad;

#ifdef THREADED_VERSION
	ad->read_started=FALSE;
	ad->write_started=FALSE;
	ad->bufferizer=ms_bufferizer_new();
	ms_mutex_init(&ad->mutex,NULL);
	ad->thread=0;
#endif
}

void alsa_read_asrc_init(MSFilter *obj){
	AlsaReadData *ad;

  alsa_read_init( obj );
	ad=(AlsaReadData*)obj->data;

  if( ad && init_asrc_thread_data( & ad->hostPcmDataPtr ) != 0 )
  {
    ms_error( "alsa_read_asrc_init: initialization failed error!");
    exit(-1);
  }
  ad->hostPcmDataPtr->alsaReadDataPtr = ad;
}

#ifdef THREADED_VERSION

static void * alsa_write_thread(void *p){
	AlsaReadData *ad=(AlsaReadData*)p;
	int samples=(160*ad->rate)/8000;
	int err;
	int count=0;
	mblk_t *om=NULL;
	struct timeval timeout;
	if (ad->handle==NULL && ad->pcmdev!=NULL){
		ad->handle=alsa_open_r(ad->pcmdev,16,ad->nchannels==2,ad->rate);
	}
	if (ad->handle==NULL) return NULL;

	while (ad->read_started)
	  {
	    count = alsa_can_read(ad->handle,samples);
	    if (count==24)
	      { /* keep this value for this driver */ }
	    else if (count<=0)
	      {
		count = samples;
	      }
	    else if (count>0)
	      {
		//ms_warning("%i count", count);
		//count = samples;
	      }

	    int size=count*2;
	    om=allocb(size,0);

	    if ((err=alsa_read(ad->handle,om->b_wptr,count))<=0)
	      {
		ms_warning("nothing to read");
		//ms_warning("Fail to read samples %i", count);
		freemsg(om); /* leak fixed */
		continue;
	      }
	    //ms_warning(" read %i", err);

	    size=err*2;
	    om->b_wptr+=size;

	    ms_mutex_lock(&ad->mutex);
	    ms_bufferizer_put(ad->bufferizer,om);
	    ms_mutex_unlock(&ad->mutex);

	    if (count==24)
	      {
		timeout.tv_sec = 0;
		timeout.tv_usec = 2000;
		select(0, 0, NULL, NULL, &timeout );
	      }
	    else
	      {
		/* select will be less active than locking on "read" */
		timeout.tv_sec = 0;
		timeout.tv_usec = 5000;
		select(0, 0, NULL, NULL, &timeout );
	      }
	  }

	if (ad->handle!=NULL) snd_pcm_close(ad->handle);
	ad->handle=NULL;
	return NULL;
}

static void alsa_start_r(AlsaReadData *d){
	if (d->read_started==FALSE){
		d->read_started=TRUE;
		ms_thread_create(&d->thread,NULL,alsa_write_thread,d);
	}else d->read_started=TRUE;
}

static void alsa_stop_r(AlsaReadData *d){
	d->read_started=FALSE;
	if (d->thread!=0)
	  {
	    ms_thread_join(d->thread,NULL);
	    d->thread=0;
	  }
}
#endif


static uint64_t get_wallclock_ms(void){
	MSTimeSpec ts;
	ms_get_cur_time(&ts);
	return (ts.tv_sec*1000LL) + ((ts.tv_nsec+500000LL)/1000000LL);
}

static const double clock_coef=.01;

static uint64_t sound_read_time_func(AlsaReadData *d){
	static int count;
	uint64_t sound_time;
	uint64_t wc=get_wallclock_ms();

	if (d->read_samples==0){
		d->wc_offset=0;
		return wc;
	}
	if (d->wc_offset==0){
		d->wc_offset=wc;
	}
	sound_time=d->wc_offset+((1000*d->read_samples)/(int64_t)d->rate);
	int diff=(int64_t)wc-(int64_t)sound_time;
	d->av_skew=(d->av_skew*(1.0-clock_coef)) + ((double)diff*clock_coef);
	count++;
	if (count%500==0) ms_message("alsa: sound/wall clock skew is average=%f ms, instant=%i ms",d->av_skew,diff);
	return wc-d->av_skew;
}


void alsa_read_preprocess(MSFilter *obj){
#ifdef THREADED_VERSION
	AlsaReadData *ad=(AlsaReadData*)obj->data;
	alsa_start_r(ad);
#endif
}


void alsa_read_postprocess(MSFilter *obj){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
#ifdef THREADED_VERSION
	alsa_stop_r(ad);
#endif
	ms_ticker_set_time_func(obj->ticker,NULL,NULL);
	if (ad->handle!=NULL) snd_pcm_close(ad->handle);
	ad->handle=NULL;
}

void alsa_read_uninit(MSFilter *obj){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
#ifdef THREADED_VERSION
	alsa_stop_r(ad);
#endif
	if (ad->pcmdev!=NULL) ms_free(ad->pcmdev);
	if (ad->handle!=NULL) snd_pcm_close(ad->handle);
#ifdef THREADED_VERSION
	ms_bufferizer_destroy(ad->bufferizer);
	ms_mutex_destroy(&ad->mutex);
#endif
	ms_free(ad);

#ifdef ALSA_TRACE_AUDIO_DATA
  trace_audio_data_release( &trace_alsa_read_data );
#endif
}

void alsa_read_asrc_uninit(MSFilter *obj)
{
	AlsaReadData *ad=(AlsaReadData*)obj->data;

  ms_message( "alsa_read_asrc_uninit");

  release_asrc_thread_data( ad->hostPcmDataPtr );
  alsa_read_uninit(obj);

#ifdef ALSA_TRACE_AUDIO_DATA
  trace_audio_data_release( &trace_alsa_read_data );
#endif
}

#ifndef THREADED_VERSION
void alsa_read_process(MSFilter *obj){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
  /* operate on 20ms period size also for the read process
     2013-02-25 @peiker/ol */
	/* int samples=(128*ad->rate)/8000; */
	int samples=ALSA_PERIOD_TIME * ad->rate / 1000;
	int err;
	mblk_t *om=NULL;

	if (ad->handle==NULL && ad->pcmdev!=NULL){
		ad->handle=alsa_open_r(ad->pcmdev,16,ad->nchannels==2,ad->rate);
		if (ad->handle){
			ad->read_samples=0;
			ms_ticker_set_time_func(obj->ticker,(uint64_t (*)(void*))sound_read_time_func,ad);
		}
	}
	if (ad->handle==NULL) return;
	while (alsa_can_read(ad->handle)>=samples){

		int size=samples*2*ad->nchannels;
		om=allocb(size,0);
		if ((err=alsa_read(ad->handle,om->b_wptr,samples))<=0) {
			ms_warning("Fail to read samples");
			freemsg(om);
			return;
		}
		ad->read_samples+=err;
		size=err*2*ad->nchannels;
		om->b_wptr+=size;
		/*ms_message("alsa_read_process: Outputing %i bytes",size);*/
		ms_queue_put(obj->outputs[0],om);
	}
}
#endif


void asrc_read_process(MSFilter *obj)
{
	AlsaReadData *ad=(AlsaReadData*)obj->data;
  t_asrc_thread_data* p = ad->hostPcmDataPtr;
	int samples;
	mblk_t *om=NULL;
	int size;

  if( ! ad->hostPcmDataPtr->run )
  {
    /* ensure that background alsa trhead delivering data is running */
    ms_message("asrc_read_process: starting host pcm thread ...");
    start_asrc_thread( ad->hostPcmDataPtr );
    ad->read_samples=0;

    /* be careful with ticker time correction with host pcm interface due to the observation
       of rtp read stream to become interrupted when using this! Since correct rtp timestamps
       are considered very important and hostpcm seems to work with it in principal as well
       we reanable this callback again. */
    ms_ticker_set_time_func(obj->ticker,(uint64_t (*)(void*))sound_read_time_func,ad);
  }

#ifdef ALSA_TRACE_AUDIO_DATA
  /* trace audio data */
  if( ! trace_alsa_read_data.initialized )
  {
    if( trace_audio_data_init( &trace_alsa_read_data, TRACE_AUDIO_READ_FILENAME, TRACE_AUDIO_MAX_FRAMES ) )
    {
      ms_error( "asrc_read_process: initialization of alsa read trace instance failed!");
    }
  }
#endif /* #ifdef ALSA_TRACE_AUDIO_DATA */


  pthread_mutex_lock ( p->pMutex );
  samples = p->capture_frontend_w_ptr - p->capture_frontend_r_ptr;
  if( samples > 0 )
  {
    // assert( samples == HOST_PCM_ATOMIC_SAMPLES );

    size=samples*2*ad->nchannels;
    om=allocb(size,0);
    memcpy( om->b_wptr, p->capture_frontend_r_ptr, size );
    p->capture_frontend_r_ptr += samples;
  }
  pthread_mutex_unlock ( p->pMutex );


  if( samples > 0 )
  {
#ifdef ALSA_TRACE_AUDIO_DATA
    if( trace_audio_data_process( &trace_alsa_read_data, om->b_wptr, size ) )
    {
      ms_error( "asrc_read_process: write trace process failed!");
    }
#endif /* #ifdef ALSA_TRACE_AUDIO_DATA */

    om->b_wptr+=size;
    ad->read_samples+=samples;

    /*ms_message("alsa_read_process: Outputing %i bytes",size);*/
    ms_queue_put(obj->outputs[0],om);
  }
}


#ifdef THREADED_VERSION
void alsa_read_process(MSFilter *obj){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
	mblk_t *om=NULL;
	int samples=(160*ad->rate)/8000;
	int size=samples*2*ad->nchannels;

	ms_mutex_lock(&ad->mutex);
	while (ms_bufferizer_get_avail(ad->bufferizer)>=size){

	  om=allocb(size,0);
	  ms_bufferizer_read(ad->bufferizer,om->b_wptr,size);
	  om->b_wptr+=size;
	  /*ms_message("alsa_read_process: Outputing %i bytes",size);*/
	  ms_queue_put(obj->outputs[0],om);
	}
	ms_mutex_unlock(&ad->mutex);
}
#endif

static int alsa_read_get_sample_rate(MSFilter *obj, void *param){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
	*((int*)param)=ad->rate;
	return 0;
}

static int alsa_read_set_sample_rate(MSFilter *obj, void *param){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
	if (forced_rate!=-1) return -1;
	ad->rate=*((int*)param);
	return 0;
}

static int alsa_read_set_nchannels(MSFilter *obj, void *param){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
	ad->nchannels=*((int*)param);
	return 0;
}

MSFilterMethod alsa_read_methods[]={
	{MS_FILTER_GET_SAMPLE_RATE,	alsa_read_get_sample_rate},
	{MS_FILTER_SET_SAMPLE_RATE, alsa_read_set_sample_rate},
	{MS_FILTER_SET_NCHANNELS, alsa_read_set_nchannels},
	{0,NULL}
};

MSFilterDesc alsa_read_desc={
	.id=MS_ALSA_READ_ID,
	.name="MSAlsaRead",
	.text=N_("Alsa sound source"),
	.category=MS_FILTER_OTHER,
	.ninputs=0,
	.noutputs=1,
	.init=alsa_read_init,
	.preprocess=alsa_read_preprocess,
	.process=alsa_read_process,
	.postprocess=alsa_read_postprocess,
	.uninit=alsa_read_uninit,
	.methods=alsa_read_methods
};

static MSFilter * ms_alsa_read_new(const char *dev){
	MSFilter *f=ms_filter_new_from_desc(&alsa_read_desc);
	AlsaReadData *ad=(AlsaReadData*)f->data;
	ad->pcmdev=ms_strdup(dev);
	return f;
}

void alsa_write_init(MSFilter *obj){

	AlsaWriteData *ad=ms_new(AlsaWriteData,1);
	ad->pcmdev=NULL;
	ad->handle=NULL;
	ad->rate=forced_rate!=-1 ? forced_rate : 8000;
	ad->nchannels=1;
	obj->data=ad;
}

void alsa_write_asrc_init(MSFilter *obj){
	AlsaWriteData *ad;

  alsa_write_init( obj );
	ad=(AlsaWriteData*)obj->data;

  if( ad && init_asrc_thread_data( & ad->hostPcmDataPtr ) != 0 )
  {
    ms_error( "alsa_write_asrc_init: initialization failed error!");
    exit(-1);
  }
  ad->hostPcmDataPtr->alsaWriteDataPtr = ad;
}

void alsa_write_postprocess(MSFilter *obj){
	AlsaReadData *ad=(AlsaReadData*)obj->data;
	if (ad->handle!=NULL) snd_pcm_close(ad->handle);
	ad->handle=NULL;
}

void alsa_write_uninit(MSFilter *obj){
	AlsaWriteData *ad=(AlsaWriteData*)obj->data;
	if (ad->pcmdev!=NULL) ms_free(ad->pcmdev);
	if (ad->handle!=NULL) snd_pcm_close(ad->handle);
	ms_free(ad);

#ifdef ALSA_TRACE_AUDIO_DATA
  trace_audio_data_release( &trace_alsa_write_data );
#endif
}

void alsa_write_asrc_uninit(MSFilter *obj)
{
	AlsaWriteData *ad=(AlsaWriteData*)obj->data;

  ms_message( "alsa_write_asrc_uninit\n");

  release_asrc_thread_data( ad->hostPcmDataPtr );
  alsa_write_uninit(obj);

#ifdef ALSA_TRACE_AUDIO_DATA
  trace_audio_data_release( &trace_alsa_write_data );
#endif
}

static int alsa_write_get_sample_rate(MSFilter *obj, void *data){
	AlsaWriteData *ad=(AlsaWriteData*)obj->data;
	*((int*)data)=ad->rate;
	return 0;
}

int alsa_write_set_sample_rate(MSFilter *obj, void *data){
	int *rate=(int*)data;
	AlsaWriteData *ad=(AlsaWriteData*)obj->data;
	if (forced_rate!=-1) return -1;
	ad->rate=*rate;
	return 0;
}

int alsa_write_set_nchannels(MSFilter *obj, void *data){
	int *n=(int*)data;
	AlsaWriteData *ad=(AlsaWriteData*)obj->data;
	ad->nchannels=*n;
	return 0;
}

void alsa_write_process(MSFilter *obj){
	AlsaWriteData *ad=(AlsaWriteData*)obj->data;
	mblk_t *im=NULL;
	int size;
	int samples;
	int err;
	if (ad->handle==NULL && ad->pcmdev!=NULL){
		ad->handle=alsa_open_w(ad->pcmdev,16,ad->nchannels==2,ad->rate);
#ifdef EPIPE_BUGFIX
		alsa_fill_w ( ad->handle );
#endif
	}
	if (ad->handle==NULL) {
		ms_queue_flush(obj->inputs[0]);
		return;
	}
	while ((im=ms_queue_get(obj->inputs[0]))!=NULL){
		while((size=im->b_wptr-im->b_rptr)>0){
			samples=size/(2*ad->nchannels);
			err=alsa_write(ad->handle,im->b_rptr,samples);
			if (err>0) {
				im->b_rptr+=err*(2*ad->nchannels);
			}
			else break;
		}
		freemsg(im);
	}
}


void asrc_write_process(MSFilter *obj)
{
	AlsaWriteData *ad=(AlsaWriteData*)obj->data;
  t_asrc_thread_data* p = ad->hostPcmDataPtr;
	mblk_t *im=NULL;
	int size, samples;
  uint64_t ts;
#ifdef HOST_PCM_DISABLE_JITTER_BUFFER
  int samples_left, samples_to_copy;
#endif

  static int tot_samples = 0;

  if( ! ad->hostPcmDataPtr->run )
  {
    /* ensure that background alsa trhead receiving data is running */
    ms_message("asrc_write_process: starting host pcm thread ...");
    start_asrc_thread( ad->hostPcmDataPtr );
  }

#ifdef ALSA_TRACE_AUDIO_DATA
  /* trace audio data */
  if( ! trace_alsa_write_data.initialized )
  {
    if( trace_audio_data_init( &trace_alsa_write_data, TRACE_AUDIO_WRITE_FILENAME, TRACE_AUDIO_MAX_FRAMES ) )
    {
      ms_error( "asrc_write_process: initialization of alsa write trace instance failed error!");
    }
  }
#endif /* #ifdef ALSA_TRACE_AUDIO_DATA */

	while ((im=ms_queue_get(obj->inputs[0]))!=NULL)
  {
		while((size=im->b_wptr-im->b_rptr)>0)
    {
      samples = size/2;
      tot_samples += samples;

#ifdef ALSA_TRACE_AUDIO_DATA
      if( trace_audio_data_process( &trace_alsa_write_data, im->b_rptr, size ) )
      {
        ms_error( "write trace process failed!\n");
      }
#endif /* #ifdef ALSA_TRACE_AUDIO_DATA */


#ifdef HOST_PCM_DISABLE_JITTER_BUFFER
      pthread_mutex_lock ( p->pMutex );
      samples_left = HOST_PCM_ATOMIC_SAMPLES - (p->playback_frontend_w_ptr - p->playback_frontend_r_ptr);
      samples_to_copy = MIN( samples, samples_left );
      memcpy( p->playback_frontend_w_ptr, im->b_rptr, samples_to_copy * 2 );
      p->playback_frontend_w_ptr += samples_to_copy;
      pthread_mutex_unlock ( p->pMutex );
#elif defined( ENABLE_ALSA_ASRC )
      /* use time stamp from RTP streaming source (user equipment) */
      // ts = (uint64_t)im->reserved1 * 1000LL / (uint64_t)(ad->rate);
      ts = (im->timestamp.tv_sec*1000LL) + ((im->timestamp.tv_usec+500LL)/1000LL);
      pa_asrc_put( p->playback_asrc_ptr, (int16_t *)im->b_rptr, samples, ts );
#else
      pthread_mutex_lock ( p->pMutex );
      if( p->playback_jitter_ring->uiFill < (HOST_PCM_PLAYBACK_JITTER_BUF_SAMPLES * sizeof(int16_t)) - size )
      {
        _pa_ringBufAddData( p->playback_jitter_ring, (int8_t *)im->b_rptr, size, 0 /* overwrite */ );
        // _pa_ringBufAddData( p->playback_jitter_ring, (int8_t *)sine400, size, 1 /* overwrite */ );
      }
      else
      {
        ms_warning("asrc_write_process: host pcm playback jitterbuffer overrun!");
      }
      pthread_mutex_unlock ( p->pMutex );
#endif /* #ifdef HOST_PCM_DISABLE_JITTER_BUFFER */

      im->b_rptr += size;
    }

		freemsg(im);
	}
}

MSFilterMethod alsa_write_methods[]={
	{MS_FILTER_GET_SAMPLE_RATE,	alsa_write_get_sample_rate},
	{MS_FILTER_SET_SAMPLE_RATE, alsa_write_set_sample_rate},
	{MS_FILTER_SET_NCHANNELS, alsa_write_set_nchannels},
	{0,NULL}
};

MSFilterDesc alsa_write_desc={
	.id=MS_ALSA_WRITE_ID,
	.name="MSAlsaWrite",
	.text=N_("Alsa sound output"),
	.category=MS_FILTER_OTHER,
	.ninputs=1,
	.noutputs=0,
	.init=alsa_write_init,
	.process=alsa_write_process,
	.postprocess=alsa_write_postprocess,
	.uninit=alsa_write_uninit,
	.methods=alsa_write_methods
};


static MSFilter * ms_alsa_write_new(const char *dev){
	MSFilter *f=ms_filter_new_from_desc(&alsa_write_desc);
	AlsaWriteData *ad=(AlsaWriteData*)f->data;
	ad->pcmdev=ms_strdup(dev);
	return f;
}


MS_FILTER_DESC_EXPORT(alsa_write_desc)

MS_FILTER_DESC_EXPORT(alsa_read_desc)

