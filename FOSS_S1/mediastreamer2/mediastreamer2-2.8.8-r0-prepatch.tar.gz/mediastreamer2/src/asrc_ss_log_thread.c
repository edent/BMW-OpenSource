/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/


#include <asrc_ss_log_thread.h>
#include <stdlib.h>
#include <assert.h>
#include <unistd.h>

#ifdef HAVE_LIBPTHREAD
 #include <pthread.h>
# ifdef ENABLE_SAMPLE_STREAM_LOGGING

static void init_asrc_log_thread_data( log_thread_data_t *p_thread, pa_asrc_buf* p_asrc_obj, int max_log_nr )
{
  p_thread->log_nr = 0;
  p_thread->max_log_nr = max_log_nr;
  p_thread->fp = NULL;
  p_thread->p_asrc_obj = p_asrc_obj;
  p_thread->error = 0;
  p_thread->run = 1;
}

static FILE* asrc_get_next_log_file( log_thread_data_t *p_thread )
{
  FILE* fp;
  char filename[80];
  char rm_filename[80];

  sprintf( filename, "%s%d.log", ASRC_LOG_FILENAME, (p_thread->log_nr)++ );
  if( p_thread->log_nr >= p_thread->max_log_nr )
  {
    sprintf( rm_filename, "%s%d.log", ASRC_LOG_FILENAME, p_thread->log_nr -p_thread->max_log_nr );
    unlink( rm_filename );
  }

  fp = fopen(filename,"w");
  if( fp == NULL )
    pa_error( "could not create file %s error!\n", filename );

  return fp;
}

static void* asrc_log_thread_function( void* p_arg )
{
  log_thread_data_t *p_thread = (log_thread_data_t *)p_arg;
  pa_ss_log_entry_t logtab[ASRC_LOG_ELEMENTS_PER_CHUNK];
  long entry, got_entries, written_entries;
  struct sched_param  sc_param;

  sched_setscheduler( 0, SCHED_OTHER, & sc_param );

  while( p_thread->run )
  {
    /* log rotate loop */

    pthread_mutex_lock( & p_thread->mutex );
    p_thread->fp = asrc_get_next_log_file( p_thread );
    pthread_mutex_unlock( & p_thread->mutex );
    if( p_thread->fp == NULL )
    {
      p_thread->error = -1;
      p_thread->run = 0;
      break;
    }

    written_entries = 0L;
    do {
      /* log worker loop */
      got_entries = read_ss_log_entries( p_thread->p_asrc_obj->ssLogPtr, logtab, ASRC_LOG_ELEMENTS_PER_CHUNK );
      for( entry = 0; entry < got_entries; ++ entry )
      {
        fprintf(p_thread->fp, "%llu : %d\n",
                logtab[entry].timestamp, logtab[entry].samples_in );
      }
      written_entries += got_entries;

      usleep( ASRC_LOG_THREAD_IDLE_MS * 1000 );
    } while( p_thread->run  &&  written_entries < ASRC_LOG_ELEMENTS_PER_FILE );

    pthread_mutex_lock( & p_thread->mutex );
    if( p_thread->fp )
    {
      fclose( p_thread->fp );
      p_thread->fp = NULL;
    }
    pthread_mutex_unlock( & p_thread->mutex );
  }

  return p_thread;
}


/*!
 * Allocate, create and run background thread for generating stream statistic log files
 *
 * Function parameters
 *   - p_asrc_obj:            pointer to asrc instance object data
 *
 * Returnparameter
 *   - R:                     pointer to thread object or NULL if allocation failed
 */
log_data_thread_t* create_asrc_log_thread( pa_asrc_buf* p_asrc_obj )
{
  log_data_thread_t*  p_thread;

  p_thread = malloc( sizeof( log_data_thread_t ) );
  if( p_thread == NULL )
    return NULL;

  if( pthread_mutex_init( & p_thread->data.mutex, 0 ) != 0 )
  {
    free( p_thread );
    return NULL;
  }

  init_asrc_log_thread_data( & p_thread->data, p_asrc_obj, ASRC_MAX_LOG_ROTATE_NR );
  if( pthread_create( & p_thread->thread, 0, asrc_log_thread_function, & p_thread->data ) != 0 )
  {
    pthread_mutex_destroy( & p_thread->data.mutex );
    free( p_thread );
    return NULL;
  }

  return( p_thread );
}



/*!
 * Stop and release background thread for generating stream statistic log files
 *
 * Function parameters
 *   - p_thread:              pointer to thread object to be stopped
 */
void stop_asrc_log_thread( log_data_thread_t* p_thread )
{
  p_thread->data.run = 0;

  pthread_join( p_thread->thread, NULL );

  pthread_mutex_lock( & p_thread->data.mutex );
  if( p_thread->data.fp )
  {
    fclose( p_thread->data.fp );
    p_thread->data.fp = NULL;
  }
  pthread_mutex_unlock( & p_thread->data.mutex );

  pthread_mutex_destroy( & p_thread->data.mutex );
  free( p_thread );
}

# endif /* # ifdef ENABLE_SAMPLE_STREAM_LOGGING */
#endif /* #ifdef HAVE_LIBPTHREAD */
