/**************************************************************************

       *
     ** **
   **     **
  *         *             **
 *           *           *  *     *
*             *         *    *   * *   ****   ****  ***  *   *  ****  ****
               *       *      * *      *   *  *      *   *  *   *     *   *
                *     *        *       ****   ***    *   * *    ***   ****
                 ** **                 *      *      *   ***    *     * *
                   *                   *      *      *   *  *   *     *  *
                                       *      ****  ***  *   *  ****  *   *

***************************************************************************/
/*!	\addtogroup signalproc
*	@{
***************************************************************************/
/*
*  History:
*  $Log: pa_stdint.h $
*
***************************************************************************/


/**************************************************************************
 INCLUDES
**************************************************************************/
#include "pa_buffer.h"
#include <string.h>


/**************************************************************************
 FUNCTION pa_ringBufInit()
**************************************************************************/
int _pa_ringBufInit( pa_ringBuf* block, int8_t* bufPtr, int32_t bufLen )
{
    int result = 0;

    if ((block == NULL) || (bufPtr == NULL) || (bufLen == 0)) {
        result = -1;
    }
    else {
        block->uiSize  = bufLen;
        block->uiFill  = 0;
        block->uiPosR  = 0;
        block->uiPosW  = 0;
        block->pBuffer = bufPtr;
    }

    return result;
}


/**************************************************************************
 FUNCTION pa_ringBufInit()
**************************************************************************/
int32_t _pa_ringBufAddData( pa_ringBuf* block, const int8_t* bufPtr, int32_t bufLen, int overwrite )
{
    /* Locals */
    int32_t space, size1, size2;

    /* Check parameters */
    if ((block == NULL) || (bufPtr == NULL) || (bufLen == 0)) {
        bufLen = 0;
    }

    /* Check if size of input buffer is greater than cirular buffer */
    if (bufLen > block->uiSize) {
        bufLen = 0;
    }

    /* Calculate number of bytes left in circular buffer */
    space = block->uiSize - block->uiFill;

    /* Adapt size of buffer depending on overwrite flag */
    if (overwrite == 0) {
        if (bufLen > space) {
            bufLen = space;
        }
    }
    else {
        if (bufLen > space) {
            block->uiFill -= (bufLen - space);
            block->uiPosR += (bufLen - space);
            if (block->uiPosR >= block->uiSize) {
                block->uiPosR -= block->uiSize;
            }
        }
    }

    /* Calculate number of bytes left to top of buffer */
    space = block->uiSize - block->uiPosW;

    /* Set number of bytes to copy for each stage */
    if (space > bufLen) {
        /* Copying can be done in one stage */
        size1 = bufLen;
        size2 = 0;
    }
    else {
        /* Copying has to be done in two stages */
        size1 = space;
        size2 = bufLen - space;
    }

    /* Copy bytes */
    memcpy( &block->pBuffer[block->uiPosW], &bufPtr[0], size1 );
    memcpy( &block->pBuffer[0], &bufPtr[size1], size2 );

    /* Update structure */
    block->uiFill += bufLen;
    block->uiPosW += bufLen;
    if (block->uiPosW >= block->uiSize) {
        block->uiPosW -= block->uiSize;
    }

    return bufLen;
}


/**************************************************************************
 FUNCTION pa_ringBufGetData()
**************************************************************************/
int32_t _pa_ringBufGetData( pa_ringBuf* block, int8_t* bufPtr, int32_t bufLen )
{
    /* Locals */
    int32_t space, size1, size2;

    /* Check parameters */
    if ((block == NULL) || (bufPtr == NULL) || (bufLen == 0)) {
        bufLen = 0;
    }

    /* Adapt buffer length depending on fill status */
    if (bufLen > block->uiFill) {
        bufLen = block->uiFill;
    }

    /* Calculate number of bytes left to top of buffer */
    space = block->uiSize - block->uiPosR;

    /* Set number of bytes to copy for each stage */
    if (space > bufLen) {
        /* Copying can be done in one stage */
        size1 = bufLen;
        size2 = 0;
    }
    else {
        /* Copying has to be done in two stages */
        size1 = space;
        size2 = bufLen - space;
    }

    /* Copy bytes */
    memcpy( &bufPtr[0], &block->pBuffer[block->uiPosR], size1 );
    memcpy( &bufPtr[size1], &block->pBuffer[0], size2 );

    /* Update structure */
    block->uiFill -= bufLen;
    block->uiPosR += bufLen;
    if (block->uiPosR >= block->uiSize) {
        block->uiPosR -= block->uiSize;
    }

    return bufLen;
}


/**************************************************************************
 eof 'pa_buffer.c'
**************************************************************************/

