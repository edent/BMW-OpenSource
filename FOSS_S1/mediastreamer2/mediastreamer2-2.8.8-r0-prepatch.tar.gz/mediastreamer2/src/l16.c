/*
mediastreamer2 library - modular sound and video processing and streaming
Copyright (C) 2011  Belledonne Communications SARL
Author: Simon Morlat <simon.morlat@linphone.org>

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <mediastreamer2/msfilter.h>
#include <arpa/inet.h>

struct EncState {
	uint32_t ts;
	int ptime;
	int rate;
	int nbytes;
  int change_endianess;
	MSBufferizer *bufferizer;
#ifdef ENABLE_L16_RTP_LOSS_ANALYSIS
  int32_t packet_count;
#endif
};

static inline uint16_t swap_uint16( uint16_t val )
{
  return (val << 8) | (val >> 8);
}

static void change_endianess( int16_t *p, const int elements )
{
  int i;

  for( i=0; i< elements; ++i )
  {
    p[i]= (int16_t) swap_uint16( (uint16_t) p[i] );
  }
}

static int is_bigendian_endian( void )
{
  return( htonl(47) == 47 );
}

static void enc_init(MSFilter *f)
{
	struct EncState *s=(struct EncState*)ms_new(struct EncState,1);
	s->ts=0;
	s->bufferizer=ms_bufferizer_new();
	s->ptime = 20;
	s->rate=8000;
  s->change_endianess = !is_bigendian_endian();
	f->data=s;
#ifdef ENABLE_L16_RTP_LOSS_ANALYSIS
  s->packet_count = 0L;
#endif
};

static void enc_uninit(MSFilter *f)
{
	struct EncState *s=(struct EncState*)f->data;
	ms_bufferizer_destroy(s->bufferizer);
	ms_free(s);
	f->data = 0;
};

static void enc_preprocess(MSFilter *f){
	struct EncState *s=(struct EncState*)f->data;
	s->nbytes=(2*s->rate*s->ptime)/1000;
}

static void enc_process(MSFilter *f)
{
	struct EncState *s=(struct EncState*)f->data;
  int bytes_read;

	ms_bufferizer_put_from_queue(s->bufferizer,f->inputs[0]);

	while(ms_bufferizer_get_avail(s->bufferizer)>=s->nbytes) {
		mblk_t *om=allocb(s->nbytes,0);
		bytes_read=ms_bufferizer_read(s->bufferizer,om->b_wptr,s->nbytes);

    if( s->change_endianess )
      change_endianess( (int16_t *) (om->b_wptr), bytes_read/2 );

#ifdef ENABLE_L16_RTP_LOSS_ANALYSIS
    *((int32_t *) (om->b_wptr)) = s->packet_count++;
#endif

		om->b_wptr+=bytes_read;

		mblk_set_timestamp_info(om,s->ts);
		ms_queue_put(f->outputs[0],om);
		s->ts += s->nbytes/2;
	}
};

static void set_ptime(struct EncState *s, int value){
	if (value>0 && value<=100){
		s->ptime=value;
	}
}

static int enc_add_attr(MSFilter *f, void *arg)
{
	const char *fmtp=(const char*)arg;
	struct EncState *s=(struct EncState*)f->data;
	if(strstr(fmtp,"ptime:"))
		set_ptime(s,atoi(fmtp+6));

	return 0;
};

static int enc_add_fmtp(MSFilter *f, void *arg){
	const char *fmtp=(const char*)arg;
	struct EncState *s=(struct EncState*)f->data;
	char tmp[16]={0};
	if (fmtp_get_value(fmtp,"ptime",tmp,sizeof(tmp))){
		set_ptime(s,atoi(tmp));
	}
	return 0;
}

static int enc_set_sr(MSFilter *f, void *arg){
	struct EncState *s=(struct EncState*)f->data;
	s->rate=*(int*)arg;
	return 0;
}

static MSFilterMethod enc_methods[]={
	{	MS_FILTER_ADD_ATTR		,	enc_add_attr},
	{	MS_FILTER_ADD_FMTP		,	enc_add_fmtp},
	{	MS_FILTER_SET_SAMPLE_RATE	,	enc_set_sr	},
	{	0				,	NULL		}
};

#ifdef _MSC_VER

MSFilterDesc ms_l16_enc_desc={
	MS_L16_ENC_ID,
	"MSL16Enc",
	"L16 dummy encoder",
	MS_FILTER_ENCODER,
	"l16",
	1,
	1,
	enc_init,
	enc_preprocess,
	enc_process,
	NULL,
	enc_uninit,
	enc_methods
};

#else

MSFilterDesc ms_l16_enc_desc={
	.id			= MS_L16_ENC_ID,
	.name		= "MSL16Enc",
	.text		= "L16 dummy encoder",
	.category	= MS_FILTER_ENCODER,
	.enc_fmt	= "l16",
	.ninputs	= 1,
	.noutputs	= 1,
	.init		= enc_init,
	.preprocess = enc_preprocess,
	.process	= enc_process,
	.uninit		= enc_uninit,
	.methods	= enc_methods
};
#endif


struct DecState {
  int change_endianess;
#ifdef ENABLE_L16_RTP_LOSS_ANALYSIS
  int32_t packet_count;
  int32_t loss_count;
#endif
};

static void dec_init(MSFilter *f){
	struct DecState *s=(struct DecState*)ms_new(struct DecState,1);
  s->change_endianess = !is_bigendian_endian();
	f->data=s;
#ifdef ENABLE_L16_RTP_LOSS_ANALYSIS
  s->packet_count = -1L;
  s->loss_count = 0L;
#endif
};

static void dec_uninit(MSFilter *f){
	struct DecState *s=(struct DecState*)f->data;
	ms_free(s);
	f->data = 0;
};

static void dec_process(MSFilter *f)
{
	struct DecState *s=(struct DecState*)f->data;
	mblk_t *im;
  int size;
#ifdef ENABLE_L16_RTP_LOSS_ANALYSIS
  int32_t received_packet_count;
#endif

	while((im=ms_queue_get(f->inputs[0]))) {
    size=im->b_wptr-im->b_rptr;

#ifdef ENABLE_L16_RTP_LOSS_ANALYSIS
    received_packet_count = *((int32_t *) (im->b_rptr));
    if( s->packet_count == -1L )
    {
      /* init */
      s->packet_count = received_packet_count;
    }
    else
    {
      if( ++s->packet_count != received_packet_count )
      {
        ms_error("--- !!! Did not receive L16 packet no %d error, number of lost packets %d !!! ---",
                 s->packet_count, s->loss_count );
        s->packet_count = received_packet_count;
        ++s->loss_count;
      }
    }
#endif /* #ifdef ENABLE_L16_RTP_LOSS_ANALYSIS */

    if( s->change_endianess )
      change_endianess( (int16_t *) (im->b_rptr), size/2 );

		ms_queue_put(f->outputs[0],im);
	}
};


/* @peiker/ol: PCM codec does not have PLC but we do neither
  want to incorporate the generic PLC to avoid NULL packets
  to be shipped, so indicate that we have one */
static int dec_have_plc(MSFilter *f, void *arg)
{
	*((int *)arg) = 1;
	return 0;
}

static int dec_add_fmtp(MSFilter *f, void *arg){
  /* @peiler/ol: plc is not required, used dummy implementation to
     avoid generic plc */
#if(0)
	DecState *s=(DecState*)f->data;
	const char *fmtp=(const char *)arg;
	char buf[32];
	if (fmtp_get_value(fmtp, "plc", buf, sizeof(buf))){
		s->plc=atoi(buf);
	}
#endif
	return 0;
}

static MSFilterMethod dec_methods[]={
	{	MS_FILTER_ADD_FMTP	,	dec_add_fmtp	},
	{ MS_DECODER_HAVE_PLC	, dec_have_plc	},
	{	0				,	NULL		}
};


#ifdef _MSC_VER

MSFilterDesc ms_l16_dec_desc={
	MS_L16_DEC_ID,
	"MSL16Dec",
	"L16 dummy decoder",
	MS_FILTER_DECODER,
	"l16",
	1,
	1,
	dec_init,
	NULL,
	dec_process,
	NULL,
	dec_uninit,
  dec_methods,
	NULL
};

#else

MSFilterDesc ms_l16_dec_desc={
	.id			= MS_L16_DEC_ID,
	.name		= "MSL16Dec",
	.text		= "L16 dummy decoder",
	.category	= MS_FILTER_DECODER,
	.enc_fmt	= "l16",
	.ninputs	= 1,
	.noutputs	= 1,
	.init		= dec_init,
	.process	= dec_process,
	.uninit		= dec_uninit,
  .methods  = dec_methods
};

#endif


MS_FILTER_DESC_EXPORT(ms_l16_dec_desc)
MS_FILTER_DESC_EXPORT(ms_l16_enc_desc)
