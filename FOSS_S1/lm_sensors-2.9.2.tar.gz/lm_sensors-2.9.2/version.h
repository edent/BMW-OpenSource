#define LM_DATE "20050906"
#define LM_VERSION "2.9.2"
