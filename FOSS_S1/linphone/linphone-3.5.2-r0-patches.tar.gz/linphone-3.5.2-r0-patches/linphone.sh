#! /bin/sh
# /etc/init.d/linphone: prelimary version, initializes internal linphone instance


##set -e # 01/07/2014 disabled to avoid script breakage on error


NAME=linphonec

PIDFILE=/var/run/$NAME.pd
# LOGFILE=/var/log/linphone.log
# LOGFILE=/dev/null

# seams to be realtime critical in some cases, so be careful with syslogging!
LOGFILE=syslog

DAEMON=/usr/bin/linphonec
DAEMON_ARGS="-d 3 -l $LOGFILE --pipe -a -c /tmp/linphonerc"


case "$1" in
    start)
        echo -n "Starting daemon: "$NAME

        cp /etc/linphonerc /tmp/linphonerc
        rm -f /tmp/linphonec-0
        start-stop-daemon --background --start --quiet -m --pidfile $PIDFILE --exec $DAEMON -- $DAEMON_ARGS
	      ;;

    stop)
        echo -n "Stopping daemon: "$NAME
        start-stop-daemon --stop --quiet --signal 9 --pidfile $PIDFILE
	      ;;

    restart)
        echo -n "Restart daemon: "$NAME
        $0 stop
        $0 start
	      ;;

    *)
	      echo "Usage: "$1" {start|stop|restart}" >&2
	      exit 1
        ;;
esac

exit 0
