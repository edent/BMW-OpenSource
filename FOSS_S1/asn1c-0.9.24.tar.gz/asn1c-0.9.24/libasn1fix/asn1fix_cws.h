#ifndef	_ASN1FIX_CLASS_WITH_SYNTAX_H_
#define	_ASN1FIX_CLASS_WITH_SYNTAX_H_

/*
 * Parse class objects
 */
int asn1f_parse_class_object(arg_t *arg);

#endif	/* _ASN1FIX_CLASS_WITH_SYNTAX_H_ */
